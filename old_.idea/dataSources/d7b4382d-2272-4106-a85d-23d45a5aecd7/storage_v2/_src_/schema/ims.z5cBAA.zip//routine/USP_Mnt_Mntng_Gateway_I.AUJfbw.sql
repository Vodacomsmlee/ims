create
    definer = ims@`%` procedure USP_Mnt_Mntng_Gateway_I(IN v_Svr_Ip varchar(15), IN v_Ping tinyint)
BEGIN
	declare v_ThresHold_Cnt int;
	set v_ThresHold_Cnt = 0;
	
	if v_Ping = 0 then -- PING False면 ThresHold_Cnt + 1
		SELECT ThresHold_Cnt INTO v_ThresHold_Cnt
		FROM mntng_svr
		WHERE Svr_Ip = v_Svr_Ip;
		
		SET v_ThresHold_Cnt = v_ThresHold_Cnt + 1;
		
		
	end if;
	update mntng_svr
	set ThresHold_Cnt = v_ThresHold_Cnt
	where Svr_Ip = v_Svr_Ip;
	
	INSERT INTO mntng_gateway_hist(Svr_Ip, Ping) VALUES(v_Svr_Ip, v_Ping);
END;

