create
    definer = ims@`%` procedure USP_Mnt_Mntng_Cpu_I(IN v_Model varchar(100), IN v_physical int, IN v_logical int,
                                                    IN v_Host_Nm varchar(100), IN v_CpuUser float, IN v_CpuSystem float,
                                                    IN v_CpuIdle float, IN v_SvrIp varchar(15),
                                                    IN v_Vendor varchar(100), IN v_Mhz int, IN v_CpuCnt int,
                                                    IN v_CacheSize int)
BEGIN
	DECLARE v_Old_Host_Nm VARCHAR(100);
	DECLARE v_ThresHold FLOAT;
	DECLARE v_ThresHold_Cnt INT;
	SET v_ThresHold_Cnt = 0;
	
	IF v_CpuUser IS NULL THEN
		SET v_CpuUser = 0;
	END IF;
	IF v_CpuSystem IS NULL THEN
		SET v_CpuSystem = 0;
	END IF;
	IF v_CpuIdle IS NULL THEN
		SET v_CpuIdle = 0;
	END IF;
	IF v_Vendor IS NULL THEN
		SET v_Vendor = '';
	END IF;
	IF v_Mhz IS NULL THEN
		SET v_Mhz = 0;
	END IF;
	IF v_CpuCnt IS NULL THEN
		SET v_CpuCnt = 0;
	END IF;
	
	SET v_SvrIp = REPLACE(v_SvrIp, '192.168.122.1','172.20.1.207'); -- fax
	SET v_SvrIp = REPLACE(v_SvrIp, '169.254.251.197','172.20.1.201'); -- rec
	
	
	IF NOT EXISTS(SELECT  '1' FROM  Mntng_Cpu_Info  WHERE Svr_Ip = v_SvrIp LIMIT 1) THEN
		INSERT INTO Mntng_Cpu_Info(Svr_Ip, Vendor, Model, Speed, Cpu_Cnt)
		VALUES(v_SvrIp, v_Vendor, v_Model, v_Mhz, v_CpuCnt);
	END IF;
	
	-- Host 명
	SELECT Host_Nm INTO v_Old_Host_Nm FROM Mntng_Svr WHERE Svr_Ip = v_SvrIp;
	IF (v_Old_Host_Nm <> v_Host_Nm) OR v_Old_Host_Nm IS NULL THEN
		UPDATE Mntng_Svr
		SET Host_Nm = v_Host_Nm
		WHERE Svr_Ip = v_SvrIp;
	END IF;
	
	INSERT INTO Mntng_Cpu_Hist(Svr_Ip, User_Qty, System_Qty, Idle_Qty)
	VALUES(v_SvrIp, v_CpuUser, v_CpuSystem, v_CpuIdle);
	
	-- 임계치 넘을경우 History저장
	SELECT Cpu_ThresHold INTO v_ThresHold FROM Mntng_Svr  WHERE Svr_Ip = v_SvrIp;
	IF ((IFNULL((v_CpuUser+v_CpuSystem)*100,0)) >= v_ThresHold) AND (v_ThresHold <> 0) THEN
		INSERT INTO Mntng_Cpu_ThresHold_Hist(Svr_Ip, User_Qty, System_Qty, Idle_Qty)
		VALUES(v_SvrIp, v_CpuUser, v_CpuSystem, v_CpuIdle);
		
		SELECT ThresHold_Cpu_Cnt INTO v_ThresHold_Cnt
		FROM mntng_svr
		WHERE Svr_Ip = v_SvrIp;
		SET v_ThresHold_Cnt = v_ThresHold_Cnt + 1;
	
		
	END IF;
	
	UPDATE mntng_svr
	SET ThresHold_Cpu_Cnt = v_ThresHold_Cnt
	WHERE Svr_Ip = v_SvrIp;
	
	
END;

