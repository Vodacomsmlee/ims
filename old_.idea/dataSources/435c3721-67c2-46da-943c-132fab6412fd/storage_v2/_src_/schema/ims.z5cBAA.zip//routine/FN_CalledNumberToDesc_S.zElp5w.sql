create
    definer = ims@`%` function FN_CalledNumberToDesc_S(v_CalledNumber varchar(20)) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   select   `Desc` INTO v_RETURN FROM Code_CalledNumber  WHERE CalledNumber = v_CalledNumber
   AND Del_Stat = 0;
   RETURN v_RETURN;
END;

