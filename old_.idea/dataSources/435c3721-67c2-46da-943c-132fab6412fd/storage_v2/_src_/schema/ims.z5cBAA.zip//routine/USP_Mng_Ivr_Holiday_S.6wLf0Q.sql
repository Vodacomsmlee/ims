create
    definer = ims@`%` procedure USP_Mng_Ivr_Holiday_S(IN v_hd_code int)
BEGIN
	SELECT HD_Seq
	, HD_Code
	, HD_Nm
	, DATE_FORMAT(HD_Date,'%Y-%m-%d') as HD_Date -- SUBSTRING(HD_Date,1,4)+'-'+SUBSTRING(HD_Date,5,2)+'-'+SUBSTRING(HD_Date,7,2)
	, CONCAT(SUBSTR(HD_TimeStart,1,2),':',SUBSTR(HD_TimeStart,3,2)) as HD_TimeStart
	, CONCAT(SUBSTR(HD_TimeEnd,1,2),':',SUBSTR(HD_TimeEnd,3,2)) as HD_TimeEnd
	, HD_AnuallyYN
	, HD_PromptYN
	, HD_Prompt
	, (CASE HD_PromptYN WHEN 0 THEN '' ELSE (SELECT SC_FILENAME FROM Mng_Ivr_Prompt  WHERE SC_PROMPT = HD_Prompt)
	END) HD_Prompt_Nm
	FROM Mng_Ivr_Holiday A 
	WHERE HD_Code = v_hd_code
	ORDER BY HD_Date;
END;

