create
    definer = ims@`%` procedure USP_QOS_Calc_IUD(IN v_nType int, IN v_LocalSubscriberNo varchar(15),
                                                 IN v_MacAddr varchar(12), IN v_Callid varchar(40),
                                                 IN v_protocolVersion int, IN v_Reason smallint,
                                                 IN v_StartTime datetime, IN v_EndTime datetime,
                                                 IN v_LocalIpAddr varchar(35), IN v_LocalRtpPort int,
                                                 IN v_RemoteIpAddr varchar(35), IN v_RemoteRtpPort int,
                                                 IN v_SsrcReceiving decimal(22), IN v_SsrcSending decimal(22),
                                                 IN v_Codec int, IN v_MediaType int, IN v_PayloadType int,
                                                 IN v_MaxPacketSize int, IN v_SilenceSuppression int,
                                                 IN v_GoodPackets decimal(22), IN v_MaxJitter int,
                                                 IN v_MaxInterJitter int, IN v_MaxJitterExceedPeriods int,
                                                 IN v_AvgRoundTripDelay int, IN v_AvgRoundTripDelayExceeded bit,
                                                 IN v_LostPackets int, IN v_DiscardedPackets int,
                                                 IN v_LostPacketsExceededPeriods int,
                                                 IN v_BA11consecutiveLostPackets varchar(25),
                                                 IN v_ConsecutivePacketLossExceedPeriods int,
                                                 IN v_BA11consecutiveGoodPackets varchar(25),
                                                 IN v_ConsecutiveGoodPacketsExceedPeriods int,
                                                 IN v_CntJitterBufferOverrun int, IN v_CntJitterBufferUnderrun int,
                                                 IN v_CodecChangedOnTheFly bit, IN v_TresholdExceededPeriods int,
                                                 IN v_rvalue float)
begin
	
	DECLARE v_recsvr VARCHAR(100);
			
	IF v_nType=1 THEN
		
			select value into v_recsvr from QOS_Config where name='recsvr';
			call FN_CMM_Split_S(v_recsvr,'|');
			IF v_RemoteIpAddr not in (select `VALUE` from FN_CMM_Split_S) THEN
			
				INSERT INTO QOS_Calc_Data 
				(LocalSubscriberNo,MacAddr,Callid,protocolVersion,Reason,StartTime,EndTime,LocalIpAddr,LocalRtpPort,RemoteIpAddr,RemoteRtpPort,
				SsrcReceiving,SsrcSending,Codec,MediaType,PayloadType,MaxPacketSize,SilenceSuppression,GoodPackets,MaxJitter,MaxInterJitter,MaxJitterExceedPeriods,
				AvgRoundTripDelay,AvgRoundTripDelayExceeded,LostPackets,DiscardedPackets,LostPacketsExceededPeriods,BA11consecutiveLostPackets,
				ConsecutivePacketLossExceedPeriods,BA11consecutiveGoodPackets,ConsecutiveGoodPacketsExceedPeriods,CntJitterBufferOverrun,CntJitterBufferUnderrun,
				CodecChangedOnTheFly,TresholdExceededPeriods,rvalue)
				VALUES 
				(v_LocalSubscriberNo,v_MacAddr,v_Callid,v_protocolVersion,v_Reason,v_StartTime,v_EndTime,v_LocalIpAddr,v_LocalRtpPort,v_RemoteIpAddr,v_RemoteRtpPort,
				v_SsrcReceiving,v_SsrcSending,v_Codec,v_MediaType,v_PayloadType,v_MaxPacketSize,v_SilenceSuppression,v_GoodPackets,v_MaxJitter,v_MaxInterJitter,v_MaxJitterExceedPeriods,
				v_AvgRoundTripDelay,v_AvgRoundTripDelayExceeded,v_LostPackets,v_DiscardedPackets,v_LostPacketsExceededPeriods,v_BA11consecutiveLostPackets,
				v_ConsecutivePacketLossExceedPeriods,v_BA11consecutiveGoodPackets,v_ConsecutiveGoodPacketsExceedPeriods,v_CntJitterBufferOverrun,v_CntJitterBufferUnderrun,
				v_CodecChangedOnTheFly,v_TresholdExceededPeriods,v_rvalue);
			end if;
		
	ELSEIF v_nType=2 THEN
		UPDATE QOS_Calc_Data set rvalue=v_rvalue WHERE LocalSubscriberNo=v_LocalSubscriberNo and MacAddr=v_MacAddr and Callid=v_Callid;
	ELSEIF v_nType=3 THEN
		DELETE FROM QOS_Calc_Data WHERE  LocalSubscriberNo=v_LocalSubscriberNo and MacAddr=v_MacAddr and Callid=v_Callid;
	ELSEIF v_nType=4 THEN
		UPDATE QOS_Calc_Data 
		set 
			protocolVersion=v_protocolVersion,
			Reason=v_Reason,
			StartTime=v_StartTime,
			EndTime=v_EndTime,
			LocalIpAddr=v_LocalIpAddr,
			LocalRtpPort=v_LocalRtpPort,
			RemoteIpAddr=v_RemoteIpAddr,
			RemoteRtpPort=v_RemoteRtpPort,
			SsrcReceiving=v_SsrcReceiving,
			SsrcSending=v_SsrcSending,
			Codec=v_Codec,
			MediaType=v_MediaType,
			PayloadType=v_PayloadType,
			MaxPacketSize=v_MaxPacketSize,
			SilenceSuppression=v_SilenceSuppression,
			GoodPackets=v_GoodPackets,
			MaxJitter=v_MaxJitter,
			MaxInterJitter=v_MaxInterJitter,
			MaxJitterExceedPeriods=v_MaxJitterExceedPeriods,
			AvgRoundTripDelay=v_AvgRoundTripDelay,
			AvgRoundTripDelayExceeded=v_AvgRoundTripDelayExceeded,
			LostPackets=v_LostPackets,
			DiscardedPackets=v_DiscardedPackets,
			LostPacketsExceededPeriods=v_LostPacketsExceededPeriods,
			BA11consecutiveLostPackets=v_BA11consecutiveLostPackets,
			ConsecutivePacketLossExceedPeriods=v_ConsecutivePacketLossExceedPeriods,
			BA11consecutiveGoodPackets=v_BA11consecutiveGoodPackets,
			ConsecutiveGoodPacketsExceedPeriods=v_ConsecutiveGoodPacketsExceedPeriods,
			CntJitterBufferOverrun=v_CntJitterBufferOverrun,
			CntJitterBufferUnderrun=v_CntJitterBufferUnderrun,
			CodecChangedOnTheFly=v_CodecChangedOnTheFly,
			TresholdExceededPeriods=v_TresholdExceededPeriods,
			rvalue=v_rvalue
		WHERE
			MacAddr=v_MacAddr and Callid=v_Callid; 
	end if;
end;

