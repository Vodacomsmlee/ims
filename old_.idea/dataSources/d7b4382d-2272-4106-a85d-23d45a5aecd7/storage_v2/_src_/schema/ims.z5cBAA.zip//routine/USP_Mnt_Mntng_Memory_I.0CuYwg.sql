create
    definer = ims@`%` procedure USP_Mnt_Mntng_Memory_I(IN v_MemTotal float, IN v_MemUsed float, IN v_MemFree float,
                                                       IN v_SvrIp varchar(15))
BEGIN
	DECLARE v_ThresHold FLOAT;
	DECLARE v_ThresHold_Cnt INT;
	SET v_ThresHold_Cnt = 0;
	
	IF v_MemTotal IS NULL THEN
		SET v_MemTotal = 0;
	END IF;
	
	IF v_MemUsed IS NULL THEN
		SET v_MemUsed = 0;
	END IF;
	IF v_MemFree IS NULL THEN
		SET v_MemFree = 0;
	END IF;
	
	IF v_MemUsed > v_MemTotal THEN
		SET v_MemUsed = v_MemTotal - v_MemFree;
	END IF;
	SET v_SvrIp = REPLACE(v_SvrIp, '192.168.122.1','172.20.1.207'); -- fax
	SET v_SvrIp = REPLACE(v_SvrIp, '169.254.251.197','172.20.1.201'); -- rec
	
	
	INSERT INTO Mntng_Memory_Hist(Svr_Ip, Total_Qty, Used_Qty, Use_Psbl_Qty)
	VALUES(v_SvrIp, v_MemTotal, v_MemUsed, v_MemFree);
	
	-- 임계치 넘을경우 History저장
	SELECT Memory_ThresHold INTO v_ThresHold FROM Mntng_Svr  WHERE Svr_Ip = v_SvrIp;
	IF (((v_MemUsed/v_MemTotal)*100) >= v_ThresHold) AND (v_ThresHold <> 0)  THEN
		INSERT INTO Mntng_Memory_ThresHold_Hist(Svr_Ip, Total_Qty, Used_Qty, Use_Psbl_Qty)
		VALUES(v_SvrIp, v_MemTotal, v_MemUsed, v_MemFree);
		
		SELECT ThresHold_Memory_Cnt INTO v_ThresHold_Cnt
		FROM mntng_svr
		WHERE Svr_Ip = v_SvrIp;
		
		SET v_ThresHold_Cnt = v_ThresHold_Cnt + 1;
	END IF;
	
	UPDATE mntng_svr
	SET ThresHold_Memory_Cnt = v_ThresHold_Cnt
	WHERE Svr_Ip = v_SvrIp;
END;

