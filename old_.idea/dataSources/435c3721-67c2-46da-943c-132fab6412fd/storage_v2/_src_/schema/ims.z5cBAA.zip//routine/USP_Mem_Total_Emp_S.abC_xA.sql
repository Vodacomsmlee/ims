create
    definer = ims@`%` procedure USP_Mem_Total_Emp_S()
BEGIN
	SELECT Emp_No, A.Organ_No, Emp_Nm, Agent_Key, A.Dept_No, Role_No, B.Team_Key, B.Dept_Nm
	, ims_ifx.FN_Get_UserID(Agent_Key) AS userid
	, RIGHT(ims_ifx.FN_Get_UserID(Agent_Key),4) as Extn_no 
	FROM Emp A 
	LEFT OUTER JOIN Dept B  ON A.Dept_No = B.Dept_No
	WHERE A.Del_Stat = 0;
END;

