create
    definer = ims@`%` procedure USP_Mnt_Mntng_Switch_Port_S(IN v_Svr_Seq int)
BEGIN
	SELECT A.Svr_Ip
	, A.Svr_Seq
	, B.Port_No
	, B.Port_Link
	, B.Port_State
	, B.Tx_Sec
	, B.Rx_Sec
	, B.Uptime
	, B.Reg_Dt
	FROM mntng_svr A
	LEFT OUTER JOIN mntng_switch_port B ON A.Svr_Seq = B.Svr_Seq
	WHERE A.Svr_Type = 1 -- 0:서버, 1:네트워크 스위치
	AND A.Svr_Seq = v_Svr_Seq
	AND A.Del_Stat = 0;
END;

