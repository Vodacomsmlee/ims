create
    definer = ims@`%` procedure USP_Hist_Rec_Listen_TotCnt_S(IN v_start int, IN v_length int,
                                                             IN v_listen_sdate varchar(10),
                                                             IN v_listen_edate varchar(10),
                                                             IN v_listen_userid varchar(20),
                                                             IN v_listen_usernm varchar(40), IN v_rec_sdate varchar(10),
                                                             IN v_rec_edate varchar(10), IN v_rec_userid varchar(20),
                                                             IN v_rec_usernm varchar(40))
BEGIN
	DECLARE v_SQL NATIONAL VARCHAR(4000);
	DECLARE v_WHERE NATIONAL VARCHAR(4000);
	IF v_start IS NULL THEN
		SET v_start = 0;
	END IF;
	IF v_length IS NULL THEN
		SET v_length = 15;
	END IF;
	IF v_listen_userid IS NULL THEN
		SET v_listen_userid = '';
	END IF;
	IF v_listen_usernm IS NULL THEN
		SET v_listen_usernm = '';
	END IF;
	IF v_rec_userid IS NULL THEN
		SET v_rec_userid = '';
	END IF;
	IF v_rec_usernm IS NULL THEN
		SET v_rec_usernm = '';
	END IF;
	IF IFNULL(v_listen_sdate,'') = '' THEN
		SET v_listen_sdate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	END IF;
	IF IFNULL(v_listen_edate,'') = '' THEN
		SET v_listen_edate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	END IF;
	SET v_WHERE = '';
	IF IFNULL(v_listen_sdate,'') <> '' AND IFNULL(v_listen_sdate,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(crymd, ''%Y-%m-%d'') >= ''',DATE_FORMAT(v_listen_sdate, '%Y-%m-%d'), ''' ');
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(crymd, ''%Y-%m-%d'') <= ''',DATE_FORMAT(v_listen_edate, '%Y-%m-%d'), ''' ');
	END IF;
	IF IFNULL(v_listen_userid,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND crsabun =''',v_listen_userid,''' ');
	END IF;
	IF IFNULL(v_listen_usernm,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND create_by =''',v_listen_usernm,''' ');
	END IF;
/*
	IF IFNULL(v_rec_sdate,'') <> '' AND IFNULL(v_rec_sdate,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(rec_datm, ''%Y-%m-%d'') >= ''',DATE_FORMAT(v_rec_sdate, '%Y-%m-%d'), ''' ');
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(rec_datm, ''%Y-%m-%d'') <= ''',DATE_FORMAT(v_rec_edate, '%Y-%m-%d'), ''' ');
	END IF;
	IF IFNULL(v_rec_userid,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND user_id =''',v_rec_userid,''' ');
	END IF;
	IF IFNULL(v_rec_usernm,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND user_name =''',v_rec_usernm,''' ');
	END IF;
*/
	-- 카운트
	SET v_SQL = CONCAT_WS('',' SELECT COUNT(1) TotRowCnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' FROM record.record_his ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' left join record.tbl_user B  ON listen_id = B.user_id  ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' WHERE 1 = 1 ');
	SET v_SQL = CONCAT_WS('', v_SQL, v_WHERE);
	
	SET @SWV_Stmt = v_SQL;
	PREPARE SWT_Stmt FROM @SWV_Stmt;
	EXECUTE SWT_Stmt;
	DEALLOCATE PREPARE SWT_Stmt;
	
END;

