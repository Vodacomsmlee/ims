create
    definer = ims@`%` procedure USP_Mng_CtiGroup_U(IN v_Group_Seq int, IN v_Dept_No int, IN v_Group_Nm varchar(100),
                                                   IN v_Group_Desc varchar(200), IN v_Group_Key int,
                                                   IN v_Emp_No varchar(4000))
BEGIN
	IF v_Group_Desc is null then
		set v_Group_Desc = '';
	END IF;
	UPDATE Mng_Cti_Group
	SET Dept_No = v_Dept_No
	,Group_Nm = v_Group_Nm
	-- 	, Group_Desc = @Group_Desc
	,Group_Key = v_Group_Key
	WHERE Group_Seq = v_Group_Seq;
END;

