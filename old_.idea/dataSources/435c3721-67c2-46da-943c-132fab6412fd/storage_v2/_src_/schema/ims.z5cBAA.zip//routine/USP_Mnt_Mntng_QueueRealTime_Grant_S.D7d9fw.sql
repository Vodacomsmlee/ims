create
    definer = ims@`%` procedure USP_Mnt_Mntng_QueueRealTime_Grant_S(IN v_Emp_No varchar(10))
BEGIN
	CALL FN_CMM_Grant_S(v_Emp_No,2);
	
	SELECT
	`date`, QueueKey, FN_QueueNm_S(QueueKey) QueueName, Contacts, OverflowedContacts
	, ROUND(ServiceLevel,2) ServiceLevel
	, ROUND(EstimatedServiceLevel,2) EstimatedServiceLevel
	,CONCAT(FORMAT(ROUND(AbandonedRate,2),2),'%') AbandonedRate
	,SEC_TO_TIME(OldestContactWaitTime) OldestContactWaitTime
	,SEC_TO_TIME(AverageAnsweredWaitTime) AverageAnsweredWaitTime
	,SEC_TO_TIME(EstimatedAnsweredWaitTime) EstimatedAnsweredWaitTime
	,SEC_TO_TIME(AverageAbandonedWaitTime) AverageAbandonedWaitTime
	FROM(
		SELECT
		`date`, QueueKey, Contacts, OverflowedContacts, ServiceLevel,
		EstimatedServiceLevel, AbandonedRate, OldestContactWaitTime,
		AverageAnsweredWaitTime, EstimatedAnsweredWaitTime, AverageAbandonedWaitTime
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueRealTime 
		WHERE QueueKey in(SELECT * FROM FN_CMM_Grant_S)
	) AS A_ROWS
	WHERE RN = 1;
END;

