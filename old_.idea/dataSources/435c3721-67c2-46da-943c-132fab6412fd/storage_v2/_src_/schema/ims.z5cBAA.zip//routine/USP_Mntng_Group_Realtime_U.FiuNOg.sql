create
    definer = ims@`%` procedure USP_Mntng_Group_Realtime_U(IN v_groupKey int, IN v_totalCallsWaiting smallint(5),
                                                           IN v_loggedOnUsers smallint(5), IN v_idleUsers smallint(5),
                                                           IN v_busyUsers smallint(5), IN v_awayUsers smallint(5),
                                                           IN v_usersHandlingDirectCalls smallint,
                                                           IN v_usersHandlingRoutedCalls smallint)
BEGIN
UPDATE `mntng_grouprealtime` SET
`date`=CURRENT_TIMESTAMP(6)
,`CallsWaiting`=v_totalCallsWaiting
,`LoggedOnUsers`=v_loggedOnUsers
,`IdleUsers`=v_idleUsers
,`BusyUsers`=v_busyUsers
,`AwayUsers`=v_awayUsers
,`HandlingDirectUsers`=v_usersHandlingDirectCalls
,`HandlingRoutedUsers`=v_usersHandlingRoutedCalls
WHERE
`GroupKey`=v_groupKey;
END;

