create
    definer = ims@`%` procedure USP_Mng_Ivr_Menu_I(IN v_SC_MENU int, IN v_SC_DIGIT varchar(10), IN v_SC_NEXT int,
                                                   IN v_SC_NEXTNAME int, IN v_SC_NOTI_YN int, IN v_SC_NOTI int)
BEGIN
	INSERT INTO Mng_Ivr_ScenarioMenuSub(SC_MENU
	,SC_DIGIT
	,SC_NEXT
	,SC_NEXTNAME
	,SC_NOTI_YN
	,SC_NOTI)
	VALUES(v_SC_MENU,v_SC_DIGIT,v_SC_NEXT,v_SC_NEXTNAME,v_SC_NOTI_YN, v_SC_NOTI);
	
END;

