create
    definer = ims@`%` procedure USP_Mntng_Queue_Cumulative_U(IN v_date datetime, IN v_queueKey int(10),
                                                             IN v_maximumWaitTime int(10), IN v_serviceLevel float,
                                                             IN v_averageWaitTime float, IN v_abandonedRate float,
                                                             IN v_redirectedOutOfScope int(10),
                                                             IN v_answeredContacts int(10),
                                                             IN v_abandonedContacts int(10),
                                                             IN v_receivedContacts int(10))
BEGIN
UPDATE `mntng_queuecumulative` SET
`MaximumWaitTime`=v_maximumWaitTime
,`ServiceLevel`=v_serviceLevel
,`AverageWaitTime`=v_averageWaitTime
,`AbandonedRate`=v_abandonedRate
,`Redirected`=v_redirectedOutOfScope
,`Answered`=v_answeredContacts
,`Abandoned`=v_abandonedContacts
,`Received`=v_receivedContacts
WHERE
`date`=v_date AND `QueueKey`=v_queueKey;
END;

