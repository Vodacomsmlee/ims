create
    definer = ims@`%` procedure USP_Mntng_Group_Realtime_All_D()
BEGIN
TRUNCATE TABLE `mntng_grouprealtime`;
END;

