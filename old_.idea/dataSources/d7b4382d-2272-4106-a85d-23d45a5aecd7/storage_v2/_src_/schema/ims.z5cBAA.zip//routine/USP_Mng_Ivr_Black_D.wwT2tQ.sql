create
    definer = ims@`%` procedure USP_Mng_Ivr_Black_D(IN v_BL_SEQUENCE int)
BEGIN
	delete from ims.mng_ivr_blacklist
	where BL_SEQUENCE = v_BL_SEQUENCE;
	
END;

