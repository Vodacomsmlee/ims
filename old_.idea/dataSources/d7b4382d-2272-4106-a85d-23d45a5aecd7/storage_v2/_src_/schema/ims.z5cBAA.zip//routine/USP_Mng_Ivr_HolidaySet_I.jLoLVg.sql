create
    definer = ims@`%` procedure USP_Mng_Ivr_HolidaySet_I(IN v_HD_Code_Nm varchar(70), IN v_Dept_No int)
BEGIN
	INSERT INTO Mng_Ivr_HolidaySet(HD_Code_Nm, Dept_No)
	VALUES(v_HD_Code_Nm, v_Dept_No);
END;

