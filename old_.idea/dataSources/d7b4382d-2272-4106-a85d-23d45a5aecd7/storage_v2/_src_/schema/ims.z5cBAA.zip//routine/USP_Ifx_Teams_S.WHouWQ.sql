create
    definer = ims@`%` procedure USP_Ifx_Teams_S()
BEGIN
	SELECT teamkey, teamname
	FROM ims_ifx.teams
	ORDER BY teamkey;
END;

