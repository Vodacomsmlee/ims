create
    definer = ims@`%` procedure USP_Ifx_Calltype_S()
BEGIN
	SELECT calltypekey, calltypename
	FROM ims_ifx.calltypes
	WHERE calltypekey > 5 ORDER BY calltypekey;
END;

