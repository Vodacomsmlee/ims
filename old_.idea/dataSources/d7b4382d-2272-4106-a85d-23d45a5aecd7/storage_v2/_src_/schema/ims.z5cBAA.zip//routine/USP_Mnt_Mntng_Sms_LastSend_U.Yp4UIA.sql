create
    definer = ims@`%` procedure USP_Mnt_Mntng_Sms_LastSend_U(IN v_Svr_Ip varchar(15), IN v_ThresHold_Type varchar(10))
BEGIN
	IF v_ThresHold_Type = 'CPU' THEN
		UPDATE mntng_svr
		SET Last_Sms_SendDt = CURRENT_TIMESTAMP(3)
		, ThresHold_Cpu_Cnt = 0
		WHERE Svr_Ip = v_Svr_Ip;
	END IF;
	
	IF v_ThresHold_Type = 'MEM' THEN
		UPDATE mntng_svr
		SET Last_Sms_SendDt = CURRENT_TIMESTAMP(3)
		, ThresHold_Memory_Cnt = 0
		WHERE Svr_Ip = v_Svr_Ip;
	END IF;
	
	IF v_ThresHold_Type = 'PING' THEN
		UPDATE mntng_svr
		SET Last_Sms_SendDt = CURRENT_TIMESTAMP(3)
		, ThresHold_Cnt = 0
		WHERE Svr_Ip = v_Svr_Ip;
	END IF;
END;

