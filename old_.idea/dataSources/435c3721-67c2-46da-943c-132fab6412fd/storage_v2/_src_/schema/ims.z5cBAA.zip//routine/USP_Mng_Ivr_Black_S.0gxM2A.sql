create
    definer = ims@`%` procedure USP_Mng_Ivr_Black_S()
BEGIN
	
	SELECT
		BL_SEQUENCE
		, BL_TELNO
		, BL_DESC
		, concat(BL_DATETIME,'') as BL_DATETIME
	FROM ims.mng_ivr_blacklist
	order by BL_SEQUENCE desc;
	
END;

