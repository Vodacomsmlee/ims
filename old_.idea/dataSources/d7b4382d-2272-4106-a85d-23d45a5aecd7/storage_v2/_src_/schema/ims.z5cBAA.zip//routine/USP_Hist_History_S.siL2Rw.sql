create
    definer = ims@`%` procedure USP_Hist_History_S(IN v_start int, IN v_length int, IN v_SearchText varchar(100))
BEGIN
	-- 전체 Row Count
	IF v_start is null then
		set v_start = 0;
	END IF;
	IF v_length is null then
		set v_length = 15;
	END IF;
	IF v_SearchText is null then
		set v_SearchText = '';
	END IF;
	SELECT COUNT(1) TotRowCnt FROM History;
	-- 검색후 Row Count
	IF v_SearchText <> '' then
		SELECT COUNT(1) SearchRowCnt
		FROM History 
		WHERE Procedure_Nm LIKE CONCAT_WS('','%',v_SearchText,'%');
	ELSE
		SELECT COUNT(1) SearchRowCnt FROM History;
	end if;
	-- Data Row
	SELECT  Seq
	, Procedure_Nm
	, B.Emp_Nm
	, DATE_FORMAT(Reg_Dt,'%Y-%m-%d %T:%f') Reg_Dt
	, Parameter
	FROM History A 
	LEFT OUTER JOIN Emp B ON A.Emp_No = B.Emp_No
	ORDER BY Reg_Dt DESC
	LIMIT v_length OFFSET v_start;
	
END;

