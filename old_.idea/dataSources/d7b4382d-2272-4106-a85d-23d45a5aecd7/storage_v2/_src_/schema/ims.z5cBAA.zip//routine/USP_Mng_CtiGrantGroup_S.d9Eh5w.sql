create
    definer = ims@`%` procedure USP_Mng_CtiGrantGroup_S(IN v__Emp_No varchar(10))
BEGIN
	CALL FN_CMM_Grant_S(v__Emp_No,1);
	SELECT Group_Seq, A.Dept_No, B.Dept_Nm, A.Group_Nm, Group_Desc, Group_Key
	FROM Mng_Cti_Group A 
	LEFT OUTER JOIN Dept B  ON A.Dept_No = B.Dept_No AND B.Del_Stat = 0
	WHERE A.Del_Stat = 0
	and A.Dept_No IN(SELECT * FROM FN_CMM_Grant_S);
	
END;

