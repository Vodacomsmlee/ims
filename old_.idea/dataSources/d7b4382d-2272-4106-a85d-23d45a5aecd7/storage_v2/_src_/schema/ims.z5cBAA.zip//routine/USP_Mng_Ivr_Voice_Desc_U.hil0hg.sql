create
    definer = ims@`%` procedure USP_Mng_Ivr_Voice_Desc_U(IN v_svcSeq int, IN v__EMP_NO varchar(30),
                                                         IN v_svcInfo varchar(4000), IN v_FILE_NAME varchar(200))
BEGIN
	UPDATE Mng_Ivr_Prompt
	SET SC_DESCRIPTION = v_svcInfo
	,SC_REGUSER = v__EMP_NO
	,SC_FILENAME = v_FILE_NAME
	,SC_REGDate = SYSDATE(3)
	WHERE SEQ = v_svcSeq;
END;

