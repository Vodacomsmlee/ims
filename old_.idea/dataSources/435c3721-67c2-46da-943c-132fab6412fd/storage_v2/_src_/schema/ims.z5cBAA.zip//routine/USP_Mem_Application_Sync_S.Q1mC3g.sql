create
    definer = ims@`%` procedure USP_Mem_Application_Sync_S(IN v_Emp_No varchar(10))
BEGIN
	DECLARE v_Dept_No INT;
	DECLARE v_Path_Dept_Code VARCHAR(1000);
	DECLARE v_Dept_1 VARCHAR(10);
	DECLARE v_Dept_2 VARCHAR(10);
	DECLARE v_Dept_3 VARCHAR(10);
	SELECT Dept_No INTO v_Dept_No FROM emp WHERE Emp_No = v_Emp_No;
		
	-- SET v_Dept_No = 8;
	
	DROP TEMPORARY TABLE IF EXISTS tt_Emp_Dept;
	CREATE TEMPORARY TABLE tt_Emp_Dept
	(
		Dept_No INT,
		Dept_Nm VARCHAR(50), 
		High_Dept_No INT, 
		Lvl INT, 
		Path_Code VARCHAR(1000),
		Path_Dept_Nm VARCHAR(1000)
	); 
	INSERT INTO tt_Emp_Dept(Dept_No, Dept_Nm, High_Dept_No, Lvl, Path_Code, Path_Dept_Nm)
	WITH RECURSIVE CTE(Dept_No, Dept_Nm, High_Dept_No, Lvl, Path_Code, Path_Dept_Nm)
	AS(
		SELECT Dept_No, Dept_Nm, High_Dept_No, 1 AS Lvl
		, CAST(Dept_No AS CHAR(10)) AS Path_Code
		, CAST(Dept_Nm AS CHAR(50)) AS Path_Dept_Nm
		FROM Dept 
		WHERE High_Dept_No IS NULL
		AND Del_Stat = 0
		
		UNION ALL
		
		SELECT C.Dept_No, C.Dept_Nm, C.High_Dept_No, Lvl + 1 AS Lvl
		, CONCAT(Path_Code,'/',CAST(C.Dept_No AS CHAR(10))) AS Path_Code
		, CONCAT(Path_Dept_Nm,'/',CAST(C.Dept_Nm AS CHAR(50))) AS Path_Dept_Nm
		FROM Dept C 
		INNER JOIN CTE CCte ON C.High_Dept_No = CCte.Dept_No
		WHERE Del_Stat = 0
	)
	SELECT Dept_No, Dept_Nm, High_Dept_No, Lvl, Path_Code, Path_Dept_Nm
	FROM CTE
	WHERE Dept_No = v_Dept_No;
	
	
	SELECT Path_Code INTO v_Path_Dept_Code FROM tt_Emp_Dept;
	CALL FN_CMM_Split_S(v_Path_Dept_Code, '/');
	
	SET @num:=0;
	
	SELECT `value` INTO v_Dept_1
	FROM ( SELECT @num:=@num+1 AS rownum, `value` FROM FN_CMM_Split_S ) A
	WHERE rownum = 1;	
	
	SET @num:=0;
	SELECT `VALUE` INTO v_Dept_2
	FROM ( SELECT @num:=@num+1 AS rownum, `value` FROM FN_CMM_Split_S ) A
	WHERE rownum = 2;	
	
	SET @num:=0;
	SELECT `VALUE` INTO v_Dept_3
	FROM ( SELECT @num:=@num+1 AS rownum, `value` FROM FN_CMM_Split_S ) A
	WHERE rownum = 3;
/*
1) 등록 : {procType : "C", cs_id : "사번", cs_name : "상담원명", cti_id:"cti id", cn_code : "센터", tm_code : "팀", pt_code : "파트(조)", indate : "입사일자"}
2) 수정 : {procType : "U", cs_id : "사번", cs_name : "상담원명", cti_id:"cti id", cn_code : "센터", tm_code : "팀", pt_code : "파트(조)"}        
3) 삭제 : {procType : "D", cs_id : "사번", outdate : "퇴사일자"} 
*/
	SELECT A.Emp_No AS cs_id
	, A.organ_no
	, A.Emp_Nm AS cs_name
	, IFNULL(ims.FN_Get_UserID(Agent_Key),'') AS cti_id
	, IFNULL(v_Dept_1,'') AS cn_code
	, IFNULL(v_Dept_2,'') AS tm_code
	, IFNULL(v_Dept_3,'') AS pt_code
	, DATE_FORMAT(NOW(), '%Y-%m-%d') AS indate
	, A.Role_No
	, (case when B.CCAPP_Admin_Stat = 1 then '02' else '04' end) as Admin_Stat
	FROM emp A
	JOIN `role` B ON A.Role_No = B.Role_No
	WHERE A.Emp_No = v_Emp_No;
	
/*
	DECLARE v_grp_nms VARCHAR(4000);
	DECLARE v_grp_cds VARCHAR(4000);
	-- SET @Emp_No = '2018001'
	DECLARE v_SEQ INT;
	DECLARE v_MAXSEQ INT;
	DECLARE SWV_grp_cds_Str VARCHAR(4000);
	DECLARE SWV_grp_nms_Str VARCHAR(4000);
	
	-- DECLARE @Emp_No VARCHAR(10)
	DROP TEMPORARY TABLE IF EXISTS tt_GROUP_T;
	CREATE TEMPORARY TABLE tt_GROUP_T
	(
		SEQ INT   AUTO_INCREMENT PRIMARY KEY, 
		Group_Seq INT, 
		Group_Nm VARCHAR(100)
	)  AUTO_INCREMENT = 1;
	
	INSERT INTO tt_GROUP_T(Group_Seq, Group_Nm)
	SELECT  A.Group_Seq, B.Group_Nm
	FROM Mng_Cti_Group_Emp A 
	JOIN Mng_Cti_Group B  ON A.Group_Seq = B.Group_Seq
	WHERE A.Emp_No = v_Emp_No
	ORDER BY A.Group_Seq;
	
	SET v_SEQ = 1;
	
	select MAX(SEQ) INTO v_MAXSEQ FROM tt_GROUP_T;
	
	SET v_grp_cds = '';
	SET v_grp_nms = '';
	
	WHILE v_SEQ <= v_MAXSEQ DO
		SET v_grp_cds = CONCAT_WS('',v_grp_cds,',',(SELECT CAST(Group_Seq AS CHAR(30)) FROM tt_GROUP_T WHERE SEQ = v_SEQ));
		SET v_grp_nms = CONCAT_WS('',v_grp_nms,',',(SELECT Group_Nm FROM tt_GROUP_T WHERE SEQ = v_SEQ));
		SET v_SEQ = v_SEQ+1;
	END WHILE;
	
	SET SWV_grp_cds_Str = SUBSTRING(v_grp_cds,2,LENGTH(v_grp_cds));
	SET v_grp_cds = SWV_grp_cds_Str;
	SET SWV_grp_nms_Str = SUBSTRING(v_grp_nms,2,LENGTH(v_grp_nms));
	SET v_grp_nms = SWV_grp_nms_Str;
	
	SELECT
	RTRIM(LTRIM(ims_ifx.FN_Get_UserID(A.Agent_Key))) user_id
	, Emp_Nm emp_nm
	, B.Dept_Nm dept_nm
	, B.Dept_No dept_cd
	, A.Emp_No agent_emp_no
	, v_grp_nms grp_nms
	, v_grp_cds grp_cds
	, (CASE
			WHEN A.Role_No = 1 THEN 'SM'
			WHEN C.CCAPP_Admin_Stat = 1 THEN 'CM'
			-- WHEN Role_No = 2 THEN 'C'
			ELSE 'C' END
	) emp_auth
	FROM Emp A 
	JOIN Dept B  ON A.Dept_No = B.Dept_No
	JOIN Role C  ON A.Role_No = C.Role_No
	WHERE Emp_No = v_Emp_No;
*/
END;

