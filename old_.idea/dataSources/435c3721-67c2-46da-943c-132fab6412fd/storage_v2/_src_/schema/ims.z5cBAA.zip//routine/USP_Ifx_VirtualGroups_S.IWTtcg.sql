create
    definer = ims@`%` procedure USP_Ifx_VirtualGroups_S()
BEGIN
	SELECT virtualgroupkey, virtualgroupname
	FROM ims_ifx.virtualgroups
	ORDER BY virtualgroupkey;
END;

