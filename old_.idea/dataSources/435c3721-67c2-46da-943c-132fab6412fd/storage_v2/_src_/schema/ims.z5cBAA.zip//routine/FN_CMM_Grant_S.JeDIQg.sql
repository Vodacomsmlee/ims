create
    definer = ims@`%` procedure FN_CMM_Grant_S(IN v_Emp_No varchar(10), IN v_Grant_Type tinyint unsigned)
BEGIN
	DECLARE v_Role_No INT;
	Declare v_Dept_No INT;
	
	declare v_SYS_CODE VARCHAR(10);
	
	select Role_No, Dept_No into v_Role_No, v_Dept_No from ims.Emp WHERE Emp_No = v_Emp_No;
	select Dept_Desc INTO v_SYS_CODE FROM ims.Dept WHERE Dept_No = v_Dept_No;
   
	DROP TEMPORARY TABLE IF EXISTS FN_CMM_Grant_S;
	CREATE TEMPORARY TABLE IF NOT EXISTS FN_CMM_Grant_S
	( 
		`VALUE` VARCHAR(50) 
	);
   
	IF v_Grant_Type = 1 then -- Dept
		INSERT INTO FN_CMM_Grant_S
		SELECT Dept_No -- A.Team_Key Dept_No
		FROM Dept A 
		JOIN Role_Emp_Grant B  ON A.Dept_No = B.Grant_Type_Seq
		WHERE B.Emp_No = v_Emp_No
		AND B.Grant_Type = 1
		AND B.Del_Stat = 0
		AND Dept_No IS NOT NULL; -- A.Team_Key IS NOT NULL;
	
	ELSE IF v_Grant_Type = 2 then -- Queue
			INSERT INTO FN_CMM_Grant_S
			SELECT A.Que_Code Que_Key
			FROM Code_Queue A
			JOIN Role_Emp_Grant B  ON A.Seq = B.Grant_Type_Seq
			WHERE B.Emp_No = v_Emp_No
			AND B.Grant_Type = 2
			AND B.Del_Stat = 0;
			
	ELSE
			IF v_Grant_Type = 3 then -- CalledNumber key
				INSERT INTO FN_CMM_Grant_S
				SELECT A.Called_Key Called_Key
				FROM Code_CalledNumber A
				JOIN Role_Emp_Grant B  ON A.Seq = B.Grant_Type_Seq
				WHERE B.Emp_No = v_Emp_No
				AND B.Grant_Type = 3
				AND B.Del_Stat = 0;
				
			ELSE
				IF v_Grant_Type = 4 then -- OSSS.teams.teamname
					INSERT INTO FN_CMM_Grant_S
					SELECT Dept_Nm
					FROM Dept B
					JOIN Role_Emp_Grant C  ON B.Dept_No = C.Grant_Type_Seq
					WHERE C.Emp_No = v_Emp_No
					AND C.Grant_Type = 1
					AND B.Del_Stat = 0
					AND B.Dept_Nm IS NOT NULL;
				ELSE
					IF v_Grant_Type = 5 then -- CalledNumber
			
						INSERT INTO FN_CMM_Grant_S
						SELECT A.CalledNumber CalledNumber
						FROM Code_CalledNumber A
						JOIN Role_Emp_Grant B  ON A.Seq = B.Grant_Type_Seq
						WHERE B.Emp_No = v_Emp_No
						AND B.Grant_Type = 3
						AND B.Del_Stat = 0;
					ELSE
						IF v_Grant_Type = 6 then -- Dept_No
			
							INSERT INTO FN_CMM_Grant_S
							SELECT B.Grant_Type_Seq as Dept_No
							FROM Role_Emp_Grant B
							WHERE B.Emp_No = v_Emp_No
							AND B.Grant_Type = 1
							AND B.Del_Stat = 0;
						end if;
					end if;
				end if;
			end if;
		end if;
	end if;
   -- SELECT * FROM FN_CMM_Grant_S;
   
   
	-- v_Role_No 에 따라 부서 추가한다.
	
	-- v_Role_No 슈퍼관리자는 모든 부서를 조회한다.
	if v_Role_No = 1 THEN
	
		INSERT INTO FN_CMM_Grant_S
		select Dept_No 
		FROM ims.Dept A
		where Not exists (select `VALUE` from FN_CMM_Grant_S where `VALUE` = A.Dept_No);
	
	else
		
		-- 01, 02 속한 센터만 조회한다. 
		IF v_Role_No = 3 THEN
		
			INSERT INTO FN_CMM_Grant_S
			SELECT Dept_No 
			FROM ims.Dept A
			WHERE NOT EXISTS (SELECT `VALUE` FROM FN_CMM_Grant_S WHERE `VALUE` = A.Dept_No)
			AND Dept_Desc = v_SYS_CODE;
			
		else
			 
			-- 그외는 모두 상담원 권한으로 처리한다. 03, 11, 자기 부서만
			IF v_Role_No in (2, 6) THEN
			
				INSERT INTO FN_CMM_Grant_S
				select `VALUE` from FN_CMM_Grant_S
				union all
				SELECT Dept_No FROM ims.Dept WHERE  Dept_No = v_Dept_No;
				
			END IF; 
		end if;
	end if;
	
END;

