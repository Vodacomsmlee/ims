create
    definer = ims@`%` procedure USP_Mng_Ivr_Route_D(IN v_RT_ROUTE int)
BEGIN
   UPDATE Mng_Ivr_ScenarioRoute
   SET Del_Stat = 1
   WHERE RT_ROUTE = v_RT_ROUTE;
END;

