create
    definer = ims@`%` procedure USP_Mng_CtiHuntGroup_Initial_S()
BEGIN
	-- Initial 헌트 그룹
	SELECT resourcename, resourcenum, resourceproperty FROM ims_ifx.Resources WHERE resourcetype = 5 AND resourceproperty <> '' ORDER BY resourcenum;
END;

