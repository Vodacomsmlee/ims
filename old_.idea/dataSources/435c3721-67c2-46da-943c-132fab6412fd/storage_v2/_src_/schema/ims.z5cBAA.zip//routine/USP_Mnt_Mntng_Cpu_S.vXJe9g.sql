create
    definer = ims@`%` procedure USP_Mnt_Mntng_Cpu_S(IN v_Svr_Ip varchar(15), IN v_Top int)
BEGIN
	DECLARE v_Last_Cpu_Use INT;
	DECLARE v_Today_Max_Cpu_Use INT;
	DECLARE v_Today_Min_Cpu_Use INT;
	-- 최종 모니터링 데이타
	IF v_Top is null then
		set v_Top = 100;
	END IF;
	
	select(User_Qty+System_Qty)*100 INTO v_Last_Cpu_Use 
	FROM Mntng_Cpu_Hist  
	WHERE Svr_Ip = v_Svr_Ip
	ORDER BY Reg_Dt DESC 
	LIMIT 1;
	-- 금일 모니터링 데이타
	-- CPU
	select MAX((User_Qty+System_Qty)*100), MIN((User_Qty+System_Qty)*100) INTO v_Today_Max_Cpu_Use,v_Today_Min_Cpu_Use 
	FROM Mntng_Cpu_Hist
	WHERE Reg_Dt >= DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
	AND Svr_Ip = v_Svr_Ip;
	
	
	SELECT `Timestamp`, UseData, IFNULL(v_Last_Cpu_Use,0) Last_Cpu_Use, IFNULL(v_Today_Max_Cpu_Use,0) Today_Max_Cpu_Use, IFNULL(v_Today_Min_Cpu_Use,0) Today_Min_Cpu_Use
	FROM
		(
		SELECT 
		TIMESTAMPADD(HOUR,9,Reg_Dt) as `Timestamp`  -- UTC 시간대 +9 
		,(User_Qty+System_Qty)*100 UseData
		, Reg_Dt
		FROM Mntng_Cpu_Hist 
		WHERE Svr_Ip = v_Svr_Ip
		ORDER BY Reg_Dt DESC
		) A
	ORDER BY Reg_Dt ASC;
	
END;

