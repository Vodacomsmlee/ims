create
    definer = ims@`%` procedure USP_Mntng_Group_Realtime_I(IN v_groupKey int, IN v_totalCallsWaiting smallint(5),
                                                           IN v_loggedOnUsers smallint(5), IN v_idleUsers smallint(5),
                                                           IN v_busyUsers smallint(5), IN v_awayUsers smallint(5),
                                                           IN v_usersHandlingDirectCalls smallint,
                                                           IN v_usersHandlingRoutedCalls smallint)
BEGIN
INSERT INTO `mntng_grouprealtime`(
`date`
,`GroupKey`
,`CallsWaiting`
,`LoggedOnUsers`
,`IdleUsers`
,`BusyUsers`
,`AwayUsers`
,`HandlingDirectUsers`
,`HandlingRoutedUsers`)
VALUES(CURRENT_TIMESTAMP(6)
,v_groupKey
,v_totalCallsWaiting
,v_loggedOnUsers
,v_idleUsers
,v_busyUsers
,v_awayUsers
,v_usersHandlingDirectCalls
,v_usersHandlingRoutedCalls);
END;

