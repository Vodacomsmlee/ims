create
    definer = ims@`%` procedure USP_Mnt_Mntng_ProcHist_S(IN v_Svr_Ip varchar(15))
BEGIN
	SELECT A.Seq
	, A.Svr_Ip
	, C.Svr_Desc
	, A.Process_Nm
	, A.Process_Cnt
	, B.Run_Process_Cnt
	, (CASE
			WHEN B.Run_Process_Cnt = A.Process_Cnt THEN 1
			WHEN (B.Run_Process_Cnt < A.Process_Cnt) AND B.Run_Process_Cnt <> 0 THEN 2
			WHEN (B.Run_Process_Cnt > A.Process_Cnt) THEN 2
			ELSE 0
		END) AS Run_Status
	, B.Risk_Dt
	, B.Reg_Dt
	, (CASE WHEN TIMESTAMPDIFF(SECOND,B.Reg_Dt,CURRENT_TIMESTAMP) > 150 THEN -1 ELSE 0 END) AS SvrChk  -- 최종 등록일이 현재시간보다 150초이상 차이나면 문제있음
	-- , -1 AS SvrChk  -- 최종 등록일이 현재시간보다 150초이상 차이나면 문제있음
	FROM Mntng_Process A
	JOIN ims.mntng_svr C ON A.Svr_Ip = C.Svr_Ip
	LEFT OUTER JOIN Mntng_Process_Hist B  ON A.Seq = B.Process_Seq
	WHERE A.Del_Stat = 0
	AND A.Svr_Ip = v_Svr_Ip;
END;

