create
    definer = ims@`%` procedure USP_Mng_CtiQueueTarget_S()
BEGIN
	select 
	resourcename
	, resourcenum
	, (CASE WHEN resourcetype = 4 THEN 'Yes' ELSE 'No' END) as requeue
	from ims_ifx.Resources
	where resourcetype IN(4,26);
	
END;

