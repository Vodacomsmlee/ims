create
    definer = ims@`%` procedure USP_Mnt_Mntng_TrunkStatus_Hist()
BEGIN
	-- 집계 히스토리 저장
	INSERT INTO Mntng_TrunkStatus_Hist
	SELECT DATE_FORMAT(`DATE`,'%Y-%m-%d %T') AS Dt
	, CODE
	, MAX(BUSY) AS BUSY
	, MAX(TOTAL) AS TOTAL
	FROM Mntng_TrunkStatus 
	WHERE DATE_FORMAT(`DATE`,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(DAY,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
	GROUP BY DATE_FORMAT(`DATE`,'%Y-%m-%d %T'),CODE
	ORDER BY DATE_FORMAT(`DATE`,'%Y-%m-%d %T'),CODE;
	-- 데이타 삭제
	DELETE FROM Mntng_TrunkStatus WHERE DATE_FORMAT(`DATE`,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(DAY,-1,CURRENT_TIMESTAMP),'%Y-%m-%d');
	
END;

