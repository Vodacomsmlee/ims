create
    definer = ims@`%` function FN_QueDivToHighDeptNo_S(v_Que_Code int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
	   
	SELECT A.High_Dept_No INTO v_RETURN
	FROM ims.dept A
	JOIN ims.code_dept_que B ON A.Dept_No = B.Dept_No
	JOIN ims.code_queue C ON B.Que_Code = C.Que_Code
	WHERE C.Que_Div = v_Que_Code
	GROUP BY A.High_Dept_No;
	SET v_RETURN = IFNULL(v_RETURN,'');
	RETURN v_RETURN;
END;

