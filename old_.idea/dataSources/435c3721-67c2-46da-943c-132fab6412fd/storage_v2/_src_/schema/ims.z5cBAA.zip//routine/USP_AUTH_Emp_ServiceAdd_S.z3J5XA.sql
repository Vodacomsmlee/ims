create
    definer = ims@`%` procedure USP_AUTH_Emp_ServiceAdd_S(IN v_Emp_No varchar(10))
BEGIN
	IF v_Emp_No is null then
		set v_Emp_No = '';
	END IF;
	
	select Emp_No INTO v_Emp_No FROM Emp  WHERE Emp_No = v_Emp_No; 
	IF v_Emp_No <> '' then
		-- 서비스 //기본Role에 권한이 있으면 disabled 처리해야한다.
		CREATE TEMPORARY TABLE tt_RoleSvc AS SELECT Svc_No FROM Role_Dtl WHERE Role_No =(SELECT Role_No FROM Emp  WHERE Emp_No = v_Emp_No);
		SELECT A.Svc_No
		, Svc_Nm
		, Svc_Url
		, (CASE WHEN IFNULL(B.Del_Stat,1) = 1 THEN '' ELSE REPLACE(DATE_FORMAT(B.Reg_Dt,'%Y-%m-%d %T:%f'),'1900-01-01 00:00:00','') END) Reg_Dt
		, (CASE WHEN IFNULL(B.Del_Stat,1) = 1 THEN '' ELSE ' checked' END) CHK
		, (CASE WHEN C.Svc_No IS NULL THEN '' ELSE 'disabled' END) Disabled_Stat
		FROM Role_Service A 
		LEFT OUTER JOIN Role_Emp_Service B  ON A.Svc_No = B.Svc_No AND B.Del_Stat = 0 AND Emp_No = v_Emp_No
		LEFT OUTER JOIN tt_RoleSvc C ON A.Svc_No = C.Svc_No
		WHERE A.Del_Stat = 0;
		DROP TEMPORARY Table IF EXISTS tt_RoleSvc;
		-- 부서
		SELECT A.Dept_No
		, A.Dept_Nm
		, (CASE WHEN IFNULL(B.Emp_No,'') = '' THEN '' ELSE ' checked' END) CHK
		FROM Dept A 
		LEFT OUTER JOIN Role_Emp_Grant B  ON A.Dept_No = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 1
		WHERE A.Del_Stat = 0;
		
		-- Queue
		SELECT A.Seq
		, A.Que_Nm
		, (CASE WHEN IFNULL(B.Emp_No,'') = '' THEN '' ELSE ' checked' END) CHK
		FROM Code_Queue A 
		LEFT OUTER JOIN Role_Emp_Grant B  ON A.Seq = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 2
		WHERE A.Del_Stat = 0
		AND A.Use_Stat = 0;
		-- CalledNumber
		SELECT A.Seq
		, A.CalledNumber
		, A.`Desc`
		, (CASE WHEN IFNULL(B.Emp_No,'') = '' THEN '' ELSE ' checked' END) CHK
		FROM Code_CalledNumber A 
		LEFT OUTER JOIN Role_Emp_Grant B  ON A.Seq = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 3
		WHERE A.Del_Stat = 0
		AND A.Use_Stat = 0;
   end if;
END;

