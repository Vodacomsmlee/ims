create
    definer = ims@`%` procedure USP_Mnt_Mntng_QueueCumulative_Rate_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	CALL FN_CMM_Grant_S(v__Emp_No,2);
	
	SELECT
	SUM(Answered) as Answered, SUM(Received) as Received, SUM(Abandoned) as Abandoned, SUM(Redirected) as Redirected
	,FORMAT(ROUND(sum(Answered)*100.0/NULLIF(sum(Received), 0),2),2) as AnswerRate
	,FORMAT(ROUND(sum(Abandoned)*100.0/NULLIF(sum(Received), 0),2),2) as AbandoneRate
	FROM(
		SELECT
		`date`, QueueKey, MaximumWaitTime,ServiceLevel,AverageWaitTime,AbandonedRate
		,Redirected,Answered,Abandoned,Received
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueCumulative
		WHERE QueueKey in(SELECT * FROM FN_CMM_Grant_S)
		and `date` > CURDATE()
	) AS A_ROWS
	WHERE RN = 1;
END;

