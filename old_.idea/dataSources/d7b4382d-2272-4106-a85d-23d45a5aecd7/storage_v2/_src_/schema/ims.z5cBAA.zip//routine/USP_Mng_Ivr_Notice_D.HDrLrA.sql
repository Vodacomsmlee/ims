create
    definer = ims@`%` procedure USP_Mng_Ivr_Notice_D(IN v_NT_Code int)
BEGIN
	UPDATE Mng_Ivr_Notice 
	SET Del_Stat = 1
	WHERE NT_Code = v_NT_Code;
END;

