create
    definer = ims@`%` procedure USP_Mng_Record_Cnt_S(IN v_sdate datetime, IN v_edate datetime, IN v_stime varchar(10),
                                                     IN v_etime varchar(10), IN v_userid varchar(20),
                                                     IN v_usernm varchar(40), IN v_slocalno varchar(15),
                                                     IN v_elocalno varchar(15), IN v_stalk int, IN v_etalk int,
                                                     IN v_tel varchar(20), IN v_inout varchar(2),
                                                     IN v__EMP_NO varchar(20))
BEGIN
	DECLARE v_Agent_Key INT;
	DECLARE v_Role_No INT; 
	DECLARE v_Dept_No INT;
	DECLARE v_Front_Stat INT;
	DECLARE v_SEQ INT;
	DECLARE v_MAXSEQ INT;
	DECLARE v_strUsrID VARCHAR(4000);
	DECLARE v_COMMA VARCHAR(5);
	DECLARE v_SQL VARCHAR(4000);
	IF v_stalk IS NULL THEN
		SET v_stalk = 0;
	END IF;
	
	IF v_etalk IS NULL THEN
		SET v_etalk = 60;
	END IF;
	
	IF v__EMP_NO IS NULL THEN
		SET v__EMP_NO = '';
	END IF;
	
	IF v_sdate IS NULL OR v_sdate = '1900-01-01' THEN
		SET v_sdate = CURRENT_TIMESTAMP;
	END IF;
	
	IF v_edate IS NULL OR v_edate = '1900-01-01' THEN
		SET v_edate = CURRENT_TIMESTAMP;
	END IF;
	
	SELECT Agent_Key, Role_No, Dept_No INTO v_Agent_Key, v_Role_No, v_Dept_No FROM ims.Emp WHERE Emp_No = v__EMP_NO;
	
	
	DROP TEMPORARY TABLE IF EXISTS tt_GrantEmp;
	CREATE TEMPORARY TABLE tt_GrantEmp
	(
		SEQ INT   AUTO_INCREMENT PRIMARY KEY, 
		USER_ID VARCHAR(20)
	)  AUTO_INCREMENT = 1;
	CALL FN_CMM_Grant_S(v__EMP_NO,1);
	
	IF v_Role_No IN(1, 3) THEN
		INSERT INTO tt_GrantEmp(USER_ID)
		SELECT A.Emp_No -- ims_ifx.FN_Get_UserID(Agent_Key) AS userid
		FROM Emp A 
		LEFT OUTER JOIN Dept B ON A.Dept_No = B.Dept_No
		WHERE B.Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
		AND A.Del_Stat = 0
		AND A.Agent_Key IS NOT NULL;
	ELSE
		INSERT INTO tt_GrantEmp(USER_ID)
		SELECT Emp_No -- ims_ifx.FN_Get_UserID(Agent_Key) AS userid
		FROM Emp 
		WHERE Emp_No = v__EMP_NO
		AND Agent_Key IS NOT NULL;
		
	END IF;
	
	SELECT GROUP_CONCAT(USER_ID) INTO v_strUsrID FROM tt_GrantEmp;
	
	SET v_stime = CONCAT('0',REPLACE(v_stime,':',''));
	SET v_stime = CONCAT_WS('',v_stime,'00');
	SET v_stime = RIGHT(v_stime, 6);
	SET v_etime = CONCAT('0',REPLACE(v_etime,':',''));
	SET v_etime = CONCAT_WS('',v_etime,'59');
	SET v_etime = RIGHT(v_etime, 6);
	
	SET v_SQL = CONCAT_WS('', v_SQL, 'SELECT COUNT(1) TotRowCnt');
	SET v_SQL = CONCAT_WS('', v_SQL, '	FROM record.crec_recfile ');
	SET v_SQL = CONCAT_WS('', v_SQL, '	WHERE 1 = 1 ');
	SET v_SQL = CONCAT_WS('', v_SQL, '	AND DATE_FORMAT(REC_DATE,''%Y-%m-%d'') >= ', 'DATE_FORMAT(''',v_sdate,''',''%Y-%m-%d'')');
	SET v_SQL = CONCAT_WS('', v_SQL, '	AND DATE_FORMAT(REC_DATE,''%Y-%m-%d'') <= ', 'DATE_FORMAT(''',v_edate,''',''%Y-%m-%d'')');
	SET v_SQL = CONCAT_WS('', v_SQL, '	AND REC_STIME >= ''', v_stime,''' ');
	SET v_SQL = CONCAT_WS('', v_SQL, '	AND REC_ETIME <= ''', v_etime,''' ');
	SET v_SQL = CONCAT_WS('', v_SQL, '	AND REC_ENDTIME >= ', v_stalk,'');
	SET v_SQL = CONCAT_WS('', v_SQL, '	AND REC_ENDTIME <= ', v_etalk,'');
	
	
	-- 권한
	-- SET v_SQL = CONCAT_ws('',v_SQL, ' AND user_id IN(',v_strUsrID,')');
	-- SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_USER_ID IN(',v_strUsrID,')');-- select USER_ID from tt_GrantEmp)');
	SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_USER_ID IN(select USER_ID from tt_GrantEmp)');
	
	IF IFNULL(v_userid,'') <> '' THEN
		SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_USER_ID = ''' ,v_userid, '''');
	END IF;
	
	IF IFNULL(v_usernm,'') <> '' THEN	
		SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_USER_NAME = ''' ,v_usernm, '''');
	END IF;
	
	IF IFNULL(v_slocalno,'') <> '' AND IFNULL(v_elocalno,'') <> '' THEN
		SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_LOCAL_PHONE >= ''' ,v_slocalno, '''');
		SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_LOCAL_PHONE <= ''' ,v_elocalno, '''');
	ELSE 
		IF IFNULL(v_slocalno,'') <> '' THEN
			SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_LOCAL_PHONE = ''' ,v_slocalno, '''');
		END IF;
   END IF;
   
	IF IFNULL(v_tel,'') <> '' THEN
		SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_CUST_PHONE1 LIKE ''%' ,v_tel, '%'' ');
	END IF;
	
	IF IFNULL(v_inout,'') <> '' THEN
		SET v_SQL = CONCAT_WS('',v_SQL, ' AND REC_INOUT = ''' ,v_inout, '''');
	END IF;
	
	
	SET @SWV_Stmt = v_SQL;
	PREPARE SWT_Stmt FROM @SWV_Stmt;
	EXECUTE SWT_Stmt;
	DEALLOCATE PREPARE SWT_Stmt;
END;

