create
    definer = ims@`%` procedure USP_Mntng_OSCCREST_Token_U(IN v_srvname varchar(30), IN v_token varchar(70))
BEGIN
UPDATE `mntng_oscctoken` SET
`token`=v_token
WHERE
`Srvname`=v_srvname;
END;

