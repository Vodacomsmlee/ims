create
    definer = ims@`%` procedure USP_Mng_Ivr_Holiday_D(IN v_HD_Seq int)
BEGIN
   DELETE FROM Mng_Ivr_Holiday
   WHERE HD_Seq = v_HD_Seq;
END;

