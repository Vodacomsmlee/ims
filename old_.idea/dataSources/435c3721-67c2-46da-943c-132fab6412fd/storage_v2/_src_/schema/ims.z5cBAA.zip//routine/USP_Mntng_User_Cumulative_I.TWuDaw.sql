create
    definer = ims@`%` procedure USP_Mntng_User_Cumulative_I(IN v_date datetime, IN v_userKey int,
                                                            IN v_utilization float, IN v_offered int(10),
                                                            IN v_handled int(10), IN v_abandonedWhileRinging int(10),
                                                            IN v_unhandledRouted int(10),
                                                            IN v_undeliveredRouted int(10), IN v_routedHeld int(10),
                                                            IN v_routedConsulted int(10),
                                                            IN v_routedTransferred int(10), IN v_totalLogonTime int(10),
                                                            IN v_ringingTime int(10), IN v_totalPendingTime int(10),
                                                            IN v_handlingTime int(10), IN v_totalOtherTime int(10),
                                                            IN v_maximumRoutedHandlingTime int(10),
                                                            IN v_totalRoutedTalkTime int(10),
                                                            IN v_totalRoutedHoldTime int(10),
                                                            IN v_disconnectedRoutedCalls int(10), IN v_requeue int(10),
                                                            IN v_totalPostProcessingTime int(10),
                                                            IN v_totalIdleTime int(10), IN v_totalAwayTime int(10),
                                                            IN v_totalBusyTime int(10))
BEGIN
INSERT INTO mntng_usercumulative(
`date`
,`UserKey`
,`Department`
,`Utilization`
,`Offered`
,`Handled`
,`AbandonedWhileRinging`
,`Unhandled`
,`RoutedHeld`
,`ConsultedOut`
,`TransferredOut`
,`TotalLoggedOnTime`
,`TotalRingTime`
,`TotalPendingTime`
,`TotalHandledTime`
,`TotalTimeOther`
,`MaximumRoutedHandlingTime`
,`TotalTalkTime`
,`TotalHoldTime`
,`Disconnected`
,`Requeued`
,`TotalPostProcessingTime`
,`TotalIdleTime`
,`TotalAwayTime`
,`TotalBusyTime`)
VALUES(v_date
,v_userKey
,FN_Get_UserKeyToDeptNo(v_userKey)
,v_utilization
,v_offered
,v_handled
,v_abandonedWhileRinging
,(v_unhandledRouted+v_undeliveredRouted)
,v_routedHeld
,v_routedConsulted
,v_routedTransferred
,v_totalLogonTime
,v_ringingTime
,v_totalPendingTime
,v_handlingTime
,v_totalOtherTime
,v_maximumRoutedHandlingTime
,v_totalRoutedTalkTime
,v_totalRoutedHoldTime
,v_disconnectedRoutedCalls
,v_requeue
,v_totalPostProcessingTime
,v_totalIdleTime
,v_totalAwayTime
,v_totalBusyTime);
END;

