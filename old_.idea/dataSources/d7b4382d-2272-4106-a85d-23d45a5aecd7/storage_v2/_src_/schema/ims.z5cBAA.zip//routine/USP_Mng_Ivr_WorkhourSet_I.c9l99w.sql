create
    definer = ims@`%` procedure USP_Mng_Ivr_WorkhourSet_I(IN v_WH_Code_Nm varchar(70), IN v_Dept_No int, IN v_HD_Code int)
BEGIN
	if v_HD_Code = -1 then 
		set v_HD_Code = null;
	end if;
	INSERT INTO Mng_Ivr_WorkhourSet(WH_Code_Nm, Dept_No, HD_Code)
	VALUES(v_WH_Code_Nm,v_Dept_No, v_HD_Code);
	
END;

