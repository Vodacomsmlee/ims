create
    definer = ims@`%` procedure USP_Mntng_Cumulative_MAX_before_15m_S()
BEGIN
SELECT (MAX(`date`)-INTERVAL 15 MINUTE) AS `date` FROM
`mntng_usercumulative`;
END;

