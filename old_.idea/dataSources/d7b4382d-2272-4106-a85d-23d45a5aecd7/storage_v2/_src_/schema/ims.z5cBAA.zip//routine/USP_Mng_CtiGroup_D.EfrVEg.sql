create
    definer = ims@`%` procedure USP_Mng_CtiGroup_D(IN v_Group_Seq int)
BEGIN
	UPDATE Mng_Cti_Group
	SET Del_Stat = 1
	WHERE Group_Seq = v_Group_Seq;
END;

