create
    definer = ims@`%` procedure USP_Test_Mir()
BEGIN
DROP TEMPORARY TABLE IF EXISTS tmp_data;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_data
( 
	Seq INT NOT NULL AUTO_INCREMENT
  , Svc_No INT
  , Svc_Nm VARCHAR(100)
  , Svc_Nm_Depth VARCHAR(500)
  , Svc_Url VARCHAR(200)
  , MenuID INT
  , Role_No VARCHAR(50)
  , Role_Nm VARCHAR(200)
  , Chk VARCHAR(50)
  , PRIMARY KEY (`Seq`)
  , KEY ix_Svc_No(Svc_No)
);
INSERT INTO tmp_data(Svc_No, Svc_Nm, Svc_Nm_Depth, Svc_Url, MenuID, Role_No, Role_Nm, Chk)
SELECT Svc_No
, Svc_Nm	
, CONCAT((CASE 
		WHEN MenuID LIKE '_000' THEN '' 
		WHEN MenuID LIKE '__00' THEN '└─' 
		WHEN MenuID IS NULL THEN '' 			
		ELSE '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└──' END) 
		,' ',Svc_Nm) AS Svc_Nm_Depth
, IFNULL(Svc_Url,'') Svc_Url
, MenuID
, GROUP_CONCAT(B.Role_No ORDER BY B.Role_No) AS Role_No
, GROUP_CONCAT(B.Role_Nm ORDER BY B.Role_No) AS Role_Nm
, GROUP_CONCAT( 
				(
					CASE WHEN EXISTS(SELECT role_No FROM Role_Dtl WHERE ROLE_NO = B.Role_No AND SVC_NO = A.SVC_NO)
					THEN 1
					ELSE 0 END
				) 
				ORDER BY B.Role_No 
) AS chk
FROM Role_Service A
LEFT OUTER JOIN `role` B ON 1=1
WHERE a.Del_Stat = 0 AND B.del_stat = 0
GROUP BY svc_no
ORDER BY MenuID;
SELECT Role_No, Role_Nm INTO @role_no, @role_nm  FROM tmp_data limit 1;
CALL FN_CMM_Split_S(@role_no, ',');
SELECT GROUP_CONCAT(CONCAT('`',`value`,'_value`', ' varchar(50)')) INTO @dynamic_col2 FROM FN_CMM_Split_S;
SET @sql = 'DROP TEMPORARY TABLE IF EXISTS temp_dynamic;';
PREPARE SWT_Stmt FROM @sql;
EXECUTE SWT_Stmt;
DEALLOCATE PREPARE SWT_Stmt;
SET @sql = 'CREATE TEMPORARY TABLE IF NOT EXISTS temp_dynamic ( svc_no int, ';
SET @sql = CONCAT(@sql, @dynamic_col2, ' , KEY ix_Svc_No(svc_no) );');
PREPARE SWT_Stmt FROM @sql;
EXECUTE SWT_Stmt;
DEALLOCATE PREPARE SWT_Stmt;
SET @Seq = 1;
SELECT MAX(Seq) INTO @max FROM tmp_data;
WHILE @Seq <= @max DO
	SELECT chk, svc_no INTO @chk, @svc_no FROM tmp_data WHERE Seq = @Seq;
	
	
	set @sql = 'insert into temp_dynamic ';
	set @sql = concat(@sql, 'select ', @svc_no ,', ', @chk);
	PREPARE SWT_Stmt FROM @sql;
	EXECUTE SWT_Stmt;
	DEALLOCATE PREPARE SWT_Stmt;
	
	SET @Seq = @seq + 1;
END WHILE;
select A.Svc_No, A.Svc_Nm, A.Svc_Nm_Depth, A.Svc_Url, A.MenuID-- , A.Role_No, A.Role_Nm, A.Chk
, B.*
from tmp_data A
JOIN temp_dynamic B on A.Svc_No = B.Svc_No;
DROP TEMPORARY TABLE IF EXISTS FN_CMM_Split_S;
DROP TEMPORARY TABLE IF EXISTS tmp_data;
DROP TEMPORARY TABLE IF EXISTS temp_dynamic;
END;

