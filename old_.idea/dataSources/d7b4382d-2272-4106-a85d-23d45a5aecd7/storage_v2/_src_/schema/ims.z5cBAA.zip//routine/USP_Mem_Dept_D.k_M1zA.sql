create
    definer = ims@`%` procedure USP_Mem_Dept_D(IN v_Dept_No int, IN v_Emp_No varchar(10))
BEGIN 
	DECLARE v_teamkey INT;
	select Team_Key INTO v_teamkey FROM Dept WHERE Dept_No = v_Dept_No;
	IF NOT EXISTS(SELECT teamkey FROM ims_ifx.teams WHERE teamkey = v_teamkey LIMIT 1) then
	
		UPDATE Dept
		SET Del_Stat = 1
		WHERE Dept_No = v_Dept_No;
		-- EXEC ('DELETE FROM teams WHERE teamkey ='+@teamkey) AT OSCC
	  
		DELETE FROM ims_ifx.teams WHERE teamkey = v_teamkey;
		
		
		-- 상담원 app 동기화
		UPDATE ypctidb.tb_team
		SET DEL_YN = 'Y'
		, MODIFY_ID = v_Emp_No
		, MODIFYDATE = NOW(3)
		WHERE TEAMCODE = v_Dept_No;
		
		
	end if;
END;

