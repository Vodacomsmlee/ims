create
    definer = ims@`%` procedure USP_Mem_Dept_Nm_S(IN v_Dept_No int)
BEGIN 
   SELECT Dept_Nm, Team_Key
   FROM Dept 
   WHERE Dept_No = v_Dept_No;
END;

