create
    definer = ims@`%` procedure USP_Mnt_Mntng_Proc_S(IN v_Svr_Ip varchar(15))
BEGIN
	SELECT Seq
	, Process_Nm
	, Process_Cnt
	FROM Mntng_Process 
	WHERE Svr_Ip = v_Svr_Ip
	AND Del_Stat = 0;
END;

