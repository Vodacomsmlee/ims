create
    definer = ims@`%` procedure USP_Stt_IVR_CallbackStat_S(IN v_destinations varchar(4000),
                                                           IN v_Srch_Type tinyint unsigned, IN v_Start_Dt datetime,
                                                           IN v_End_Dt datetime)
BEGIN
	IF v_Srch_Type is null then
		set v_Srch_Type = 0;
	END IF;
	IF v_Srch_Type IS NULL then
		SET v_Srch_Type = 0;
	end if;
	call FN_CMM_Split_S(v_destinations,'|');
	
	IF v_Srch_Type = 0 then -- 월별
		SELECT
			DT
			, CB_DNIS
			, FN_CalledNumberToDesc_S(CB_DNIS) as DNIS_NAME
			, GROUP_SEQ
			, IFNULL(FN_CtiGroup_Nm_S(Group_Seq),'') as SERVICE_NAME,
			COUNT(*) REQCB_CNT,
			SUM(CASE WHEN CB_RST = 1 THEN CB_RST ELSE 0 END) RSTCB_CNT,
			-- RSTRATE=ISNULL(STR(ROUND(COUNT(*)*100.0/SUM(CASE WHEN CB_RST=1 THEN CB_RST ELSE 0 END),2),6,2),'0.00') -- CHECK DIVISION ZERO
			IFNULL(FORMAT(ROUND(SUM(CASE WHEN CB_RST = 1 THEN CB_RST ELSE 0 END)*100.0/COUNT(*),2),2),'0.00') as RSTRATE -- CHECK DIVISION ZERO
		FROM(
			select
				DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m') as DT
				, CB_DNIS
				, Group_Seq
				, (CASE WHEN CB.CB_AGENTID IS NOT NULL  THEN 1 ELSE 0 END) as CB_RST -- NEED EDIT
			from Mng_Ivr_Callback cb 
			LEFT OUTER JOIN TB_IVRSTATISTICS stt ON cb.CB_CALLID = stt.CALLID
			where cb.CB_CALLID is not null
			AND CB_DNIS IN(SELECT `VALUE` FROM FN_CMM_Split_S)
			-- AND CB_CALLBACKDATETIME >= @Start_Dt
			AND CB_CALLBACKDATETIME >= CONCAT(DATE_FORMAT(v_Start_Dt,'%Y-%m-%d'),'-01') -- Index 태우기 위해 날짜를 만들어준다.
			-- AND CONVERT(CHAR(10), DATEADD(HOUR, 9, CB_CALLBACKDATETIME), 121) <= CONVERT(CHAR(10), @End_Dt, 121)
			AND DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m') <= DATE_FORMAT(LAST_DAY(v_End_Dt),'%Y-%m-%d')
		) AS CB
		GROUP BY DT,CB_DNIS,Group_Seq;
	end if;
	IF v_Srch_Type = 1 then -- 일별
		SELECT
			DT
			, CB_DNIS
			, FN_CalledNumberToDesc_S(CB_DNIS) as DNIS_NAME
			, GROUP_SEQ
			, IFNULL(FN_CtiGroup_Nm_S(Group_Seq),'') as SERVICE_NAME
			, COUNT(1) as REQCB_CNT
			, SUM(CASE WHEN CB_RST = 1 THEN CB_RST ELSE 0 END) as RSTCB_CNT
			, IFNULL(FORMAT(ROUND(SUM(CASE WHEN CB_RST = 1 THEN CB_RST ELSE 0 END)*100.0/COUNT(1),2),2),'0.00') as RSTRATE -- CHECK DIVISION ZERO
		FROM(
			select
				DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d') as DT
				, CB_DNIS
				, Group_Seq
				, (CASE WHEN CB.CB_AGENTID IS NOT NULL THEN 1 ELSE 0 END) as CB_RST -- NEED EDIT
				from Mng_Ivr_Callback cb 
				LEFT OUTER JOIN  TB_IVRSTATISTICS stt ON  cb.CB_CALLID = stt.CALLID
				where cb.CB_CALLID is not null
				AND CB_DNIS IN(SELECT `VALUE` FROM FN_CMM_Split_S)
				-- AND CB_CALLBACKDATETIME >= @Start_Dt
				-- AND CONVERT(CHAR(10), DATEADD(HOUR, 9, CB_CALLBACKDATETIME), 121) <= CONVERT(CHAR(10), @End_Dt, 121)
				AND CB_CALLBACKDATETIME >= DATE_FORMAT(v_Start_Dt,'%Y-%m-%d') -- Index 태우기 위해 날짜를 만들어준다.
				AND DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d') <= DATE_FORMAT(v_End_Dt,'%Y-%m-%d')
		) AS CB
		GROUP BY DT,CB_DNIS,Group_Seq;
	end if;
	IF v_Srch_Type = 2 THEN -- 시간별
		SELECT
			DT
			, CB_DNIS
			, FN_CalledNumberToDesc_S(CB_DNIS) AS DNIS_NAME
			, GROUP_SEQ
			, IFNULL(FN_CtiGroup_Nm_S(Group_Seq),'') AS SERVICE_NAME
			, COUNT(1) AS REQCB_CNT
			, SUM(CASE WHEN CB_RST = 1 THEN CB_RST ELSE 0 END) AS RSTCB_CNT
			, IFNULL(FORMAT(ROUND(SUM(CASE WHEN CB_RST = 1 THEN CB_RST ELSE 0 END)*100.0/COUNT(1),2),2),'0.00') AS RSTRATE -- CHECK DIVISION ZERO
		FROM(
			SELECT
				DATE_FORMAT(CB_CALLBACKDATETIME,'%H') AS DT
				, CB_DNIS
				, Group_Seq
				, (CASE WHEN CB.CB_AGENTID IS NOT NULL THEN 1 ELSE 0 END) AS CB_RST -- NEED EDIT
				FROM Mng_Ivr_Callback cb 
				LEFT OUTER JOIN  TB_IVRSTATISTICS stt ON  cb.CB_CALLID = stt.CALLID
				WHERE cb.CB_CALLID IS NOT NULL
				AND CB_DNIS IN(SELECT `VALUE` FROM FN_CMM_Split_S)
				AND CB_CALLBACKDATETIME >= DATE_FORMAT(v_Start_Dt,'%Y-%m-%d') -- Index 태우기 위해 날짜를 만들어준다.
				AND DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d') <= DATE_FORMAT(v_End_Dt,'%Y-%m-%d')
		) AS CB
		GROUP BY DT,CB_DNIS,Group_Seq;
	END IF;
END;

