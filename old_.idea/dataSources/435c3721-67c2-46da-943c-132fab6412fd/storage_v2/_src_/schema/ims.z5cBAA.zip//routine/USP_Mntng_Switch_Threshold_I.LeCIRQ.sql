create
    definer = ims@`%` procedure USP_Mntng_Switch_Threshold_I(IN v_Svr_Seq int, IN v_Svr_Status int)
BEGIN
DECLARE v_ThresHold_Cnt INT;
IF v_Svr_Status = 0 THEN
	SELECT ThresHold_Cnt INTO v_ThresHold_Cnt
	FROM mntng_svr
	WHERE Svr_Seq = v_Svr_Seq;
	
	SET v_ThresHold_Cnt = v_ThresHold_Cnt + 1;
	
	UPDATE mntng_svr
	SET ThresHold_Cnt = v_ThresHold_Cnt
	WHERE Svr_Seq = v_Svr_Seq;
ELSE
	UPDATE mntng_svr
	SET ThresHold_Cnt = 0
	WHERE Svr_Seq = v_Svr_Seq;
END IF;
END;

