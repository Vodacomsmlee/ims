create
    definer = ims@`%` procedure USP_AUTH_Emp_ServiceAdd_RoleSvc_S(IN v_Emp_No varchar(10))
BEGIN
	IF v_Emp_No IS NULL THEN
		SET v_Emp_No = '';
	END IF;
	
	SELECT Emp_No INTO v_Emp_No FROM Emp  WHERE Emp_No = v_Emp_No; 
	IF v_Emp_No <> '' THEN
		-- 서비스 //기본Role에 권한이 있으면 disabled 처리해야한다.
		CREATE TEMPORARY TABLE tt_RoleSvc AS SELECT Svc_No FROM Role_Dtl WHERE Role_No =(SELECT Role_No FROM Emp  WHERE Emp_No = v_Emp_No);
		SELECT A.Svc_No
		, Svc_Nm
        , CONCAT((CASE
                      WHEN MenuID LIKE '_000' THEN ''
                      WHEN MenuID LIKE '__00' THEN '└─'
                      WHEN MenuID IS NULL THEN ''
                      ELSE '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└──' END)
            ,' ', A.Svc_Nm) AS Svc_Nm_Depth
		, Svc_Url
		, (CASE WHEN IFNULL(B.Del_Stat,1) = 1 THEN '' ELSE REPLACE(DATE_FORMAT(B.Reg_Dt,'%Y-%m-%d %T:%f'),'1900-01-01 00:00:00','') END) Reg_Dt
		, (CASE WHEN IFNULL(B.Del_Stat,1) = 1 THEN '' ELSE 'checked' END) CHK
		, (CASE WHEN C.Svc_No IS NULL THEN '' ELSE 'disabled' END) Disabled_Stat
		FROM Role_Service A 
		LEFT OUTER JOIN Role_Emp_Service B  ON A.Svc_No = B.Svc_No AND B.Del_Stat = 0 AND Emp_No = v_Emp_No
		LEFT OUTER JOIN tt_RoleSvc C ON A.Svc_No = C.Svc_No
		WHERE A.Del_Stat = 0
        ORDER BY MenuID;
		DROP TEMPORARY TABLE IF EXISTS tt_RoleSvc;
   END IF;
END;

