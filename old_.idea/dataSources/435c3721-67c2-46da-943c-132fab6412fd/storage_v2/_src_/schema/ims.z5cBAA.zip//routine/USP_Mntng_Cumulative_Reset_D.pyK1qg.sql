create
    definer = ims@`%` procedure USP_Mntng_Cumulative_Reset_D()
BEGIN
TRUNCATE TABLE `mntng_usercumulative`;
TRUNCATE TABLE `mntng_queuecumulative`;
TRUNCATE TABLE `mntng_groupcumulative`;
TRUNCATE TABLE `mntng_aggregatecumulative`;
END;

