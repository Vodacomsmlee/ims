create
    definer = ims@`%` procedure USP_Mnt_Mntng_System_Maintenance_D()
BEGIN
   DELETE FROM Mntng_Cpu_Hist WHERE Reg_Dt < SYSDATE(3);
   DELETE FROM Mntng_Memory_Hist WHERE Reg_Dt < SYSDATE(3);
   DELETE FROM Mntng_Network_Hist WHERE Reg_Dt < SYSDATE(3);
   delete from mntng_gateway_hist where reg_dt < TIMESTAMPADD(DAY, -1, SYSDATE());
   delete from mntng_usercumulative where `date` < TIMESTAMPADD(MONTH, -1, SYSDATE());
END;

