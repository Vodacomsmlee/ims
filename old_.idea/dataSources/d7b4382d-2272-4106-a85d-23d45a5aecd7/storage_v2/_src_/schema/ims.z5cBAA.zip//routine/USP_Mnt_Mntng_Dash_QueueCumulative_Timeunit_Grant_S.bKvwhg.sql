create
    definer = ims@`%` procedure USP_Mnt_Mntng_Dash_QueueCumulative_Timeunit_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	call FN_CMM_Grant_S(v__Emp_No,2);
	
	with CTE
	AS(
		SELECT DATE_FORMAT(`date`,'%Y-%m-%d %H') as DT
		, MAX(Received) as Received
		, QueueKey
		, MAX(Answered) as Answered
		, MAX(Abandoned) as Abandoned
		, MAX(Redirected) as Redirected
		FROM Mntng_QueueCumulative 
		WHERE QueueKey IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
		AND `date` > DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
		GROUP BY DATE_FORMAT(`date`,'%Y-%m-%d %H'), QueueKey
	)
	SELECT
	DT
	, cast(RIGHT(DT,2) as SIGNED INTEGER) TimeUnit
	, SUM(PrevReceived) as CntReceived
	, SUM(PrevAnswered) as CntAnswered
	, SUM(PrevAbandoned) as CntAbandoned
	, SUM(PrevRedirected) as CntRedirected
	FROM(
		SELECT
		DT
		, Received - IFNULL(LEAD(Received) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) as PrevReceived
		, Answered - IFNULL(LEAD(Answered) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) as PrevAnswered
		, Abandoned - IFNULL(LEAD(Abandoned) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) as PrevAbandoned
		, Redirected - IFNULL(LEAD(Redirected) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) as PrevRedirected
		FROM CTE
		) B
	GROUP BY DT
	ORDER BY DT;
END;

