create
    definer = ims@`%` procedure USP_Cmm_SsoChk_S(IN v_empno varchar(10), IN v_key varchar(100))
BEGIN
	IF EXISTS(SELECT Emp_No FROM Emp WHERE Emp_No = v_empno AND Auth_Key = v_key AND Del_Stat = 0 LIMIT 1) then
		
		SELECT Emp_No
		, Emp_Nm
		, IFNULL(CAST(Agent_Key AS CHAR(30)),'') Agent_Key
		, IFNULL(CAST(Dept_No AS CHAR(30)),'') Dept_No
		, DATE_FORMAT(Last_PassWd_Edit_Dt,'%Y-%m-%d %T:%f') Last_PassWd_Edit_Dt
		FROM Emp 
		WHERE Emp_No = v_empno
		AND Auth_Key = v_key
		AND Del_Stat = 0;
		UPDATE Emp
		SET Auth_Key = ''
		WHERE Emp_No = v_empno AND Auth_Key = v_key
		AND Del_Stat = 0;
      
	end if;
END;

