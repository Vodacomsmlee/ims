create
    definer = ims@`%` procedure USP_Mng_Ivr_DNIS_U(IN v_DNIS_CODE int, IN v_DNIS_NAME varchar(50),
                                                   IN v_DNIS_NUMBER varchar(20), IN v_DNIS_SERVICE varchar(20),
                                                   IN v_DNIS_SC_CODE int)
BEGIN
   UPDATE Mng_Ivr_DNIS
   SET DNIS_NAME = v_DNIS_NAME
   ,DNIS_NUMBER = v_DNIS_NUMBER
   ,DNIS_SERVICE = v_DNIS_SERVICE
   ,DNIS_SC_CODE = v_DNIS_SC_CODE
   WHERE DNIS_CODE = v_DNIS_CODE;
END;

