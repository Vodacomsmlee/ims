create
    definer = ims@`%` procedure USP_Mntng_Wallbarod_Notice_S()
BEGIN	SELECT
		Notice	FROM(		SELECT			Notice			,ROW_NUMBER() OVER(ORDER BY Reg_Dt DESC) AS RN		FROM Mntng_Wallboard_Notice	) AS A_ROWS	WHERE RN = 1;END;

