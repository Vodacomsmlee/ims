create
    definer = ims@`%` procedure USP_QOS_Subscribers_S()
BEGIN
	
	SELECT LocalSubscriberNo 
	FROM QOS_CALC_DATA 
	WHERE LocalSubscriberNo <> ''
	GROUP BY LocalSubscriberNo 
	ORDER BY LocalSubscriberNo;
END;

