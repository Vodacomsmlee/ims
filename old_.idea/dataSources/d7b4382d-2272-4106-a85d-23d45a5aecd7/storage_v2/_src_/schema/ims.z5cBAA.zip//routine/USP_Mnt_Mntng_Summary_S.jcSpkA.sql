create
    definer = ims@`%` procedure USP_Mnt_Mntng_Summary_S()
BEGIN
	SELECT X.Svr_Ip
	, IFNULL(Y.Cpu,0) Cpu
	, IFNULL(Y.Memory,0) Memory
	, IFNULL(Y.NetworkRx,0) NetworkRx
	, IFNULL(Y.NetworkTx,0) NetworkTx
	, IFNULL(Y.Run_Status,0) Run_Status
	, Run_StatusChk
	FROM Mntng_Svr X 
	LEFT OUTER JOIN(
					SELECT
						A.Svr_Ip
						, (
							SELECT IFNULL((User_Qty+System_Qty)*100,0) AS Last_Cpu_Use
							FROM Mntng_Cpu_Hist 
							WHERE Svr_Ip =  IFNULL(A.Svr_Ip,'')
							ORDER BY Reg_Dt DESC LIMIT 1
						) AS Cpu
						, (
							SELECT IFNULL(ROUND(((Total_Qty -Use_Psbl_Qty)/Total_Qty)*100,2),0) AS Last_Mem_Use
							FROM Mntng_Memory_Hist 
							WHERE Svr_Ip =  IFNULL(A.Svr_Ip,'')
							ORDER BY Reg_Dt DESC LIMIT 1
						) AS Memory
						, (
							SELECT  IFNULL(Rx*8,0) AS Last_Rx_Use-- (Rx * 0.000122)
							FROM Mntng_Network_Hist 
							WHERE Svr_Ip =  IFNULL(A.Svr_Ip,'')
							ORDER BY Reg_Dt DESC LIMIT 1
						) AS NetworkRx
						, (
							SELECT  IFNULL(Tx*8,0) AS Last_Tx_Use-- (Tx * 0.000122)
							FROM Mntng_Network_Hist 
							WHERE Svr_Ip =  IFNULL(A.Svr_Ip,'')
							ORDER BY Reg_Dt DESC LIMIT 1
						) AS NetworkTx
						, (CASE
								WHEN SUM(Y.Run_Process_Cnt) = SUM(X.Process_Cnt) THEN 1
								WHEN (SUM(Y.Run_Process_Cnt) < SUM(X.Process_Cnt)) AND SUM(Y.Run_Process_Cnt) <> 0 THEN 2
								WHEN (SUM(Y.Run_Process_Cnt) > SUM(X.Process_Cnt)) THEN 2
								ELSE 0
						END) AS Run_Status
						, (CASE WHEN TIMESTAMPDIFF(SECOND,Y.Reg_Dt,CURRENT_TIMESTAMP) > 150 THEN -1 ELSE 0 END) AS Run_StatusChk  -- 최종 등록일이 현재시간보다 150초이상 차이나면 문제있음
					FROM Mntng_Svr A 
					LEFT OUTER JOIN Mntng_Process X  ON A.Svr_Ip = X.Svr_Ip AND X.Del_Stat = 0
					LEFT OUTER JOIN Mntng_Process_Hist Y  ON X.Seq = Y.Process_Seq
					WHERE A.Del_Stat = 0
					AND A.Svr_Type = 0
					GROUP BY A.Svr_Ip -- ,AA.Last_Cpu_Use,BB.Last_Mem_Use,CC.Last_Rx_Use,DD.Last_Tx_Use
				) Y ON X.Svr_Ip = Y.Svr_Ip
	WHERE X.Del_Stat = 0
	AND X.Svr_Type = 0
	ORDER BY X.Disp_Order;
END;

