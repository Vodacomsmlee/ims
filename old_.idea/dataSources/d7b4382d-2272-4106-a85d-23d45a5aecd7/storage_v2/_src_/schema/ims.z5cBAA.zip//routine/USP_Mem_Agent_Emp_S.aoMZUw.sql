create
    definer = ims@`%` procedure USP_Mem_Agent_Emp_S()
BEGIN
	SELECT A.Emp_No
	, A.Organ_No
	, Emp_Nm
	, Agent_Key
	, A.Dept_No
	, IFNULL(CAST(A.Role_No AS CHAR(30)),'') Role_No
	, B.Team_Key
	, B.Dept_Nm
	, '' as Group_Nm
	, ims_ifx.FN_Get_UserID(Agent_Key) userid
	, IFNULL(C.Role_Nm,'') Role_Nm
	, RIGHT(ims_ifx.FN_Get_UserID(Agent_Key),4) AS Extn_no 
	FROM Emp A 
	LEFT OUTER JOIN Dept B  ON A.Dept_No = B.Dept_No
	LEFT OUTER JOIN ROLE C  ON A.Role_No = C.Role_No
	WHERE A.Del_Stat = 0
	AND A.Emp_No <> '1000';
	-- AND A.Agent_Key IS NOT NULLAND;
END;

