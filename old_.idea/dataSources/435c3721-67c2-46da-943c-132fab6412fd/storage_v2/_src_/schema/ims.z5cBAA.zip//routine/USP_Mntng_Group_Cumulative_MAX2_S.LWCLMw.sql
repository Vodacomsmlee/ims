create
    definer = ims@`%` procedure USP_Mntng_Group_Cumulative_MAX2_S()
BEGIN
SELECT * FROM (
SELECT ROW_NUMBER() OVER(PARTITION BY `GroupKey` ORDER BY `date` DESC)
AS RN, `date`, `GroupKey`
FROM `mntng_groupcumulative`
) AS A_ROWS
WHERE RN=1;
END;

