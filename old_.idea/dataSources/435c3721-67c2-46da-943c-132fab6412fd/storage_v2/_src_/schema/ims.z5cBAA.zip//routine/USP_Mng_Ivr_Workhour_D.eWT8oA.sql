create
    definer = ims@`%` procedure USP_Mng_Ivr_Workhour_D(IN v_WH_Seq int)
BEGIN
	UPDATE Mng_Ivr_Workhour 
	SET Del_Stat = 1
	WHERE WH_Seq = v_WH_Seq;
END;

