create
    definer = ims@`%` procedure USP_Mnt_Mntng_ThresHold_S(IN v_Svr_Ip varchar(15))
BEGIN
	declare v_Last_Reg_Dt_Cpu datetime(3);
	declare v_Last_Reg_Dt_Mem DATETIME(3);
	SELECT Reg_Dt into v_Last_Reg_Dt_Cpu FROM mntng_cpu_hist WHERE Svr_Ip = v_Svr_Ip ORDER BY reg_dt DESC limit 1;
	SELECT Reg_Dt into v_Last_Reg_Dt_Mem FROM mntng_memory_hist WHERE Svr_Ip = v_Svr_Ip ORDER BY reg_dt DESC LIMIT 1;
	SELECT A.Svr_Ip, A.Svr_Seq, A.Svr_Desc, A.Last_Sms_SendDt, Cpu_ThresHold, Memory_ThresHold
	, IFNULL(TIMESTAMPDIFF(MINUTE, IFNULL(A.Last_Sms_SendDt, A.Reg_Dt), SYSDATE()),0) AS SmsSend_Elapse_Min -- SMS 발송 경과시간(분)
	, ThresHold_Cnt -- 누적 ping 임계카운트
	, ThresHold_Cpu_Cnt -- 누적 CPU 임계카운트
	, ThresHold_Memory_Cnt -- 누적 메모리 임계카운트
	, Collect_ThresHold -- 임계카운트 한계
	, (CASE WHEN TIMESTAMPDIFF(SECOND, v_Last_Reg_Dt_Cpu,CURRENT_TIMESTAMP) > 150 THEN -1 ELSE 0 END) AS CpuChk
	, (CASE WHEN TIMESTAMPDIFF(SECOND, v_Last_Reg_Dt_Mem,CURRENT_TIMESTAMP) > 150 THEN -1 ELSE 0 END) AS MemChk
	FROM mntng_svr A
	WHERE A.Svr_Ip = v_Svr_Ip
	AND A.Del_Stat = 0;
END;

