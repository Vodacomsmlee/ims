create
    definer = ims@`%` procedure USP_Mntng_User_Cumulative_MAX2_S()
BEGIN
SELECT * FROM (
SELECT ROW_NUMBER() OVER(PARTITION BY UserKey ORDER BY `date` DESC) AS
RN, `date`, UserKey
FROM `mntng_usercumulative`
) AS A_ROWS
WHERE RN=1;
END;

