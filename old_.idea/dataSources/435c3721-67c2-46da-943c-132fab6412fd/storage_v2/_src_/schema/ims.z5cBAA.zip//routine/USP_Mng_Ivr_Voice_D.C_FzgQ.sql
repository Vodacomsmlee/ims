create
    definer = ims@`%` procedure USP_Mng_Ivr_Voice_D(IN v_SEQ int, IN v__EMP_NO varchar(30))
BEGIN
	UPDATE Mng_Ivr_Prompt
	SET Del_Stat = 1
	,SC_REGUSER = v__EMP_NO
	WHERE SEQ = v_SEQ;
END;

