create
    definer = ims@`%` function FN_CMM_CmmDtlName_S(v_CMM_CODE int, v_CMM_DTL_CODE varchar(50)) returns varchar(50)
BEGIN 
   DECLARE v_RETURN VARCHAR(50);
   select   Cmm_Dtl_Code_Nm INTO v_RETURN FROM Code_Cmm_Dtl  WHERE Cmm_Code = v_CMM_CODE
   AND Cmm_Dtl_Code = v_CMM_DTL_CODE;
    -- 공통코드 상세 명칭 RETURN
   RETURN v_RETURN;
END;

