create
    definer = ims@`%` procedure USP_Mntng_Wallboard_QueueCumulative_Rate_S()
BEGIN
	SELECT
	QueueKey, Answered, Received, Abandoned, Redirected
	,FORMAT(ROUND(AbandonedRate),2) AS AbandoneRate
	FROM(
		SELECT
		`date`, QueueKey, MaximumWaitTime,ServiceLevel,AverageWaitTime,AbandonedRate
		,Redirected,Answered,Abandoned,Received
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM
		Mntng_QueueCumulative
		WHERE `date` > CURDATE()
	) AS A_ROWS
	WHERE RN = 1;
END;

