create
    definer = ims@`%` procedure USP_AUTH_Emp_Grant_I(IN v_Emp_No varchar(10), IN v_Grant_Type tinyint unsigned,
                                                     IN v_Grant_Type_Seq int)
BEGIN
	IF EXISTS(SELECT  Emp_No FROM Role_Emp_Grant  WHERE Emp_No = v_Emp_No AND Grant_Type = v_Grant_Type AND Grant_Type_Seq = v_Grant_Type_Seq LIMIT 1) then
		
		DELETE FROM Role_Emp_Grant
		WHERE Emp_No = v_Emp_No
		AND Grant_Type = v_Grant_Type
		AND Grant_Type_Seq = v_Grant_Type_Seq;
		
	ELSE
	
		INSERT INTO Role_Emp_Grant(Emp_No, Grant_Type, Grant_Type_Seq)
		VALUES(v_Emp_No, v_Grant_Type, v_Grant_Type_Seq);
		
	end if;
END;

