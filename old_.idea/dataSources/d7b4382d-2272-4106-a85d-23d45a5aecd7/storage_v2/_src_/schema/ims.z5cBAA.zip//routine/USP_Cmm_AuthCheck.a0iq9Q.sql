create
    definer = ims@`%` procedure USP_Cmm_AuthCheck(IN v_URL varchar(200), IN v_EMP_NO varchar(10))
BEGIN
	DECLARE v_Rst BOOLEAN;
	IF v_URL is null then
		set v_URL = '';
	END IF;
	
	IF v_EMP_NO is null then
		set v_EMP_NO = '';
	END IF;
	
	SET v_Rst = cast(0 as SIGNED INTEGER);
	
	/*
	DECLARE @EMP_NO VARCHAR(10)
	DECLARE @URL VARCHAR(200)
	SET @EMP_NO = '1000'
	SET @URL = '/ims/cmm/mng/code/queue.do'
	*/
	
	-- 기본 Role
	IF EXISTS
			(
				SELECT * 
				FROM Emp A 
				JOIN Role_Dtl B  ON A.Role_No = B.Role_No
				JOIN Role_Service C  ON B.Svc_No = C.Svc_No
				WHERE A.Emp_No = v_EMP_NO
				AND C.Svc_Url = v_URL
				AND C.Use_Stat = 0
				AND A.Del_Stat = 0
			) then
		SET v_Rst = cast(1 as SIGNED INTEGER);
	end if;
	-- 개인 권한
	IF EXISTS
			(
				SELECT * 
				FROM Emp A 
				JOIN Role_Emp_Service B  ON A.Emp_No = B.Emp_No
				JOIN Role_Service C  ON B.Svc_No = C.Svc_No
				WHERE A.Emp_No = v_EMP_NO
				AND B.Del_Stat = 0
				AND C.Use_Stat = 0
				AND C.Svc_Url = v_URL
				AND A.Del_Stat = 0
			) then
		SET v_Rst = cast(1 as SIGNED INTEGER);
	end if;
   SELECT v_Rst AS Rst;
	-- SELECT @Rst = CAST( 1 AS BIT)
END;

