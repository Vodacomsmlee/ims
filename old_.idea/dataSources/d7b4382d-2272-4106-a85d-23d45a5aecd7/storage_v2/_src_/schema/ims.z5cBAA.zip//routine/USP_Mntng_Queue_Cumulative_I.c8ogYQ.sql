create
    definer = ims@`%` procedure USP_Mntng_Queue_Cumulative_I(IN v_date datetime, IN v_queueKey int(10),
                                                             IN v_maximumWaitTime int(10), IN v_serviceLevel float,
                                                             IN v_averageWaitTime float, IN v_abandonedRate float,
                                                             IN v_redirectedOutOfScope int(10),
                                                             IN v_answeredContacts int(10),
                                                             IN v_abandonedContacts int(10),
                                                             IN v_receivedContacts int(10))
BEGIN
INSERT INTO `mntng_queuecumulative`(
`date`
,`QueueKey`
,`MaximumWaitTime`
,`ServiceLevel`
,`AverageWaitTime`
,`AbandonedRate`
,`Redirected`
,`Answered`
,`Abandoned`
,`Received`)
VALUES(v_date
,v_queueKey
,v_maximumWaitTime
,v_serviceLevel
,v_averageWaitTime
,v_abandonedRate
,v_redirectedOutOfScope
,v_answeredContacts
,v_abandonedContacts
,v_receivedContacts);
END;

