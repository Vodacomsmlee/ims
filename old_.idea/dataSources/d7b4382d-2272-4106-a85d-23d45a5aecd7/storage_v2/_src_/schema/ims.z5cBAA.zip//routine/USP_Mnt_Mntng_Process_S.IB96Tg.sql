create
    definer = ims@`%` procedure USP_Mnt_Mntng_Process_S(IN v_SvrIp varchar(15))
BEGIN
	IF v_SvrIp IS NOT NULL THEN
	
		SET v_SvrIp = REPLACE(v_SvrIp, '192.168.122.1','172.20.1.207'); -- fax
		SET v_SvrIp = REPLACE(v_SvrIp, '169.254.251.197','172.20.1.201'); -- rec
	
	
		SELECT Process_Nm, Process_Cnt, Seq FROM Mntng_Process 
		WHERE Svr_Ip = v_SvrIp
		AND Del_Stat = 0;
	END IF;
	
END;

