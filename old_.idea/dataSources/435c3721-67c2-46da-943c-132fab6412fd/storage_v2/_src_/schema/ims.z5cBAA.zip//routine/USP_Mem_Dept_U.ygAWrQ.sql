create
    definer = ims@`%` procedure USP_Mem_Dept_U(IN v_Dept_No int, IN v_Dept_Nm varchar(50),
                                               IN v_Dept_Type tinyint unsigned, IN v_High_Dept_No int,
                                               IN v_Team_Key int, IN v_Dept_Desc varchar(100), IN v_Emp_No varchar(10))
BEGIN 
	UPDATE Dept
	SET Dept_Nm = v_Dept_Nm
	,Dept_Type = v_Dept_Type
	,High_Dept_No = v_High_Dept_No
	,Team_Key = v_Team_Key
	,Dept_Desc = v_Dept_Desc
	WHERE Dept_No = v_Dept_No;
	
	-- 상담원 app 동기화
	UPDATE ypctidb.tb_team
	SET TEAMNAME = v_Dept_Nm
	, HIGH_TEAMCODE = v_High_Dept_No
	, MODIFY_ID = v_Emp_No
	, MODIFYDATE = NOW(3)
	WHERE TEAMCODE = v_Dept_No;
	
	
END;

