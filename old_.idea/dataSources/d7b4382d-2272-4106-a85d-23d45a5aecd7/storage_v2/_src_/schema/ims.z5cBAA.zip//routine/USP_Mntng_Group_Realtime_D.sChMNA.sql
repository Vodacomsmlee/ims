create
    definer = ims@`%` procedure USP_Mntng_Group_Realtime_D(IN v_groupKey int(10))
BEGIN
DELETE FROM `mntng_grouprealtime` WHERE `GroupKey`=v_groupKey;
END;

