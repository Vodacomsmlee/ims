create
    definer = ims@`%` procedure USP_Mnt_Mntng_Dash_AgentStatus_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	call FN_CMM_Grant_S(v__Emp_No,4);
	
	SELECT
		IFNULL(SUM(1),0) as LOGIN
		,IFNULL(SUM(CASE PresenceState
						WHEN 4 THEN CASE HandlingStateReasonKey WHEN 10 THEN 1 ELSE 0 END
						WHEN 2 THEN 1 ELSE 0 
					END),0) as `WORK`
		,IFNULL(SUM(CASE PresenceState
						WHEN 4 THEN CASE WHEN HandlingStateReasonKey <> 10 THEN 1 ELSE 0 END
						ELSE 0 
					END),0) as BUSY
		,IFNULL(SUM(CASE PresenceState WHEN 3 THEN 1 ELSE 0 END),0) as AWAY
		,IFNULL(SUM(CASE PresenceState WHEN 1 THEN 1 ELSE 0 END),0) as IDLE
	FROM Mntng_UserRealTime 
	WHERE Department in(SELECT `VALUE` FROM FN_CMM_Grant_S);
END;

