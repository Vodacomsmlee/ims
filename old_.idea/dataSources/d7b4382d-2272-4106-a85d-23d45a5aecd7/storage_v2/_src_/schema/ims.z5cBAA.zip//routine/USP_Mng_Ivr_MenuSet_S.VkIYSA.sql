create
    definer = ims@`%` procedure USP_Mng_Ivr_MenuSet_S()
BEGIN
	SELECT SC_MENU
	,SC_MENUNAME
	,SC_PROMPT
	,IFNULL((SELECT SC_FILENAME FROM Mng_Ivr_Prompt  WHERE SC_PROMPT = A.SC_PROMPT),'') AS SC_PROMPT_NM
	,SC_DIGIT
	FROM Mng_Ivr_ScenarioMenu A 
	WHERE Del_Stat = 0
	ORDER BY SC_MENUNAME;
END;

