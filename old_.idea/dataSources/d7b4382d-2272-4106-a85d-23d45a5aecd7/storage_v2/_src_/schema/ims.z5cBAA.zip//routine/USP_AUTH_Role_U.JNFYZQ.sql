create
    definer = ims@`%` procedure USP_AUTH_Role_U(IN v_Role_No int, IN v_Role_Nm varchar(30),
                                                IN v_CCAPP_Admin_Stat tinyint unsigned)
BEGIN
	IF v_CCAPP_Admin_Stat is null then
	set v_CCAPP_Admin_Stat = 0;
	END IF;
	UPDATE Role
	SET Role_Nm = v_Role_Nm
	,CCAPP_Admin_Stat = v_CCAPP_Admin_Stat
	WHERE Role_No = v_Role_No;
	
END;

