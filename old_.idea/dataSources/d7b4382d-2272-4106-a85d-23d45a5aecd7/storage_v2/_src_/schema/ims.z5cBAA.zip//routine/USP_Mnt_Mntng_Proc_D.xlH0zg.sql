create
    definer = ims@`%` procedure USP_Mnt_Mntng_Proc_D(IN v_Proc_Seq int)
BEGIN
	UPDATE Mntng_Process
	SET Del_Stat = 1
	WHERE Seq = v_Proc_Seq;
END;

