create
    definer = ims@`%` procedure USP_Mntng_Group_Cumulative_All_D()
BEGIN
TRUNCATE TABLE `mntng_groupcumulative`;
END;

