create
    definer = ims@`%` procedure USP_OracleToMaria_Sync()
BEGIN 
	declare v_OraEmpCnt int;
	declare v_OraDeptCnt int;
	DROP TEMPORARY TABLE IF EXISTS Tmp_Old_Emp;
	CREATE TEMPORARY TABLE IF NOT EXISTS Tmp_Old_Emp
	( 
		Emp_No VARCHAR(10) 
		, Emp_Passwd blob
		, Emp_Nm varchar(30)
		, Last_Passwd_Edit_Dt timestamp(6)
	);
	
	
	insert into Tmp_Old_Emp(Emp_No, Emp_Passwd, Emp_Nm, Last_Passwd_Edit_Dt)
	select Emp_No, Emp_Passwd, Emp_Nm, Last_Passwd_Edit_Dt from ims.emp;
	select count(1) as cnt into v_OraEmpCnt from oracle_IV_CTI_DEPT;
	SELECT COUNT(1) AS CNT INTO v_OraDeptCnt  FROM oracle_iv_dept;
	
	if v_OraEmpCnt > 0 then
	
		-- ims.emp 전체삭제
		delete from ims.emp where Emp_No <> '1000';
		
		INSERT INTO emp(Emp_No, Emp_Passwd, Emp_Nm, Agent_Key, Dept_No, Del_Stat, Role_No)
		SELECT emp_no, SHA2('1111', 256), `name`, Agent_Key, dept_cd, del_stat, Role_No
		FROM
			(
			SELECT emp_no, `name`, B.Agent_seq AS Agent_Key, dept_cd, (CASE WHEN `status` = 'Y' THEN 0 ELSE 1 END) AS del_stat, IFNULL(C.Role_No, '11') AS Role_No
			FROM oracle_IV_CTI_DEPT A
			LEFT OUTER JOIN oigweb.mitel_acd_agent B ON A.agent_id = right(B.AGENT_ID,4)
			LEFT OUTER JOIN ims.ROLE C ON A.CAPACITY_CD = C.DESC
			) A
		ON DUPLICATE KEY UPDATE Emp_No = A.emp_no, Emp_Nm = a.name, DEL_STAT = a.del_stat;
		UPDATE ims.emp A, Tmp_Old_Emp B
		SET A.Emp_Passwd = B.Emp_Passwd
		, A.Last_Passwd_Edit_Dt = B.Last_Passwd_Edit_Dt
		WHERE A.emp_no = B.emp_no and A.Emp_Nm = B.Emp_Nm;
		
	end if;
	-- 부서
	if v_OraDeptCnt > 0 then
		
		
		delete from ims.dept;
		
		INSERT INTO dept(DEPT_NO, DEPT_NM, HIGH_DEPT_NO, DEPT_DESC, CLASS_TYPE)
		SELECT DEPT_CD, DEPT_NAME, UPPER_DEPT_CD, SYS_CODE, CLASS_TYPE 
		FROM oracle_iv_dept;
	end if;
	
	
	
	/*
	INSERT INTO dept(DEPT_NO, DEPT_NM, HIGH_DEPT_NO, DEL_STAT)
	SELECT dept_cd, dept_name, upper_Dept_cd, del_stat
	FROM 
		(
		SELECT dept_cd, dept_name, upper_Dept_cd, 0 AS del_stat -- , (CASE WHEN STATUS = 'Y' THEN 0 ELSE 1 END) AS del_stat 
		FROM oracle_IV_CTI_DEPT 
		GROUP BY dept_cd ORDER BY dept_cd
		) A
	ON DUPLICATE KEY UPDATE DEPT_NM = A.dept_name, HIGH_DEPT_NO = a.upper_Dept_cd, DEL_STAT = a.del_stat;
	*/
	
		
	/*
	-- 상담무음IVR 업데이트
	update ims.oracle_iv_cti_dept A, ims.mng_ivr_dnis B
	set B.DNIS_SC_CODE = 3
	, B.DEL_STAT = 0
	, B.DNIS_TELTYPE = 0
	, B.DNIS_NAME = (CASE WHEN B.DNIS_NAME = '' THEN '상담무음IVR' ELSE B.DNIS_NAME END)
	where A.AGENT_ID = B.DNIS_NUMBER
	AND A.CAPACITY_CD = 11
	AND B.DNIS_SC_CODE <> 3
	AND B.DNIS_TELTYPE <> 0
	-- 상담무음IVR 빼기 업데이트
	UPDATE ims.oracle_iv_cti_dept A, ims.mng_ivr_dnis B
	SET B.DNIS_SC_CODE = 5
	, B.DEL_STAT = 0
	, B.DNIS_TELTYPE = 6
	, B.DNIS_NAME = '업무무음IVR'
	WHERE A.AGENT_ID = B.DNIS_NUMBER
	AND A.CAPACITY_CD <> 11
	AND B.DNIS_SC_CODE = 3
	AND B.DNIS_TELTYPE = 0
	*/
		
		
	
/*
 	DECLARE V_MIN INT;
	DECLARE V_MAX INT;
	
	DECLARE V_DEPT_CD INT;
	DECLARE V_EMP_NO VARCHAR(12);
	DECLARE V_NAME VARCHAR(30);
	DECLARE V_AGENT_ID VARCHAR(8);
	DECLARE V_CAPACITY_CD VARCHAR(8);
	DECLARE V_STATUS VARCHAR(1);
	
	SET V_MIN = 1;
	DROP TEMPORARY TABLE IF EXISTS TMP_EMP_SYNC;
	CREATE TEMPORARY TABLE IF NOT EXISTS TMP_EMP_SYNC
	( 
		SEQ INT AUTO_INCREMENT
		, DEPT_CD INT
		, EMP_NO VARCHAR(12)
		, `NAME` VARCHAR(30)
		, AGENT_ID VARCHAR(8)
		, CAPACITY_CD VARCHAR(8)
		, `STATUS` VARCHAR(1)
		, PRIMARY KEY (`SEQ`)
	);
	INSERT INTO TMP_EMP_SYNC(DEPT_CD, EMP_NO, NAME, AGENT_ID, CAPACITY_CD, `STATUS`)
	SELECT DEPT_CD, EMP_NO, NAME, AGENT_ID, CAPACITY_CD, `STATUS`
	FROM ims.oracle_IV_CTI_DEPT;
	
	SELECT MAX(SEQ) INTO V_MAX FROM TMP_EMP_SYNC;
	
	WHILE (V_MIN < V_MAX) DO
	
		SET V_DEPT_CD = NULL;
		SET V_EMP_NO = '';
		SET V_NAME = '';
		SET V_AGENT_ID = '';
		SET V_CAPACITY_CD = '';
		SET V_STATUS = '';
		
		SELECT DEPT_CD, EMP_NO, `NAME`, AGENT_ID, CAPACITY_CD, `STATUS` INTO V_DEPT_CD, V_EMP_NO, V_NAME, V_AGENT_ID, V_CAPACITY_CD, V_STATUS
		FROM TMP_EMP_SYNC
		WHERE SEQ = V_MIN;
		
	
		-- 사원 정보가 있으면
		IF EXISTS(SELECT EMP_NO FROM ims.EMP WHERE Emp_No = V_EMP_NO AND Del_Stat = 0) then
			
			-- 변경된 데이타가 있으면 UPDATE
			IF NOT EXISTS(
							SELECT EMP_NO 
							FROM ims.EMP 
							WHERE Emp_No = V_EMP_NO
							AND ifnull(Emp_Nm,'') = V_NAME
							AND ifnull(Dept_No,'') = V_DEPT_CD
							-- and Agent_Key = V_AGENT_ID
							-- and Role_No = V_CAPACITY_CD
							AND Del_Stat = (CASE WHEN V_STATUS = 'Y' THEN 0 ELSE 1 END)
						) THEN
			
				UPDATE ims.EMP 
				SET Emp_Nm = V_NAME
				, Dept_No = V_DEPT_CD
				-- , Agent_Key = V_AGENT_ID
				-- , Role_No = V_CAPACITY_CD
				, Del_Stat = (CASE WHEN V_STATUS = 'Y' THEN 0 ELSE 1 END)
				WHERE Emp_No = V_EMP_NO;
			
			END IF;
				
		ELSE -- 사원 정보가 없으면 INSERT
			INSERT INTO ims.emp(Emp_No, Emp_Passwd, Emp_Nm, Dept_No, Del_Stat) VALUES(V_EMP_NO, SHA2('1234', 256), V_NAME, V_DEPT_CD, (CASE WHEN V_STATUS = 'Y' THEN 0 ELSE 1 END));
		
		END IF;
	
		SET V_MIN = V_MIN + 1;
		
	END WHILE; 
	
	DROP TEMPORARY TABLE IF EXISTS TMP_EMP_SYNC;
 
 */
 
END;

