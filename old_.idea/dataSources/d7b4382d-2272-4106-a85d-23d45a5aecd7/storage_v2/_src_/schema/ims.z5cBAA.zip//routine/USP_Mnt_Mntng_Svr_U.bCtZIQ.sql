create
    definer = ims@`%` procedure USP_Mnt_Mntng_Svr_U(IN v_Svr_Seq int, IN v_Svr_Ip varchar(15),
                                                    IN v_Svr_Desc varchar(4000), IN v_Cpu_ThresHold float,
                                                    IN v_Memory_ThresHold float, IN v_Network_ThresHold float)
BEGIN
	IF v_Network_ThresHold is null then
		set v_Network_ThresHold = 0;
	END IF;
	UPDATE Mntng_Svr
	SET Svr_Ip = v_Svr_Ip
	,Svr_Desc = v_Svr_Desc
	,Cpu_ThresHold = v_Cpu_ThresHold
	,Memory_ThresHold = v_Memory_ThresHold
	,Network_ThresHold = v_Network_ThresHold
	WHERE Svr_Seq = v_Svr_Seq;
	
END;

