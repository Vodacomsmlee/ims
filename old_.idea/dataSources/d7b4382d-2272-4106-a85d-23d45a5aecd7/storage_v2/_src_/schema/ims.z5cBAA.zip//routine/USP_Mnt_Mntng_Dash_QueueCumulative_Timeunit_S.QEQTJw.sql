create
    definer = ims@`%` procedure USP_Mnt_Mntng_Dash_QueueCumulative_Timeunit_S()
BEGIN
	SELECT
	DT, right(DT,2) TimeUnit, SUM(PrevReceived) CntReceived, SUM(PrevAnswered) CntAnswered, SUM(PrevAbandoned) CntAbandoned, SUM(PrevRedirected) CntRedirected
	FROM(
		SELECT
		DT, right(DT,2) TimeUnit, Received
		, Received - IFNULL(LEAD(Received) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) PrevReceived
		, Answered
		, Answered - IFNULL(LEAD(Answered) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) PrevAnswered
		, Abandoned
		, Abandoned - IFNULL(LEAD(Abandoned) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) PrevAbandoned
		, Redirected
		, Redirected - IFNULL(LEAD(Redirected) OVER(PARTITION BY QueueKey ORDER BY Dt desc),0) PrevRedirected
		FROM(
			SELECT DATE_FORMAT(`date`,'%Y-%m-%d %H') DT, MAX(Received) Received, QueueKey, MAX(Answered) Answered,MAX(Abandoned) Abandoned,MAX(Redirected) Redirected
			FROM Mntng_QueueCumulative 
			-- WHERE `date` > TIMESTAMPADD(DAY,TIMESTAMPDIFF(DAY,0,CURRENT_TIMESTAMP),0)
			GROUP BY DATE_FORMAT(`date`,'%Y-%m-%d %H'),QueueKey
			) A
		) B
	GROUP BY B.DT
	ORDER BY DT;
END;

