create
    definer = ims@`%` procedure USP_Mntng_User_Realtime_U(IN v_userKey int, IN v_extension varchar(20),
                                                          IN v_routingState varchar(20),
                                                          IN v_routingStateReasonKey int(10),
                                                          IN v_timeInRoutingState int(10),
                                                          IN v_presenceState varchar(20),
                                                          IN v_timeInPresenceState int(10),
                                                          IN v_handlingState varchar(20),
                                                          IN v_handlingStateReason int(10),
                                                          IN v_timeInHandlingState int(10),
                                                          IN v_uniqueCallId varchar(30), IN v_contactType varchar(40),
                                                          IN v_description varchar(50), IN v_associatedQueueKey int(10),
                                                          IN v_userHandlingTime int(10))
BEGIN
UPDATE `mntng_userrealtime` SET
`date`=CURRENT_TIMESTAMP(6)
,`Extension`=v_extension
,`RoutingState`=v_routingState
,`RoutingStateReasonKey`=v_routingStateReasonKey
,`TimeInRoutingState`=v_timeInRoutingState
,`PresenceState`=v_presenceState
,`TimeInPresenceState`=v_timeInPresenceState
,`HandlingState`=v_handlingState
,`HandlingStateReasonKey`=v_handlingStateReason
,`TimeInHandlingState`=v_timeInHandlingState
,`CallID`=v_uniqueCallId
,`ContactType`=v_contactType
,`ContactDescription`=v_description
,`AssociatedQueueKey`=v_associatedQueueKey
,`TotalContactHandlingTime`=v_userHandlingTime
WHERE `UserKey`=v_userKey;
END;

