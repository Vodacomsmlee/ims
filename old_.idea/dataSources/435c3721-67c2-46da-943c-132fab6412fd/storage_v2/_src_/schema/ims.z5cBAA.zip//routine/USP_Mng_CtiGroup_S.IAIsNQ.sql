create
    definer = ims@`%` procedure USP_Mng_CtiGroup_S()
BEGIN
	SELECT Group_Seq, A.Dept_No, B.Dept_Nm, A.Group_Nm
	-- , '' as Group_Key
	-- , '' AS virtualgroupname
	, C.virtualgroupkey AS Group_Key
	, IFNULL(C.virtualgroupname,'') AS virtualgroupname
	FROM Mng_Cti_Group A 
	LEFT OUTER JOIN Dept B ON A.Dept_No = B.Dept_No AND  B.Del_Stat = 0
	LEFT OUTER JOIN ims_ifx.virtualgroups C  ON A.Group_Key = C.virtualgroupkey
	WHERE A.Del_Stat = 0;
END;

