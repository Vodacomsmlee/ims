create
    definer = ims@`%` procedure USP_Mem_Dept_I(IN v_Dept_Nm varchar(50), IN v_Dept_Type tinyint unsigned,
                                               IN v_High_Dept_No int, IN v_Team_Key int, IN v_Dept_Desc varchar(100),
                                               IN v_Emp_No varchar(10))
BEGIN
	DECLARE v_Dept_No INT;
	DECLARE v_Reg_Dt DATETIME;
	DECLARE v_teamkey_seq INT;
	declare v_SEQ int;
	DECLARE v_DEPTH INT;
	
	
	
	INSERT INTO Dept(Dept_Nm, Dept_Type, High_Dept_No, Team_Key, Dept_Desc)
	VALUES(v_Dept_Nm, v_Dept_Type, v_High_Dept_No, v_Team_Key, v_Dept_Desc);
	SET v_Dept_No = LAST_INSERT_ID();
	DROP TEMPORARY TABLE IF EXISTS tt_CTE;
	CREATE TEMPORARY TABLE tt_CTE
	(
		Dept_No INT,
		Dept_Nm VARCHAR(50), 
		High_Dept_No INT, 
		Lvl INT, 
		Path_Code VARCHAR(1000)
	); 
	
	insert into tt_CTE(Dept_No, Dept_Nm, High_Dept_No, Lvl, Path_Code)
	WITH RECURSIVE CTE(Dept_No, Dept_Nm, High_Dept_No, Lvl, Path_Code)
	AS(
		SELECT Dept_No, Dept_Nm, High_Dept_No, 1 AS Lvl, CAST(Dept_No AS CHAR(10)) AS Path_Code
		FROM Dept 
		WHERE High_Dept_No IS NULL
		AND Del_Stat = 0
		
		UNION ALL
		
		SELECT C.Dept_No, C.Dept_Nm, C.High_Dept_No, Lvl + 1 AS Lvl, CONCAT(Path_Code,'/',CAST(C.Dept_No AS CHAR(10))) AS Path_Code
		FROM Dept C 
		INNER JOIN CTE CCte ON C.High_Dept_No = CCte.Dept_No
		WHERE Del_Stat = 0
	)
	SELECT Lvl, Dept_Nm, High_Dept_No, Lvl, Path_Code
	FROM CTE
	WHERE Dept_No = v_Dept_No;
	-- ORDER BY Path_Code ASC;
	select Lvl INTO v_DEPTH from tt_CTE;
	DROP TEMPORARY TABLE IF EXISTS tt_CTE;
	
	select ifnull(max(TEAMCODE),0) into v_SEQ from ypctidb.tb_team where HIGH_TEAMCODE = v_Dept_No;
	set v_SEQ = v_SEQ + 1;
	-- 상담원 app 동기화
	INSERT INTO ypctidb.tb_team(TEAMCODE, HIGH_TEAMCODE, TEAMNAME, SEQ, USED, DEPTH, `DESCRIPTION`, `INSERT_ID`, MODIFY_ID, INSERTDATE, MODIFYDATE, DEL_YN, TEAMCTYPE)
	VALUES(CAST(v_Dept_No AS char), ifnull(v_High_Dept_No, ''), v_Dept_Nm, v_SEQ, 'Y', v_DEPTH, '', v_Emp_No, v_Emp_No, NOW(3), NOW(3), 'N', NULL);
	/*
	-- OSCC처리
	SET v_Reg_Dt = CURRENT_TIMESTAMP;
	-- linked 수정 필요
	-- INSERT INTO OPENQUERY(OSCC, 'SELECT teamname, sitekey, locktimestamp, busunitkey FROM teams WHERE 1=0 ') 
	-- VALUES(@Dept_Desc, ims_ifx.FN_IFX_Constant_S(1), DATEADD(HOUR, -9, @Reg_Dt), 1)
	-- CALL ims_ifx.USP_Sync_UsersTeams_Day(); -- 동기화 처리
	select teamkey INTO v_teamkey_seq FROM ims_ifx.teams  WHERE locktimestamp = TIMESTAMPADD(HOUR,-9,v_Reg_Dt);
	
	UPDATE Dept
	SET Team_Key = v_teamkey_seq
	WHERE Dept_No = v_Dept_No;
	*/
END;

