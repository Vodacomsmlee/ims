create
    definer = ims@`%` procedure USP_AUTH_Emp_ServiceAdd_Dept_S(IN v_Emp_No varchar(10))
BEGIN
	IF v_Emp_No IS NULL THEN
		SET v_Emp_No = '';
	END IF;
	
	SELECT Emp_No INTO v_Emp_No FROM Emp  WHERE Emp_No = v_Emp_No; 
	IF v_Emp_No <> '' THEN
	
		/*
		WITH RECURSIVE CTE(Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm)
		AS(
			SELECT Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, 1 AS Lvl
			
			, CAST(Dept_No AS CHAR(10)) AS Path_Code
			, CAST(Dept_Nm AS CHAR(50)) AS Path_Dept_Nm
			FROM Dept 
			WHERE High_Dept_No IS NULL
			AND Del_Stat = 0
			
			UNION ALL
			
			SELECT C.Dept_No, C.Dept_Nm, C.High_Dept_No, C.Team_Key, C.Dept_Desc, Lvl + 1 AS Lvl
			, CONCAT(Path_Code,'/',CAST(C.Dept_No AS CHAR(10))) AS Path_Code
			, CONCAT(Path_Dept_Nm,' > ',CAST(C.Dept_Nm AS CHAR(50))) AS Path_Dept_Nm
			FROM Dept C 
			INNER JOIN CTE CCte ON C.High_Dept_No = CCte.Dept_No
			WHERE Del_Stat = 0
		)
		SELECT Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm
		, (CASE WHEN IFNULL(B.Emp_No,'') = '' THEN '' ELSE ' checked' END) CHK
		FROM CTE A
		LEFT OUTER JOIN Role_Emp_Grant B  ON A.Dept_No = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 1
		WHERE ifnull(A.Dept_No,'') <> ''
		ORDER BY Path_Code ASC ;
		*/
		-- 부서
		SELECT A.Dept_No
		, A.Dept_Nm
		, (CASE WHEN IFNULL(B.Emp_No,'') = '' THEN '' ELSE ' checked' END) CHK
		FROM Dept A 
		LEFT OUTER JOIN Role_Emp_Grant B  ON A.Dept_No = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 1
		WHERE A.Del_Stat = 0;
   END IF;
END;

