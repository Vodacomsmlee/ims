create
    definer = ims@`%` function FN_Get_UserKeyToDeptNo(v_userkey int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   SELECT Dept_no INTO v_RETURN FROM ims.emp WHERE agent_key = v_userkey;
   RETURN v_RETURN;
END;

