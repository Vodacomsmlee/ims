create
    definer = ims@`%` procedure USP_Mntng_Wallboard_GroupRealTime_S()
BEGIN
	SELECT
	`date`
	, groupkey
	, CallsWaiting
	, LoggedOnUsers
	, IdleUsers
	, (BusyUsers+AwayUsers) AS AwayUsers
	, (HandlingDirectUsers+HandlingRoutedUsers) AS BusyUsers
	FROM(
		SELECT
		`date`
		, groupkey
		, CallsWaiting
		,LoggedOnUsers
		,IdleUsers
		,BusyUsers
		,AwayUsers
		,HandlingDirectUsers
		,HandlingRoutedUsers
		,ROW_NUMBER() OVER(PARTITION BY groupkey ORDER BY `date` DESC) AS RN
		FROM Mntng_GroupRealTime
	) AS A_ROWS
	WHERE RN = 1;
END;

