create
    definer = ims@`%` procedure USP_Mnt_Mntng_UserRealTime_S()
BEGIN
	SELECT
		A_ROWS.`date`
		, A_ROWS.UserKey
		, A_ROWS.UserID
		, ims_ifx.FN_Get_Emp_Nm(A_ROWS.UserKey,sysdate()) as UserName
		, A_ROWS.Department
		, ims_ifx.FN_Get_Emp_Dept_Nm(A_ROWS.UserKey,SYSDATE()) as DepartmentName
		, Extension,PresenceState
		, (CASE PresenceState
			   WHEN 4 THEN HandlingState
			   WHEN 3 THEN RoutingStateReasonKey
			   ELSE 0
			END) as ReasonKey
		,(CASE PresenceState
				WHEN 4 THEN -- 공통코드 : 4
					CASE WHEN HandlingState IS NOT NULL THEN FN_CMM_CmmDtlName_S(4,HandlingState) ELSE 'unknown' END
				WHEN 3 THEN -- 공통코드 : 1
					CASE WHEN RoutingStateReasonKey IS NOT NULL THEN FN_CMM_CmmDtlName_S(1,RoutingStateReasonKey) ELSE 'unknown' END
				ELSE -- 공통코드 : 5
					CASE WHEN PresenceState IS NOT NULL THEN  FN_CMM_CmmDtlName_S(5,PresenceState) ELSE 'unknown' END
			END) as State
		, SEC_TO_TIME(CASE PresenceState
							WHEN 4 THEN TimeInHandlingState
							WHEN 3 THEN TimeInRoutingState
							ELSE TimeInPresenceState
						END) as TimeInState
		, (CASE WHEN AssociatedQueueKey IS NOT NULL THEN FN_QueueNm_S(AssociatedQueueKey) ELSE '' END) as QueueName
		, Handled
		, SEC_TO_TIME(TotalLoggedOnTime) as TotalLoggedOnTime
		, SEC_TO_TIME(TotalIdleTime) AS TotalIdleTime
		, SEC_TO_TIME(TotalAwayTime) AS TotalAwayTime
		, SEC_TO_TIME(TotalHandledTime - TotalPostProcessingTime) AS TotalWorkOnTime
		, SEC_TO_TIME(TotalBusyTime) AS TotalBusyTime
		, SEC_TO_TIME(TotalPostProcessingTime) AS TotalPostProcessingTime
	FROM(
			SELECT
				`date`, UserKey, UserID, Department, Extension,
				RoutingState, RoutingStateReasonKey, TimeInRoutingState,
				PresenceState, TimeInPresenceState, HandlingState, HandlingStateReasonKey,
				TimeInHandlingState, CallID, ContactType, ContactDescription, AssociatedQueueKey,
				TotalContactHandlingTime,ROW_NUMBER() OVER(PARTITION BY UserKey ORDER BY `date` DESC) AS RNS
			FROM Mntng_UserRealTime 
			WHERE `date` >= DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
		) AS A_ROWS
	JOIN(
			SELECT
				`date`, UserKey,Handled
				,TotalLoggedOnTime,TotalIdleTime,TotalAwayTime
				,TotalPostProcessingTime,TotalBusyTime,TotalHandledTime
				,ROW_NUMBER() OVER(PARTITION BY UserKey ORDER BY `date` DESC) AS RNT
			FROM Mntng_UserCumulative 
			WHERE `date` >= DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
		) AS TOTALS ON A_ROWS.USERKEY = TOTALS.USERKEY
	WHERE A_ROWS.RNS = 1
	AND TOTALS.RNT = 1;
END;

