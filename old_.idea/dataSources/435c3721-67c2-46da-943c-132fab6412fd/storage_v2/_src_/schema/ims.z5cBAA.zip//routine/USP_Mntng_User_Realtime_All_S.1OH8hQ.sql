create
    definer = ims@`%` procedure USP_Mntng_User_Realtime_All_S()
BEGIN
SELECT `date`,`UserKey`,`Extension`
FROM `mntng_userrealtime`;
END;

