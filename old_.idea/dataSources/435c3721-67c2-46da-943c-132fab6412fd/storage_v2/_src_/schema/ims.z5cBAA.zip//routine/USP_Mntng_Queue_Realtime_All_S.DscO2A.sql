create
    definer = ims@`%` procedure USP_Mntng_Queue_Realtime_All_S()
BEGIN
SELECT `date`,`QueueKey`
FROM `mntng_queuerealtime`;
END;

