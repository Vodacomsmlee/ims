create
    definer = ims@`%` procedure USP_Mng_Ivr_Route_I(IN v_RT_ROUTENAME varchar(50), IN v_RT_ROUTENUM varchar(50),
                                                    IN v_RT_PROMPT varchar(50), IN v_RT_HDSET tinyint unsigned,
                                                    IN v_RT_WHSET tinyint unsigned)
BEGIN
	INSERT INTO Mng_Ivr_ScenarioRoute(
		RT_ROUTENAME
		,RT_ROUTENUM
		,RT_PROMPT
		,RT_HOLIDAYSET
		,RT_WORKTIME
	) VALUES (
		v_RT_ROUTENAME,
		v_RT_ROUTENUM,
		v_RT_PROMPT,
		v_RT_HDSET,
		v_RT_WHSET
	);
			
END;

