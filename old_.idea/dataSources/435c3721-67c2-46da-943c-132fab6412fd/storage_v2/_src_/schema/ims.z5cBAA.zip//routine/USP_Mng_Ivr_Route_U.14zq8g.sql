create
    definer = ims@`%` procedure USP_Mng_Ivr_Route_U(IN v_RT_ROUTE int, IN v_RT_ROUTENAME varchar(50),
                                                    IN v_RT_ROUTENUM varchar(50), IN v_RT_PROMPT varchar(50),
                                                    IN v_RT_HDSET tinyint unsigned, IN v_RT_WHSET tinyint unsigned)
BEGIN
	UPDATE Mng_Ivr_ScenarioRoute
	SET RT_ROUTENAME = v_RT_ROUTENAME
	,RT_ROUTENUM = v_RT_ROUTENUM
	,RT_PROMPT = v_RT_PROMPT
	,RT_HOLIDAYSET = v_RT_HDSET
	,RT_WORKTIME = v_RT_WHSET
	WHERE
	RT_ROUTE = v_RT_ROUTE;
   
END;

