create
    definer = ims@`%` procedure USP_Mnt_Mntng_Svr_I(IN v_Svr_Ip varchar(15), IN v_Svr_Desc varchar(4000),
                                                    IN v_Cpu_ThresHold float, IN v_Memory_ThresHold float,
                                                    IN v_Network_ThresHold float)
BEGIN
	IF v_Network_ThresHold is null then
		set v_Network_ThresHold = 0;
	END IF;
	INSERT INTO Mntng_Svr(Svr_Ip, Svr_Desc, Cpu_ThresHold, Memory_ThresHold, Network_ThresHold)
	SELECT v_Svr_Ip, v_Svr_Desc, v_Cpu_ThresHold, v_Memory_ThresHold, v_Network_ThresHold;
	
END;

