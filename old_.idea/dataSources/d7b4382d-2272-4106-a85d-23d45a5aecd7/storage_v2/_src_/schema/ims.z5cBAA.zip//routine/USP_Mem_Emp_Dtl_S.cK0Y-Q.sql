create
    definer = ims@`%` procedure USP_Mem_Emp_Dtl_S(IN v_Emp_No varchar(10))
BEGIN
	SELECT
	Emp_No
	, Organ_No
	, Emp_Passwd
	, Emp_Nm
	, Agent_Key
	, Dept_No
	, Role_No
	, Last_PassWd_Edit_Dt
	, Auth_Key
	, Del_Stat
	FROM emp
	WHERE Emp_No = v_Emp_No;
END;

