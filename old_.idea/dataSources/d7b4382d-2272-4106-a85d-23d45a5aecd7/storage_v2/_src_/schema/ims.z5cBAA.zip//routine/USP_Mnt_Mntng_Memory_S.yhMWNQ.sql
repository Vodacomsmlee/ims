create
    definer = ims@`%` procedure USP_Mnt_Mntng_Memory_S(IN v_Svr_Ip varchar(15))
BEGIN
	SELECT 
	IFNULL(ROUND(((Total_Qty - Use_Psbl_Qty)/Total_Qty)*100,2),0) as Last_Mem_Use
	, Total_Qty
	, ROUND((Total_Qty -Use_Psbl_Qty),2) as Used_Qty
	, Use_Psbl_Qty
	FROM Mntng_Memory_Hist 
	WHERE Svr_Ip =  v_Svr_Ip
	ORDER BY Reg_Dt DESC LIMIT 1;
END;

