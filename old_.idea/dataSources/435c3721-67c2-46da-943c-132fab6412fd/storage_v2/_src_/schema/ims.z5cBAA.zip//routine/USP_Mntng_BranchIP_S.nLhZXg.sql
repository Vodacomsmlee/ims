create
    definer = ims@`%` procedure USP_Mntng_BranchIP_S()
BEGIN
	DECLARE v_branch_code INT;
	select Cmm_Code INTO v_branch_code FROM Code_Cmm WHERE Cmm_Code_Nm = 'OpenScapeBranch 정보';
	SELECT * FROM Code_Cmm_Dtl WHERE Cmm_Code = v_branch_code and Del_Stat = 0;
	
END;

