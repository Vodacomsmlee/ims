create
    definer = ims@`%` procedure USP_QOS_Config_S()
begin
	select name, value from QOS_CONFIG order by name;
end;

