create
    definer = ims@`%` procedure USP_Cmm_LoginChk_S(IN v_Emp_No varchar(10), IN v_Emp_Passwd varchar(50))
BEGIN
	DECLARE v_Result INT;
	SET v_Result = 0;
	-- IF EXISTS(SELECT Emp_No FROM Emp WHERE Emp_No = v_Emp_No AND Emp_Passwd = SHA2(v_Emp_Passwd,256) AND Del_Stat = 0 LIMIT 1) then
	IF EXISTS(SELECT Emp_No FROM Emp WHERE Emp_No = v_Emp_No AND Del_Stat = 0 LIMIT 1) THEN
		SELECT Emp_No
		, Emp_Nm
		, IFNULL(CAST(Agent_Key AS CHAR(30)),'') Agent_Key
		, IFNULL(CAST(Dept_No AS CHAR(30)),'') Dept_No
		, DATE_FORMAT(Last_PassWd_Edit_Dt,'%Y-%m-%d %T:%f') Last_PassWd_Edit_Dt
		, DATEDIFF(Last_PassWd_Edit_Dt, CURRENT_TIMESTAMP) as expireCnt
		, A.Role_No
		, B.desc 
		FROM Emp A
		JOIN `Role` B ON A.Role_No = B.Role_No
		WHERE Emp_No = v_Emp_No
		-- AND Emp_Passwd = SHA2(v_Emp_Passwd,256)
		AND A.Del_Stat = 0;
		
	end if;
END;

