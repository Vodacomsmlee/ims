create
    definer = ims@`%` procedure USP_Mng_CtiHuntGroup_MOH_S()
BEGIN
	-- MOH 헌트그룹
	SELECT resourcename, resourcenum FROM ims_ifx.Resources WHERE resourcetype = 3 AND subtype = 3 ORDER BY resourcenum;
END;

