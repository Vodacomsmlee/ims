create
    definer = ims@`%` procedure USP_Mntng_Wallbarod_NoticeTest_S()
BEGIN
	SELECT A.Group_Nm AS TITLE, 'Y' AS EMERGENCY
	FROM Mng_Cti_Group A 
	LEFT OUTER JOIN Dept B ON A.Dept_No = B.Dept_No AND  B.Del_Stat = 0
	LEFT OUTER JOIN ims_ifx.virtualgroups C  ON A.Group_Key = C.virtualgroupkey
	WHERE A.Del_Stat = 0;
END;

