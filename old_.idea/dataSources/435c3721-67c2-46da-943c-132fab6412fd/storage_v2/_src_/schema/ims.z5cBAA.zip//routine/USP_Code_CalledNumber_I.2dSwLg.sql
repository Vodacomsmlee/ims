create
    definer = ims@`%` procedure USP_Code_CalledNumber_I(IN v_Called_Key int, IN v_CalledNumber varchar(20),
                                                        IN v_Desc varchar(100), IN v_Use_Stat tinyint unsigned)
BEGIN
	-- select resourcenum INTO v_CalledNumber
	-- FROM ims_ifx.monitoredresources WHERE resourcekey = v_Called_Key;
	INSERT INTO Code_CalledNumber(Called_Key, CalledNumber, `Desc`, Use_Stat)VALUES(0, v_CalledNumber, v_Desc, v_Use_Stat);
END;

