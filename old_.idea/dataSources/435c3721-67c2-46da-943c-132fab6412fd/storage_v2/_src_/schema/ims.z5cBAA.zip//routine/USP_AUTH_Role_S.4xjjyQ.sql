create
    definer = ims@`%` procedure USP_AUTH_Role_S(IN v__EMP_NO varchar(20))
BEGIN
	DECLARE v_Role_No INT;
	-- Role 확인
	select Role_No INTO v_Role_No FROM Emp  WHERE Emp_No = v__EMP_NO;
	-- 슈퍼 관리자외 다른 Role은 슈퍼관리자 Role 안가져오게
	IF v_Role_No = 1 then
		SELECT A.Role_No
		, Role_Nm
		, Use_Stat
		, FN_CMM_CmmDtlName_S(3,Use_Stat) Use_Stat_Nm
		, CCAPP_Admin_Stat
        -- , (SELECT GROUP_CONCAT(Emp_Nm) FROM Emp WHERE Del_Stat = 0 AND Role_No = A.Role_No) As TargetEmp
		FROM Role A
		WHERE A.Del_Stat = 0;
	ELSE
		SELECT A.Role_No
		, Role_Nm
		, Use_Stat
		, FN_CMM_CmmDtlName_S(3,Use_Stat) Use_Stat_Nm
		, CCAPP_Admin_Stat
        -- , (SELECT GROUP_CONCAT(Emp_Nm) FROM Emp WHERE Del_Stat = 0 AND Role_No = A.Role_No) As TargetEmp
		FROM Role A
		WHERE A.Del_Stat = 0
		AND Role_No <> 1;
	end if;
END;

