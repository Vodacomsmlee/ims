create
    definer = ims@`%` procedure USP_Mem_Emp_U(IN v_Emp_No varchar(10), IN v_Emp_Nm varchar(30),
                                              IN v_Emp_Passwd varchar(50), IN v_Dept_No int, IN v_Role int,
                                              IN v_AgentKey int, IN v_Group_Seq varchar(4000), IN v_pwdStat varchar(5))
BEGIN
	DECLARE v_Cur_Dept_No INT;
	DECLARE v_Cur_AgentKey INT;
	DECLARE v_Cur_Emp_Nm VARCHAR(30);
	DECLARE v_UserID VARCHAR(20);
	DECLARE v_Dept_Nm VARCHAR(50);
	DECLARE v_Cur_Organ_No VARCHAR(20);
	
	IF EXISTS(SELECT Emp_No FROM Emp WHERE Emp_No = v_Emp_No AND Del_Stat = 0) THEN
			
		SELECT Dept_No, Agent_Key, Emp_Nm INTO v_Cur_Dept_No,v_Cur_AgentKey , v_Cur_Emp_Nm
		FROM Emp  
		WHERE Emp_No = v_Emp_No
		AND Del_Stat = 0;
		
		IF v_AgentKey IS NULL OR v_AgentKey = 0 THEN
			SET v_AgentKey = v_Cur_AgentKey;
		END IF;
		
		UPDATE Emp
		SET Emp_No = v_Emp_No
		,Emp_Passwd =(CASE WHEN v_pwdStat = 'true' THEN SHA2(v_Emp_Passwd, 256) ELSE Emp_Passwd END)
		,Emp_Nm = v_Emp_Nm
		,Agent_Key = v_AgentKey 
		,Dept_No = v_Dept_No
		,Role_No = v_Role
		WHERE Emp_No = v_Emp_No;
		
		
		
		
		-- 녹취 계정 수정
		-- SET v_UserID = RTRIM(LTRIM(ims_ifx.FN_Get_UserID(v_AgentKey)));
		-- CALL record.sp_User_insert_app(v_UserID,v_Emp_Nm,'9999','U');
	
		SELECT Dept_Nm INTO v_Dept_Nm FROM Dept WHERE Dept_No = v_Dept_No;
	
		-- Agent_Key 변경시 Emp_Hist 변경
		IF v_AgentKey <> v_Cur_AgentKey THEN
			-- 이전 HIST 정보 업데이트
			UPDATE Emp_Hist
			SET Apply_End_Dt = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
			WHERE Agent_Key = v_Cur_AgentKey
			AND Emp_No = v_Emp_No
			AND Dept_No = v_Cur_Dept_No
			AND Apply_End_Dt IS NULL;
			
			INSERT INTO Emp_Hist(Agent_Key, Emp_No, Organ_No, Emp_Nm, Dept_No, Dept_Nm, Apply_Start_Dt, Reg_Dt)
			SELECT v_AgentKey, v_Emp_No, v_Cur_Organ_No, v_Emp_Nm, v_Dept_No, v_Dept_Nm, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP;
		END IF;
		
		-- 부서 변경시 Emp_Hist 변경
		IF v_Dept_No <> v_Cur_Dept_No OR v_Emp_Nm <> v_Cur_Emp_Nm THEN
			-- 이전 HIST 정보 업데이트
			UPDATE Emp_Hist
			SET Apply_End_Dt = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
			WHERE Agent_Key = v_AgentKey
			AND Emp_No = v_Emp_No
			AND Dept_No = v_Cur_Dept_No
			AND Apply_End_Dt IS NULL;
			
			INSERT INTO Emp_Hist(Agent_Key, Emp_No, Organ_No, Emp_Nm, Dept_No, Dept_Nm, Apply_Start_Dt, Reg_Dt)
			SELECT v_AgentKey, v_Emp_No, v_Cur_Organ_No, v_Emp_Nm, v_Dept_No, v_Dept_Nm, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP;
		END IF;
	END IF;
END;

