create
    definer = ims@`%` procedure USP_Mng_Ivr_Voice_I(IN v_FILE_NAME varchar(200), IN v_svcInfo varchar(4000),
                                                    IN v__EMP_NO varchar(30), IN v_ORIGINAL_FILE_NAME varchar(200))
BEGIN
	DECLARE v_MAX_SVCID VARCHAR(50);
	DECLARE v_NEW_SVCID VARCHAR(50);
	select MAX(SC_PROMPT) INTO v_MAX_SVCID FROM Mng_Ivr_Prompt;
	SET v_NEW_SVCID = CONCAT('SV',RIGHT(CONCAT('000',CAST(cast(REPLACE(v_MAX_SVCID,'SV','') as SIGNED INTEGER)+1 AS CHAR(30))),4));
	INSERT INTO Mng_Ivr_Prompt(SC_PROMPT, SC_FILENAME, SC_DESCRIPTION, SC_REGDATE,SC_REGUSER,SC_ORGNL_FILENAME)
	VALUES(UPPER(v_NEW_SVCID), v_FILE_NAME, v_svcInfo, SYSDATE(3),v__EMP_NO,v_ORIGINAL_FILE_NAME);
	
END;

