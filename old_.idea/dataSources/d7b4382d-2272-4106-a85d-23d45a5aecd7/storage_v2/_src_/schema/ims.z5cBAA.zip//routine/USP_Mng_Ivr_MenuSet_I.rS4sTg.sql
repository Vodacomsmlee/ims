create
    definer = ims@`%` procedure USP_Mng_Ivr_MenuSet_I(IN v_SC_MENUNAME varchar(50), IN v_SC_PROMPT varchar(50),
                                                      IN v_SC_DIGIT varchar(50))
BEGIN
	INSERT INTO Mng_Ivr_ScenarioMenu(SC_MENUNAME,SC_PROMPT,SC_DIGIT)
	VALUES(v_SC_MENUNAME,v_SC_PROMPT,v_SC_DIGIT);
END;

