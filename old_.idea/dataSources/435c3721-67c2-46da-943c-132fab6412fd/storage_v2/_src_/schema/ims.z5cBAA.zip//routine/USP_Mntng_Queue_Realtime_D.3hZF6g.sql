create
    definer = ims@`%` procedure USP_Mntng_Queue_Realtime_D(IN v_queueKey int(10))
BEGIN
DELETE FROM `mntng_queuerealtime` WHERE `QueueKey`=v_queueKey;
END;

