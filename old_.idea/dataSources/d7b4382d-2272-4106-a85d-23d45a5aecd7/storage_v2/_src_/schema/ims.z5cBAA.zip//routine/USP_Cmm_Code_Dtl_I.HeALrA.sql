create
    definer = ims@`%` procedure USP_Cmm_Code_Dtl_I(IN v_Cmm_Code int, IN v_Cmm_Dtl_Code varchar(200),
                                                   IN v_Cmm_Dtl_Code_Nm varchar(100))
BEGIN
	INSERT INTO Code_Cmm_Dtl(Cmm_Code, Cmm_Dtl_Code, Cmm_Dtl_Code_Nm)
	SELECT v_Cmm_Code, v_Cmm_Dtl_Code, v_Cmm_Dtl_Code_Nm;
	
END;

