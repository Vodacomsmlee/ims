create
    definer = ims@`%` procedure USP_Mnt_Mntng_Cpu2_I(IN v_Model varchar(100), IN v_physical int, IN v_logical int,
                                                     IN v_Host_Nm varchar(100), IN v_CpuUser float,
                                                     IN v_CpuSystem float, IN v_CpuIdle float, IN v_SvrIp varchar(15))
BEGIN
/*
	IF NOT EXISTS(SELECT TOP 1 '1' FROM  dbo.Mntng_Cpu_Info WITH(READUNCOMMITTED) WHERE Svr_Ip = @SvrIp )
	BEGIN
		INSERT INTO dbo.Mntng_Cpu_Info(Svr_Ip, Vendor, Model, Speed, Cpu_Cnt)
		VALUES(@SvrIp, @Vendor, @Model, @Mhz, @CpuCnt)
	END
	*/
	-- Host 명
	DECLARE v_Old_Host_Nm VARCHAR(100);
	IF v_CpuUser is null then
		set v_CpuUser = 0;
	END IF;
	IF v_CpuSystem is null then
		set v_CpuSystem = 0;
	END IF;
	IF v_CpuIdle is null then
		set v_CpuIdle = 0;
	END IF;
	
	select Host_Nm INTO v_Old_Host_Nm FROM Mntng_Svr WHERE Svr_Ip = v_SvrIp;
	
	IF (v_Old_Host_Nm <> v_Host_Nm) OR v_Old_Host_Nm IS NULL then
		UPDATE Mntng_Svr
		SET Host_Nm = v_Host_Nm
		WHERE Svr_Ip = v_SvrIp;
	end if;
	INSERT INTO Mntng_Cpu_Hist(Svr_Ip, User_Qty, System_Qty, Idle_Qty)
	VALUES(v_SvrIp, v_CpuUser, v_CpuSystem, v_CpuIdle);
END;

