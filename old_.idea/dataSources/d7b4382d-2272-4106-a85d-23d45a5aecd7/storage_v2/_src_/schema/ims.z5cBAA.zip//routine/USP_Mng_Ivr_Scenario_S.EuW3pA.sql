create
    definer = ims@`%` procedure USP_Mng_Ivr_Scenario_S(IN v__Emp_No varchar(10))
BEGIN
	IF v__Emp_No is null then
		set v__Emp_No = '';
	END IF;
	CALL FN_CMM_Grant_S(v__Emp_No,6);
	
	SELECT
	SC_CODE
	,Dept_No
	,(select dept_nm from Dept where dept_no = A.dept_no) AS Dept_Nm
	,SC_NAME
	,SC_PROMPT_YN
	,SC_PROMPT
	,(SELECT SC_FILENAME FROM Mng_Ivr_Prompt where SC_PROMPT = A.SC_PROMPT) AS SC_PROMPT_NM
	,SC_NEXT
	,FN_CMM_CmmDtlName_S(9,SC_NEXT) AS SC_NEXTNM
	,SC_NEXT_TARGET
	,(
		CASE SC_NEXT
			WHEN 1 THEN -- MENU : 1
				(SELECT SC_MENUNAME FROM Mng_Ivr_ScenarioMenu WHERE SC_MENU = SC_NEXT_TARGET)
			WHEN 2 THEN -- ROUTE : 2
				(SELECT RT_ROUTENAME FROM Mng_Ivr_ScenarioRoute WHERE RT_ROUTE = SC_NEXT_TARGET)
			WHEN 4 THEN -- NOTICE : 4
				(SELECT NT_NAME FROM Mng_Ivr_Notice WHERE NT_Code = SC_NEXT_TARGET)
			WHEN 9 THEN -- WORKTIME : 9
				(SELECT WH_Code_Nm FROM Mng_Ivr_WorkhourSet WHERE WH_Code = SC_NEXT_TARGET)
			ELSE
					-- CALLBACK, END, SMS : 3,5,6,
					-- CAST([SC_NEXTNAME] AS VARCHAR)
				SC_NEXT_TARGET
		END
	)AS SC_NEXT_TARGET_NM
	,SC_NOTI_YN
	,SC_NOTI
	,(CASE SC_NOTI WHEN 0 THEN '' ELSE(SELECT NT_NAME FROM Mng_Ivr_Notice WHERE NT_Code = SC_NOTI) END) AS SC_NOTI_NM
	, '' aS SC_WORKTIME_CODE
   FROM Mng_Ivr_Scenario A 
   WHERE Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
   AND Del_Stat = 0
   order by SC_NAME;
   
END;

