create
    definer = ims@`%` procedure USP_AUTH_Role_D(IN v_Role_No int)
BEGIN
	UPDATE Role
	SET Del_Stat = 1
	WHERE Role_No = v_Role_No;
END;

