create
    definer = ims@`%` procedure USP_Mnt_Mntng_Gateway_IP_S()
BEGIN
	declare v_SmsReSendMin int;
	
	select cast(Cmm_Dtl_Code as int) into v_SmsReSendMin from code_cmm_dtl where Cmm_Code = 13; -- 13은 하드코딩
	SELECT A.Svr_Ip, A.Svr_Seq, A.Svr_Desc, A.Last_Sms_SendDt
	, ifnull(TIMESTAMPDIFF(MINUTE, A.Last_Sms_SendDt, SYSDATE()), v_SmsReSendMin+1) as SmsSend_Elapse_Min -- SMS 발송 경과시간(분)
	, ThresHold_Cnt
	, Collect_ThresHold
	FROM mntng_svr A
	WHERE A.Svr_Type = 2 -- 0:서버, 1:네트워크 스위치, 2:Gateway
	AND A.Del_Stat = 0;
END;

