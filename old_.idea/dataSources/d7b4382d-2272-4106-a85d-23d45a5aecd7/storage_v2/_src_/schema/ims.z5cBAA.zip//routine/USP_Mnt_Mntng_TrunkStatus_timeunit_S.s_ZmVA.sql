create
    definer = ims@`%` procedure USP_Mnt_Mntng_TrunkStatus_timeunit_S(IN v_Trunk_Ip varchar(15))
BEGIN
	SELECT DATE_FORMAT(`DATE`,'%H') AS dt
	, MAX(total) min_total
	, MAX(busy) max_busy
	FROM Mntng_TrunkStatus 
	WHERE ip = v_Trunk_Ip
	AND `DATE` > DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
	GROUP BY DATE_FORMAT(`DATE`,'%H');
END;

