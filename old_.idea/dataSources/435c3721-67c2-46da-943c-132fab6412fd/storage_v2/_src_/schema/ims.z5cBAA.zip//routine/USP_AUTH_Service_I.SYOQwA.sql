create
    definer = ims@`%` procedure USP_AUTH_Service_I(IN v_Svc_Nm varchar(100), IN v_Svc_Url varchar(200),
                                                   IN v_Use_Stat tinyint unsigned)
BEGIN
	IF v_Use_Stat is null then
		set v_Use_Stat = 1;
	END IF;
	
	IF IFNULL(v_Svc_Nm,'') <> '' AND IFNULL(v_Svc_Url,'') <> '' then
		INSERT INTO Role_Service(Svc_Nm, Svc_Url, Use_Stat)
		SELECT v_Svc_Nm, v_Svc_Url, v_Use_Stat;
	end if;
   
END;

