create
    definer = ims@`%` procedure USP_Mnt_Mntng_DNISStatus_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	call FN_CMM_Grant_S(v__Emp_No,5);
	
	SELECT
		DNIS,FN_CalledNumberToDesc_S(dnis) DNIS_NAME,SKIND,
		-- IFNULL(FN_CtiGroup_Nm_S(Group_Seq),'') SERVICE_NAME,
		 case when SKIND = '' then '' else IFNULL(FN_IvrService_Nm_S(SKIND),'') end SERVICE_NAME,
		-- ,IFNULL(FN_IvrService_Nm_S(SKIND),'') SERVICE_NAME,
		SUM(CASE WHEN ROUTENUM = '' THEN CNT ELSE 0 END) TRANS_CNT,
		SUM(CASE WHEN ROUTENUM != '' THEN CNT ELSE 0 END) AGENT_CNT,
		SUM(CNT) RECEIVE_CNT
	FROM(
		SELECT
		DNIS,SKIND, ROUTENUM,
		COUNT(*) CNT
		FROM(
			select 
				dnis,
				SKIND,
				ROUTENUM
			from TB_IVRSTATISTICS
			WHERE DNIS in(SELECT * FROM FN_CMM_Grant_S)
			AND startdate > DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
		) AS A
		GROUP BY DNIS,SKIND,ROUTENUM
	) AS AGG
	GROUP BY DNIS,SKIND
	ORDER BY DNIS_NAME;
end;

