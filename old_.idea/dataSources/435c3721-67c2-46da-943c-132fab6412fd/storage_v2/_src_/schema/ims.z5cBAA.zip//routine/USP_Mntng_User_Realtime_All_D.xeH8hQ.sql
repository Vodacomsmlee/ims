create
    definer = ims@`%` procedure USP_Mntng_User_Realtime_All_D()
BEGIN
TRUNCATE TABLE `mntng_userrealtime`;
END;

