create
    definer = ims@`%` procedure USP_Mnt_Mntng_GroupCumulative_S(IN v_Svr_Ip varchar(15))
BEGIN
	SELECT ROUND((Used_Qty/Total_Qty)*100,2) as Last_Mem_Use
	, Total_Qty
	, Used_Qty
	, Use_Psbl_Qty
	FROM Mntng_Memory_Hist 
	WHERE Svr_Ip =  v_Svr_Ip
	ORDER BY Reg_Dt DESC LIMIT 1;
END;

