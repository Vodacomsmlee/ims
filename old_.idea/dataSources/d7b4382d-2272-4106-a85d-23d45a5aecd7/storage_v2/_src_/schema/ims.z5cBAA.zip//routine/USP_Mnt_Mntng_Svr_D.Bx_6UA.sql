create
    definer = ims@`%` procedure USP_Mnt_Mntng_Svr_D(IN v_Svr_Seq int)
BEGIN
	UPDATE Mntng_Svr
	SET Del_Stat = 1
	WHERE Svr_Seq = v_Svr_Seq;
	
END;

