create
    definer = ims@`%` procedure USP_Cmm_Code_S()
BEGIN
	SELECT Cmm_Code, Cmm_Code_Nm
	FROM Code_Cmm 
	WHERE Del_Stat = 0; 
END;

