create
    definer = ims@`%` procedure USP_Mntng_Group_Cumulative_U(IN v_date datetime, IN v_groupKey int(10),
                                                             IN v_callsReceived int(10), IN v_callsOffered int(10),
                                                             IN v_consultOut int(10), IN v_transferOut int(10),
                                                             IN v_receivedHereOfferedElsewhere int(10))
BEGIN
UPDATE `mntng_groupcumulative` SET
`Received`=v_callsReceived
,`Offered`=v_callsOffered
,`ConsultOut`=v_consultOut
,`TransferOut`=v_transferOut
,`ReceivedHereOfferedElsewhere`=v_receivedHereOfferedElsewhere
WHERE
`date`=v_date AND `GroupKey`=v_groupKey;
END;

