create
    definer = ims@`%` procedure USP_Mng_Ivr_Notice_S(IN v__Emp_No varchar(10))
BEGIN
	IF v__Emp_No is null then
		set v__Emp_No = '';
	END IF;
	CALL FN_CMM_Grant_S(v__Emp_No,6);
	
	SELECT NT_Code
	, NT_NAME
	, A.Dept_No
	, (select dept_nm from Dept where dept_no = A.dept_no) AS Dept_Nm
	, CONCAT(SUBSTR(NT_SERVICE_SDATE,1,4),'-',SUBSTR(NT_SERVICE_SDATE,5,2),'-',SUBSTR(NT_SERVICE_SDATE,7,2)) AS NT_SERVICE_SDATE
	, CONCAT(SUBSTR(NT_SERVICE_EDATE,1,4),'-',SUBSTR(NT_SERVICE_EDATE,5,2),'-',SUBSTR(NT_SERVICE_EDATE,7,2)) AS NT_SERVICE_EDATE
	, NT_USE_YN
	, NT_tts_TIMEREAD_YN
	, CONCAT(SUBSTR(NT_tts_SDate,1,4),'-',SUBSTR(NT_tts_SDate,5,2),'-',SUBSTR(NT_tts_SDate,7,2)) AS NT_tts_SDate
	, CONCAT(SUBSTR(NT_tts_STime,1,2),':',SUBSTR(NT_tts_STime,3,2)) AS NT_tts_STime
	, CONCAT(SUBSTR(NT_tts_EDate,1,4),'-',SUBSTR(NT_tts_EDate,5,2),'-',SUBSTR(NT_tts_EDate,7,2)) AS NT_tts_EDate
	, CONCAT(SUBSTR(NT_tts_ETime,1,2),':',SUBSTR(NT_tts_ETime,3,2)) AS NT_tts_ETime
	, NT_PROMPT
	, (SELECT SC_FILENAME FROM Mng_Ivr_Prompt where SC_PROMPT = NT_PROMPT) AS NT_PROMPT_NM
	, NT_PROMPT_END
	, (SELECT SC_FILENAME FROM Mng_Ivr_Prompt where SC_PROMPT = NT_PROMPT_END) AS NT_PROMPT_END_NM
	, NT_PROMPT_END2
	, (SELECT SC_FILENAME FROM Mng_Ivr_Prompt where SC_PROMPT = NT_PROMPT_END2) AS NT_PROMPT_END2_NM
	FROM Mng_Ivr_Notice A 
	WHERE Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
	AND Del_Stat = 0
	ORDER BY NT_NAME;
   
END;

