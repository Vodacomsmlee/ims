create
    definer = ims@`%` procedure USP_Mnt_Mntng_Disk_I(IN v_DiskDevNm varchar(50), IN v_DiskTotal float,
                                                     IN v_DiskUsed float, IN v_DiskAvail float,
                                                     IN v_DiskMount varchar(50), IN v_DiskType varchar(50),
                                                     IN v_SvrIp varchar(15))
BEGIN
	DECLARE v_DiskPer SMALLINT;
	-- 제외대상 DISK
	-- Disk_Type : UDF, ramfs, ext2 제외
	-- Disk_Nm : /, /dev/sda14, /dev/sda6, /dev/sda9, /dev/sda13, /dev/sda11, /dev/sda15, /dev/sda5, /dev/sda10, /dev/sda8, /dev/sda12
	
	-- v_DiskType NOT IN('UDF','ramfs','ext2') AND
	-- IF  v_DiskDevNm NOT IN('/','/dev/sda14','/dev/sda6','/dev/sda9','/dev/sda13','/dev/sda11','/dev/sda15', '/dev/sda5','/dev/sda10','/dev/sda8','/dev/sda12') then
	IF  v_DiskDevNm NOT IN('/dev/sda14','/dev/sda6','/dev/sda9','/dev/sda13','/dev/sda11','/dev/sda15', '/dev/sda5','/dev/sda10','/dev/sda8','/dev/sda12' ,'CD-ROM 디스크 (F:)') THEN
		SET v_SvrIp = REPLACE(v_SvrIp, '192.168.122.1','172.20.1.207'); -- fax
		SET v_SvrIp = REPLACE(v_SvrIp, '169.254.251.197','172.20.1.201'); -- rec
	
	
			IF v_DiskTotal = 0 THEN
				SET v_DiskPer  = 0;
			ELSE
				SET v_DiskPer = ROUND((v_DiskUsed/v_DiskTotal)*100,0);
			END IF;
			
			IF EXISTS(SELECT  1 FROM  Mntng_Disk_Hist  WHERE Svr_Ip = v_SvrIp AND Disk_Nm = v_DiskDevNm LIMIT 1) THEN
				UPDATE Mntng_Disk_Hist
				SET Total_Qty = v_DiskTotal,Used_Qty = v_DiskUsed,Use_Psbl_Qty = v_DiskAvail, 
				Use_Pct = v_DiskPer,Del_Stat = 0
				,Reg_Dt = SYSDATE(3)
				WHERE Svr_Ip = v_SvrIp AND Disk_Nm = v_DiskDevNm;
			ELSE
				INSERT INTO Mntng_Disk_Hist(Svr_Ip, Disk_Nm, Total_Qty, Used_Qty, Use_Psbl_Qty, Use_Pct, Disk_Type)
				VALUES(v_SvrIp, v_DiskDevNm, v_DiskTotal, v_DiskUsed, v_DiskAvail, v_DiskPer, v_DiskType);
			END IF;
	END IF;
END;

