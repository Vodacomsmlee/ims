create
    definer = ims@`%` procedure USP_QOS_Raw_U(IN v_nType int, IN v_LocalSubscriberNo varchar(15),
                                              IN v_MacAddr varchar(12), IN v_Callid varchar(40),
                                              IN v_protocolVersion int, IN v_Reason smallint,
                                              IN v_StartTime decimal(22), IN v_EndTime decimal(22),
                                              IN v_LocalIpAddr varchar(35), IN v_LocalRtpPort int,
                                              IN v_RemoteIpAddr varchar(35), IN v_RemoteRtpPort int,
                                              IN v_SsrcReceiving decimal(22), IN v_SsrcSending decimal(22),
                                              IN v_Codec int, IN v_MediaType int, IN v_PayloadType int,
                                              IN v_MaxPacketSize int, IN v_SilenceSuppression int,
                                              IN v_GoodPackets decimal(22), IN v_MaxJitter int, IN v_MaxInterJitter int,
                                              IN v_MaxJitterExceedPeriods int, IN v_AvgRoundTripDelay int,
                                              IN v_AvgRoundTripDelayExceeded bit, IN v_LostPackets int,
                                              IN v_DiscardedPackets int, IN v_LostPacketsExceededPeriods int,
                                              IN v_BA11consecutiveLostPackets varchar(25),
                                              IN v_ConsecutivePacketLossExceedPeriods int,
                                              IN v_BA11consecutiveGoodPackets varchar(25),
                                              IN v_ConsecutiveGoodPacketsExceedPeriods int,
                                              IN v_CntJitterBufferOverrun int, IN v_CntJitterBufferUnderrun int,
                                              IN v_CodecChangedOnTheFly bit, IN v_TresholdExceededPeriods int)
begin
	IF v_nType is null then
		set v_nType = 1;
	END IF;
	IF v_LocalSubscriberNo IS NULL then
		SET v_LocalSubscriberNo = '';
	end if;
	IF v_MacAddr is null then
		set v_MacAddr = '';
	END IF;
	IF v_Callid IS NULL then
		SET v_Callid = '';
	end if;
	IF v_protocolVersion is null then
		set v_protocolVersion = 0;
	END IF;
	IF v_Reason IS NULL then
		SET v_Reason = 0;
	end if;
	IF v_StartTime is null then
		set v_StartTime = 0;
	END IF;
	IF v_EndTime IS NULL then
		SET v_EndTime = 0;
	end if;
	IF v_LocalIpAddr IS NULL then
		SET v_LocalIpAddr = '';
	end if;
	IF v_LocalRtpPort IS NULL then
		SET v_LocalRtpPort = 0;
	end if;
	IF v_RemoteIpAddr IS NULL then
		SET v_RemoteIpAddr = '';
	end if;
	IF v_RemoteRtpPort IS NULL then
		SET v_RemoteRtpPort = 0;
	end if;
	IF v_SsrcReceiving IS NULL then
		SET v_SsrcReceiving = 0;
	end if;
	IF v_SsrcSending IS NULL then
		SET v_SsrcSending = 0;
	end if;
	IF v_Codec IS NULL then
		SET v_Codec = 0;
	end if;
	IF v_MediaType IS NULL then
		SET v_MediaType = 0;
	end if;
	IF v_PayloadType IS NULL then
		SET v_PayloadType = 0;
	end if;
	IF v_MaxPacketSize IS NULL then
		SET v_MaxPacketSize = 0;
	end if;
	IF v_SilenceSuppression IS NULL then
		SET v_SilenceSuppression = 0;
	end if;
	IF v_GoodPackets IS NULL then
		SET v_GoodPackets = 0;
	end if;
	IF v_MaxJitter IS NULL then
		SET v_MaxJitter = 0;
	end if;
	IF v_MaxInterJitter IS NULL then
		SET v_MaxInterJitter = 0;
	end if;
	IF v_MaxJitterExceedPeriods IS NULL then
		SET v_MaxJitterExceedPeriods = 0;
	end if;
	IF v_AvgRoundTripDelay IS NULL then
		SET v_AvgRoundTripDelay = 0;
	end if;
	IF v_AvgRoundTripDelayExceeded IS NULL then
		SET v_AvgRoundTripDelayExceeded = 0;
	end if;
	IF v_LostPackets IS NULL then
		SET v_LostPackets = 0;
	end if;
	IF v_DiscardedPackets IS NULL then
		SET v_DiscardedPackets = 0;
	end if;
	IF v_LostPacketsExceededPeriods IS NULL then
		SET v_LostPacketsExceededPeriods = 0;
	end if;
	IF v_BA11consecutiveLostPackets IS NULL then
		SET v_BA11consecutiveLostPackets = '';
	end if;
	
	UPDATE QOS_RAW_DATA 
	set 
		protocolVersion=v_protocolVersion,
		Reason=v_Reason,
		StartTime=v_StartTime,
		EndTime=v_EndTime,
		LocalIpAddr=v_LocalIpAddr,
		LocalRtpPort=v_LocalRtpPort,
		RemoteIpAddr=v_RemoteIpAddr,
		RemoteRtpPort=v_RemoteRtpPort,
		SsrcReceiving=v_SsrcReceiving,
		SsrcSending=v_SsrcSending,
		Codec=v_Codec,
		MediaType=v_MediaType,
		PayloadType=v_PayloadType,
		MaxPacketSize=v_MaxPacketSize,
		SilenceSuppression=v_SilenceSuppression,
		GoodPackets=v_GoodPackets,
		MaxJitter=v_MaxJitter,
		MaxInterJitter=v_MaxInterJitter,
		MaxJitterExceedPeriods=v_MaxJitterExceedPeriods,
		AvgRoundTripDelay=v_AvgRoundTripDelay,
		AvgRoundTripDelayExceeded=v_AvgRoundTripDelayExceeded,
		LostPackets=v_LostPackets,
		DiscardedPackets=v_DiscardedPackets,
		LostPacketsExceededPeriods=v_LostPacketsExceededPeriods,
		BA11consecutiveLostPackets=v_BA11consecutiveLostPackets,
		ConsecutivePacketLossExceedPeriods=v_ConsecutivePacketLossExceedPeriods,
		BA11consecutiveGoodPackets=v_BA11consecutiveGoodPackets,
		ConsecutiveGoodPacketsExceedPeriods=v_ConsecutiveGoodPacketsExceedPeriods,
		CntJitterBufferOverrun=v_CntJitterBufferOverrun,
		CntJitterBufferUnderrun=v_CntJitterBufferUnderrun,
		CodecChangedOnTheFly=v_CodecChangedOnTheFly,
		TresholdExceededPeriods=v_TresholdExceededPeriods
	WHERE
		MacAddr=v_MacAddr and Callid=v_Callid; 
END;

