create
    definer = ims@`%` procedure USP_Stt_IVR_CallbackList_S(IN v_destinations varchar(4000), IN v_Start_Dt datetime,
                                                           IN v_End_Dt datetime)
BEGIN
	call FN_CMM_Split_S(v_destinations,'|');
	
	SELECT
	CB_DNIS
	, FN_CalledNumberToDesc_S(CB_DNIS) as DNIS_NAME
	, Group_Seq
	, IFNULL(FN_CtiGroup_Nm_S(Group_Seq),'') AS SERVICE_NAME
	, CB_CALLERID
	, CB_CALLBACKNUM
	, DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d %T') AS CB_CALLBACKDATETIME
	, IFNULL(DATE_FORMAT(CB_CALLDATETIME,'%Y-%m-%d %T'),'') AS CB_CALLDATETIME
	, IFNULL(CB_AGENTID,'') AS CB_AGENTID
	, ims.FN_Get_UserIdToUserNm(CB_AGENTID) AS AGENT_NAME
	, (
		CASE WHEN CB_RESULT = 0 THEN 'N'
		   WHEN CB_RESULT = 2 THEN 'Y'
		   WHEN CB_RESULT = 4 THEN 'N'
		   ELSE '' 
		END) as CB_RESULT
	FROM Mng_Ivr_Callback cb  
	LEFT OUTER JOIN  TB_IVRSTATISTICS stt ON cb.CB_CALLID = stt.CALLID
	WHERE cb.CB_CALLID IS NOT NULL
	AND CB_DNIS IN(SELECT `VALUE` FROM FN_CMM_Split_S)
	AND CB_CALLBACKDATETIME >= v_Start_Dt
	AND DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d') <= DATE_FORMAT(v_End_Dt,'%Y-%m-%d')
	ORDER BY CB_SEQUENCE;
END;

