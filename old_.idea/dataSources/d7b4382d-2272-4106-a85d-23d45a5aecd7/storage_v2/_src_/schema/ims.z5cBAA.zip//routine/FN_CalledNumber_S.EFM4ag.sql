create
    definer = ims@`%` function FN_CalledNumber_S(v_Called_Seq int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   select   CalledNumber INTO v_RETURN FROM Code_CalledNumber  WHERE Seq = v_Called_Seq
   AND Del_Stat = 0;
   RETURN v_RETURN;
END;

