create
    definer = ims@`%` procedure USP_Mnt_Mntng_Dash_WaitCallStatus_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	call FN_CMM_Grant_S(v__Emp_No,2);
	
	SELECT
	SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime < 11 THEN 1 ELSE 0 END)
			ELSE 0
		END) as IN10
	,SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime < 21 AND TotalWaitTime > 10 THEN 1 ELSE 0 END)
			ELSE 0
		END) as IN20
	,SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime < 31 AND TotalWaitTime > 20 THEN 1 ELSE 0 END)
			ELSE 0
		END) as IN30
	,SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime < 41 AND TotalWaitTime > 30 THEN 1 ELSE 0 END)
			ELSE 0
		END) as IN40
	,SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime < 51 AND TotalWaitTime > 40 THEN 1 ELSE 0 END)
			ELSE 0
		END) as IN50
	,SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime < 61 AND TotalWaitTime > 50 THEN 1 ELSE 0 END)
			ELSE 0
		END) as IN60
	,SUM(CASE 
			WHEN CurrentState IN(5,25) THEN (CASE WHEN TotalWaitTime > 60 THEN 1 ELSE 0 END)
			ELSE 0
		END) as OVER60
	FROM Mntng_ContactRealtime
	WHERE QueueKey in(SELECT * FROM FN_CMM_Grant_S);
END;

