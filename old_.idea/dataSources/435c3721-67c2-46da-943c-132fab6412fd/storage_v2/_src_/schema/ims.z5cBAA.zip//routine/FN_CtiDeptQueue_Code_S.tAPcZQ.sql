create
    definer = ims@`%` function FN_CtiDeptQueue_Code_S(v_Dept_No int) returns varchar(100)
BEGIN
	   DECLARE v_RETURN VARCHAR(100);
	   SELECT  Que_Code INTO v_RETURN FROM code_dept_que WHERE Dept_No = v_Dept_No;
	   RETURN v_RETURN;
    END;

