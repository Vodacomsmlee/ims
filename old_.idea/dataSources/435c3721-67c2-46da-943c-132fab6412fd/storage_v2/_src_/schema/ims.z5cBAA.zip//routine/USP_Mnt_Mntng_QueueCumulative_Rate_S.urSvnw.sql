create
    definer = ims@`%` procedure USP_Mnt_Mntng_QueueCumulative_Rate_S()
BEGIN
	SELECT
	sum(Answered) as Answered, sum(Received) as Received, sum(Abandoned) as Abandoned, sum(Redirected) as Redirected
	,FORMAT(ROUND(sum(Answered)*100.0/sum(Received),2),2) as AnswerRate
	,FORMAT(ROUND(sum(Abandoned)*100.0/sum(Received),2),2) as AbandoneRate
	FROM(
		SELECT
		`date`, QueueKey, MaximumWaitTime,ServiceLevel,AverageWaitTime,AbandonedRate
		,Redirected,Answered,Abandoned,Received
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM
		Mntng_QueueCumulative
		WHERE `date` > CURDATE()
	) AS A_ROWS
	WHERE RN = 1;
END;

