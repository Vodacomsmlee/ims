create
    definer = ims@`%` procedure USP_Mng_Ivr_HolidaySet_U(IN v_HD_Code int, IN v_HD_Code_Nm varchar(70), IN v_Dept_No int)
BEGIN
	UPDATE Mng_Ivr_HolidaySet 
	SET HD_Code_Nm = v_HD_Code_Nm
	,Dept_No = v_Dept_No
	WHERE HD_Code = v_HD_Code;
END;

