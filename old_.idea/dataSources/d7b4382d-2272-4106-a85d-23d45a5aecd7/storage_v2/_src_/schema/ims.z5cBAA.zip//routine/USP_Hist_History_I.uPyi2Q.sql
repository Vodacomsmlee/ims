create
    definer = ims@`%` procedure USP_Hist_History_I(IN v_Procedure_Nm varchar(200), IN v_Emp_No varchar(10),
                                                   IN v_Parameter varchar(4000))
BEGIN
	IF RIGHT(UPPER(v_Procedure_Nm),2) IN('_I','_U','_D') then	
		INSERT INTO History(Procedure_Nm, Emp_No, Parameter)
		VALUES(v_Procedure_Nm, v_Emp_No, v_Parameter);
	end if;
END;

