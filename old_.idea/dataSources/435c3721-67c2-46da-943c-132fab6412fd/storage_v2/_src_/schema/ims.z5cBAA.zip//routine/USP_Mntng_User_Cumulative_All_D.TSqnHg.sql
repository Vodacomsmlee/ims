create
    definer = ims@`%` procedure USP_Mntng_User_Cumulative_All_D()
BEGIN
TRUNCATE TABLE `mntng_usercumulative`;
END;

