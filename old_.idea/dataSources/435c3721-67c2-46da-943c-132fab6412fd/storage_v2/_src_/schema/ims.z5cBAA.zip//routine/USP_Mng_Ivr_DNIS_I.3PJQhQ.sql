create
    definer = ims@`%` procedure USP_Mng_Ivr_DNIS_I(IN v_DNIS_NAME varchar(50), IN v_DNIS_NUMBER varchar(20),
                                                   IN v_DNIS_SERVICE varchar(20), IN v_DNIS_SC_CODE int)
BEGIN
	INSERT INTO Mng_Ivr_DNIS(DNIS_NAME, DNIS_NUMBER, DNIS_SERVICE, DNIS_SC_CODE)
	VALUES(v_DNIS_NAME, v_DNIS_NUMBER, v_DNIS_SERVICE, v_DNIS_SC_CODE);
	
END;

