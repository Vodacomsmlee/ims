create
    definer = ims@`%` procedure USP_Mnt_Mntng_Disk_S(IN v_Svr_Ip varchar(15))
BEGIN
	SELECT
	Disk_Nm
	, ROUND((Total_Qty/1024/1024/1024),1) as Total_Qty
	, ROUND((Used_Qty/1024/1024/1024),1) as Used_Qty
	, ROUND((Use_Psbl_Qty/1024/1024/1024),1) as Use_Psbl_Qty
	, IFNULL(Use_Pct,0) as Use_Pct
	FROM Mntng_Disk_Hist 
	WHERE Svr_Ip = v_Svr_Ip
	AND Del_Stat = 0
	AND Disk_Type <> 'UDF/cdrom'
	ORDER BY Disk_Nm; 
END;

