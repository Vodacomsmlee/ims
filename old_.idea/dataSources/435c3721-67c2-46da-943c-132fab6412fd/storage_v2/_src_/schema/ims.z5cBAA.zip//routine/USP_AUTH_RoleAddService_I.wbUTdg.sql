create
    definer = ims@`%` procedure USP_AUTH_RoleAddService_I(IN v_Svc_No int, IN v_Role_No int)
BEGIN
	DECLARE v_RTN_VALUE INT;
	SET v_RTN_VALUE = -1;
	IF v_Svc_No IS NULL OR v_Role_No IS NULL then
		SET v_RTN_VALUE = -2;
	ELSE
		IF EXISTS(SELECT Role_No FROM Role_Dtl  WHERE Role_No = v_Role_No AND Svc_No = v_Svc_No LIMIT 1) then
			DELETE FROM Role_Dtl WHERE Role_No = v_Role_No AND Svc_No = v_Svc_No;
			SET v_RTN_VALUE = 1;
		ELSE
			INSERT INTO Role_Dtl(Role_No, Svc_No)VALUES(v_Role_No, v_Svc_No);
			SET v_RTN_VALUE = 1;
		end if;
	end if;
	SELECT v_RTN_VALUE Result;
	
END;

