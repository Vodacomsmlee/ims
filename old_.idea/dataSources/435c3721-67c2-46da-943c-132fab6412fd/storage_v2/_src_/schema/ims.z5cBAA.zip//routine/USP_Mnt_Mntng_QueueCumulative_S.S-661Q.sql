create
    definer = ims@`%` procedure USP_Mnt_Mntng_QueueCumulative_S()
BEGIN
	SELECT
	`date`
	, QueueKey
	, FN_QueueNm_S(QueueKey) AS QueueName
	, SEC_TO_TIME(MaximumWaitTime) AS MaximumWaitTime
	, ServiceLevel
	, SEC_TO_TIME(AverageWaitTime) AS AverageWaitTime
	, CONCAT(FORMAT(ROUND(AbandonedRate*100,2),2),'%') AS AbandonedRate
	, Redirected,Answered,Abandoned,Received
	, CONCAT(FORMAT(ROUND(Answered*100.0/Received,2),2),'%') AS AnswerRate
	FROM(
		SELECT
		`date`, QueueKey, MaximumWaitTime,ServiceLevel,AverageWaitTime,AbandonedRate
		,Redirected,Answered,Abandoned,Received
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueCumulative
		WHERE `date` > TIMESTAMPADD(DAY,TIMESTAMPDIFF(DAY,0,CURRENT_TIMESTAMP),0)
	) AS A_ROWS
	WHERE RN = 1;
END;

