create
    definer = ims@`%` procedure USP_Mnt_Mntng_IVRMONITOR_S()
BEGIN
	SELECT 
		EXTENSION
		, (
			CASE 
				WHEN DNIS IS NOT NULL THEN (CASE WHEN DNIS = '' THEN '' ELSE FN_CalledNumberToDesc_S(DNIS) end)-- 추후에 변경 FN_CalledNumber_Desc_S						
			   ELSE ''
			END
		) AS DNIS_NAME
	FROM TB_IVRMONITOR;
END;

