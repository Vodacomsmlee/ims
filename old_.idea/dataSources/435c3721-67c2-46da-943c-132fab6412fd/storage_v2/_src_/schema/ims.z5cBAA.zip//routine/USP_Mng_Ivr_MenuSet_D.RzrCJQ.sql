create
    definer = ims@`%` procedure USP_Mng_Ivr_MenuSet_D(IN v_SC_MENU int)
BEGIN
	UPDATE Mng_Ivr_ScenarioMenu 
	SET Del_Stat = 1
	WHERE SC_MENU = v_SC_MENU;
END;

