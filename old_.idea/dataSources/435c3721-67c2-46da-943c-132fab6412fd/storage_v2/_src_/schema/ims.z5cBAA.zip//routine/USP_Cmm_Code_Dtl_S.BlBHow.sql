create
    definer = ims@`%` procedure USP_Cmm_Code_Dtl_S(IN v_Cmm_Code int)
BEGIN
	SELECT Cmm_Dtl_Code_Idx
	, Cmm_Code
	, Cmm_Dtl_Code
	, Cmm_Dtl_Code_Nm
	, Sort
	FROM Code_Cmm_Dtl 
	WHERE Cmm_Code = v_Cmm_Code
	AND Del_Stat = 0
	ORDER BY Sort; 
END;

