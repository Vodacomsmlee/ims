create
    definer = ims@`%` procedure USP_Mntng_Contact_Realtime_D(IN v_callID varchar(30))
BEGIN
DELETE FROM `mntng_contactrealtime` WHERE `CallID`=v_callID;
END;

