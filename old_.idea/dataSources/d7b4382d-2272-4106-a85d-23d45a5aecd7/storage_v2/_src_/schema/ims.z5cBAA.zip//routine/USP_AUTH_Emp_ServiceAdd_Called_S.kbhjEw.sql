create
    definer = ims@`%` procedure USP_AUTH_Emp_ServiceAdd_Called_S(IN v_Emp_No varchar(10))
BEGIN
	IF v_Emp_No IS NULL THEN
		SET v_Emp_No = '';
	END IF;
	
	SELECT Emp_No INTO v_Emp_No FROM Emp  WHERE Emp_No = v_Emp_No; 
	IF v_Emp_No <> '' THEN
		
		-- CalledNumber
		SELECT A.Seq
		, A.CalledNumber
		, A.`Desc`
		, (CASE WHEN IFNULL(B.Emp_No,'') = '' THEN '' ELSE ' checked' END) CHK
		FROM Code_CalledNumber A 
		LEFT OUTER JOIN Role_Emp_Grant B  ON A.Seq = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 3
		WHERE A.Del_Stat = 0;
		-- AND A.Use_Stat = 0;
   END IF;
END;

