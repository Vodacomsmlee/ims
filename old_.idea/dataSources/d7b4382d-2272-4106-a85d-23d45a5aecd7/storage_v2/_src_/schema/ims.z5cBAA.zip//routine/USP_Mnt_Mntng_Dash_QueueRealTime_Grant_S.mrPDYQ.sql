create
    definer = ims@`%` procedure USP_Mnt_Mntng_Dash_QueueRealTime_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	CALL FN_CMM_Grant_S(v__Emp_No,2);
	
	SELECT
	SUM(Contacts) AS WaitCalls -- 대기콜
	, ROUND(AVG(AbandonedRate),2) AS AbandonedRate
	, SEC_TO_TIME(MAX(OldestContactWaitTime)) AS OldestContactWaitTime -- 최장 대기 시간
	, SEC_TO_TIME(AVG(AverageAnsweredWaitTime)) AS AverageAnsweredWaitTime -- 평균 대기 시간
	, ROUND(AVG(ServiceLevel),2) AS ServiceLevel -- 서비스 레벨
	, SEC_TO_TIME(AVG(EstimatedAnsweredWaitTime)) AS EstimatedAnsweredWaitTime -- 예상 응대호 대기시간
	, ROUND(AVG(EstimatedServiceLevel),2) AS EstimatedServiceLevel -- 예상 응대호 대기시간
	FROM(
		SELECT
		`date`
		, QueueKey
		, Contacts
		, OverflowedContacts
		, ServiceLevel
		, EstimatedServiceLevel
		, AbandonedRate
		, OldestContactWaitTime
		, AverageAnsweredWaitTime
		, EstimatedAnsweredWaitTime
		, AverageAbandonedWaitTime
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueRealTime  
		WHERE QueueKey IN(SELECT * FROM FN_CMM_Grant_S)
	) AS A_ROWS
	WHERE RN = 1;
	
	
END;

