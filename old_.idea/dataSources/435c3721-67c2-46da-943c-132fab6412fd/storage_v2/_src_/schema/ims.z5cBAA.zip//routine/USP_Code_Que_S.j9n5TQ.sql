create
    definer = ims@`%` procedure USP_Code_Que_S()
BEGIN
   SELECT Seq
	, Que_Code
	, B.calltypename OSCC_Que_Nm
	, Que_Nm
	, Trans_Group_No
	, Use_Stat
	, (CASE WHEN Use_Stat = 0 THEN '사용' ELSE '사용 안함' END) Use_Stat_Nm
   FROM Code_Queue A 
   LEFT OUTER JOIN ims_ifx.calltypes B  ON A.Que_Code = B.calltypekey
   WHERE Del_Stat = 0;
END;

