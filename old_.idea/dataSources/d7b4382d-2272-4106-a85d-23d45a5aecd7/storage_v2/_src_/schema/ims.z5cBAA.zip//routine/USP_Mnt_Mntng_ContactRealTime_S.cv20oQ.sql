create
    definer = ims@`%` procedure USP_Mnt_Mntng_ContactRealTime_S()
BEGIN
	SELECT
	`date`, CallID,Destination,Source
	,(CASE WHEN CurrentState IS NOT NULL THEN FN_CMM_CmmDtlName_S(6,CurrentState) ELSE '' END) as StateName
	,TImeInState,TotalWaitTime
	,MediaType,CurrentPriority,Description
	,FN_QueueNm_S(QueueKey) QueueName
	,QualifyingAgentsCount
	FROM Mntng_ContactRealtime;
END;

