create
    definer = ims@`%` procedure USP_Mng_Ivr_CallBack_U(IN v_CB_CALLID varchar(60), IN v_CB_AGENTID varchar(20),
                                                       IN v_CB_RESULT tinyint unsigned, OUT v_RESULT tinyint unsigned)
BEGIN
	IF v_CB_RESULT is null then
	  set v_CB_RESULT = 0;
	END IF;
	
	IF NOT EXISTS(SELECT  CB_CALLID FROM Mng_Ivr_Callback WHERE CB_CALLID = v_CB_CALLID LIMIT 1) then
	  SET v_RESULT = 0;
	ELSE
	  UPDATE Mng_Ivr_Callback
	  SET CB_AGENTID = v_CB_AGENTID
	  ,CB_RESULT = v_CB_RESULT
	  ,CB_CALLDATETIME = CURRENT_TIMESTAMP
	  WHERE CB_CALLID = v_CB_CALLID;
	  
	  SET v_RESULT = 1;
	end if;
END;

