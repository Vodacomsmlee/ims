create
    definer = ims@`%` procedure USP_Mng_Ivr_Menu_D(IN v_SC_MENU int, IN v_SC_DIGIT varchar(50))
BEGIN
   DELETE FROM Mng_Ivr_ScenarioMenuSub
   WHERE SC_MENU = v_SC_MENU AND SC_DIGIT = v_SC_DIGIT;
END;

