create
    definer = ims@`%` procedure USP_Mntng_Contact_Realtime_All_S()
BEGIN
SELECT `date`,`CallID`
FROM `mntng_contactrealtime`;
END;

