create
    definer = ims@`%` procedure USP_Mnt_Mntng_Network_S(IN v_Svr_Ip varchar(15), IN v_Top int, IN v_Div varchar(5))
BEGIN
	IF v_Top is null then
		set v_Top = 100;
	END IF;
	IF v_Div is null then
		set v_Div = 'Rx';
	END IF;
	IF v_Div = '' then
		SET v_Div = 'Rx';
	end if;
	SELECT `Timestamp`
	, Rx*8 Rx_Kbyte -- = 1Byte = 8 bit
	, Tx*8 Tx_Kbyte -- = 1Byte = 8 bit
	-- INTO #Net_Temp
	FROM(
		SELECT 
		TIMESTAMPADD(HOUR,9,Reg_Dt) as `Timestamp`  -- UTC 시간대 +9 해야함
		, Rx
		, Tx
		, Reg_Dt
		FROM Mntng_Network_Hist 
		WHERE Svr_Ip = v_Svr_Ip
		ORDER BY Reg_Dt DESC
	) A
	ORDER BY Reg_Dt ASC;
	-- Top 내 MAX , MIN
	/*
	DECLARE @RxMAX INT
	DECLARE @RxMIN INT
	DECLARE @TxMAX INT
	DECLARE @TxMIN INT
	SELECT @RxMAX = MAX(Rx_Kbyte)
	, @RxMIN = MIN(Rx_Kbyte)
	, @TxMAX = MAX(Tx_Kbyte)
	, @TxMIN = MIN(Tx_Kbyte)
	FROM #Net_Temp
	IF @Div = 'Rx'
		BEGIN
			SELECT Timestamp, Rx_Kbyte, Tx_Kbyte
			, RxMAX = @RxMAX
			, RxMIN = @RxMIN
			, TxMAX = @TxMAX
			, TxMIN = @TxMIN
			FROM #Net_Temp
		END
	ELSE
		BEGIN
			SELECT Timestamp, Rx_Kbyte, Tx_Kbyte
			, RxMAX = @RxMAX
			, RxMIN = @RxMIN
			, TxMAX = @TxMAX
			, TxMIN = @TxMIN
			FROM #Net_Temp
		END
	DROP TABLE #Net_Temp
	*/
END;

