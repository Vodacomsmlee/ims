create
    definer = ims@`%` procedure USP_Mng_Ivr_Holiday_U(IN v_HD_Seq int, IN v_HD_Nm varchar(50), IN v_HD_Date varchar(8),
                                                      IN v_HD_TimeStart varchar(6), IN v_HD_TimeEnd varchar(6),
                                                      IN v_HD_AnuallyYN tinyint unsigned,
                                                      IN v_HD_PromptYN tinyint unsigned, IN v_HD_Prompt char(10))
BEGIN
	UPDATE Mng_Ivr_Holiday
	SET HD_Nm = v_HD_Nm,HD_Date = v_HD_Date
	, HD_TimeStart = RIGHT(CONCAT_WS('','0',v_HD_TimeStart),4)
	, HD_TimeEnd = RIGHT(CONCAT_WS('','0',v_HD_TimeEnd),4)
	, HD_AnuallyYN = v_HD_AnuallyYN
	, HD_PromptYN = v_HD_PromptYN
	, HD_Prompt = v_HD_Prompt
	WHERE HD_Seq = v_HD_Seq;
   
END;

