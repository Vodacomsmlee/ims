create
    definer = ims@`%` procedure USP_AUTH_Service_D(IN v_Svc_No int, OUT v_RTN_VALUE int)
BEGIN
	IF v_RTN_VALUE is null then
		set v_RTN_VALUE = -2;
	END IF;
	
	SET v_RTN_VALUE = 1;
	IF v_Svc_No IS NULL then
		SET v_RTN_VALUE = -1;
	end if;
	IF EXISTS(SELECT Svc_No FROM Role_Service WHERE Svc_No = v_Svc_No LIMIT 1) then
		UPDATE Role_Service
		SET Del_Stat = 1
		WHERE Svc_No = v_Svc_No;
		SET v_RTN_VALUE = 0;
	ELSE
		SET v_RTN_VALUE = -2;
	end if;
	
END;

