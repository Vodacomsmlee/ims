create
    definer = ims@`%` procedure USP_Mng_Ivr_WorkhourSet_S(IN v__Emp_No varchar(10))
BEGIN
	IF v__Emp_No is null then
		set v__Emp_No = '';
	END IF;
	
	-- CALL FN_CMM_Grant_S(v__Emp_No,6);
	
	SELECT WH_Code
	, WH_Code_Nm
	, A.Dept_No
	, '' as Dept_Nm -- (select dept_nm from Dept where dept_no = A.dept_no) AS Dept_Nm
	, A.HD_Code
	, B.HD_Code_Nm
	FROM Mng_Ivr_WorkhourSet A 
	left outer join mng_ivr_holidayset B on A.HD_Code = B.HD_Code
	WHERE 1=1 -- Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
	AND A.Del_Stat = 0
	ORDER BY WH_Code_Nm;
	
END;

