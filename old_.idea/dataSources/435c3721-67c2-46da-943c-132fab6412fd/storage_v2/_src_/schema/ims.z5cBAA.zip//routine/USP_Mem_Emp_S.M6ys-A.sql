create
    definer = ims@`%` procedure USP_Mem_Emp_S(IN v_Emp_No varchar(10))
BEGIN
	DECLARE v_Role_No INT;
	DECLARE v_Dept_No INT;
	DECLARE v_SYS_CODE VARCHAR(10);
	
	SELECT Role_No, Dept_No INTO v_Role_No, v_Dept_No FROM ims.Emp WHERE Emp_No = v_Emp_No;
	SELECT Dept_Desc INTO v_SYS_CODE FROM ims.Dept WHERE Dept_No = v_Dept_No;
	
	IF v_Emp_No IS NULL THEN
		SET v_Emp_No = '';
	END IF;
	
	CALL FN_CMM_Grant_S(v_Emp_No,1);
	
	IF v_Role_No IN(1, 3) THEN
		SELECT Emp_No
		, A.Organ_No
		, Emp_Nm
		, Agent_Key
		, A.Dept_No
		, Role_No
		, B.Team_Key
		 , ims_ifx.FN_Get_UserID(Agent_Key) AS userid
		, RIGHT(ims_ifx.FN_Get_UserID(Agent_Key),4) AS Extn_no
		FROM Emp A 
		LEFT OUTER JOIN Dept B ON A.Dept_No = B.Dept_No
		WHERE B.Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
		AND A.Del_Stat = 0
		AND A.Agent_Key IS NOT NULL;
	ELSE
	
		SELECT Emp_No
		, A.Organ_No
		, Emp_Nm
		, Agent_Key
		, A.Dept_No
		, Role_No
		, B.Team_Key
		 , ims_ifx.FN_Get_UserID(Agent_Key) AS userid
		, RIGHT(ims_ifx.FN_Get_UserID(Agent_Key),4) AS Extn_no
		FROM Emp A 
		LEFT OUTER JOIN Dept B ON A.Dept_No = B.Dept_No
		WHERE A.Del_Stat = 0
		AND A.Emp_No = v_Emp_No
		AND A.Agent_Key IS NOT NULL;
		
	END IF;
	
	/*
	union 
	
	SELECT Emp_No
	, A.Organ_No
	, Emp_Nm
	, Agent_Key
	, A.Dept_No
	, Role_No
	, B.Team_Key
	, ims_ifx.FN_Get_UserID(Agent_Key) AS userid
	FROM Emp A 
	LEFT OUTER JOIN Dept B ON A.Dept_No = B.Dept_No
	WHERE A.Emp_No = v_Emp_No
	AND A.Del_Stat = 0
	AND A.Agent_Key IS NOT NULL;
	*/
	
END;

