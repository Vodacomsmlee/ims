create
    definer = ims@`%` procedure USP_Mnt_Mntng_TrunkStatus_I(IN v_code int, IN v_name varchar(50), IN v_ip varchar(18),
                                                            IN v_idle int, IN v_busy int, IN v_total int)
BEGIN
	INSERT INTO Mntng_TrunkStatus(`date`, code, name, ip, idle, busy, total)
	SELECT CURRENT_TIMESTAMP, v_code, v_name, v_ip, v_idle, v_busy, v_total;
	
END;

