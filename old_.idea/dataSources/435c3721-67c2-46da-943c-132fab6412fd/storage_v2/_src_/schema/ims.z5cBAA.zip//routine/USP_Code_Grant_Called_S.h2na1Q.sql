create
    definer = ims@`%` procedure USP_Code_Grant_Called_S(IN v_Emp_No varchar(10))
BEGIN
	SELECT Seq, Called_Key, CalledNumber, `Desc`, Use_Stat
	FROM Code_CalledNumber A 
	JOIN Role_Emp_Grant B ON A.Seq = B.Grant_Type_Seq AND B.Emp_No = v_Emp_No AND B.Del_Stat = 0 AND B.Grant_Type = 3
	WHERE A.Del_Stat = 0;
END;

