create
    definer = ims@`%` procedure USP_Mng_Ivr_WorkhourSet_U(IN v_WH_Code int, IN v_WH_Code_Nm varchar(70),
                                                          IN v_Dept_No int, IN v_HD_Code int)
BEGIN
	IF v_HD_Code = -1 THEN 
		SET v_HD_Code = NULL;
	END IF;
	
	UPDATE Mng_Ivr_WorkhourSet 
	SET WH_Code_Nm = v_WH_Code_Nm
	,Dept_No = v_Dept_No
	, HD_Code = v_HD_Code
	WHERE WH_Code = v_WH_Code;
END;

