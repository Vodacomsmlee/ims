create
    definer = ims@`%` procedure USP_Mntng_Contact_Realtime_All_D()
BEGIN
TRUNCATE TABLE `mntng_contactrealtime`;
END;

