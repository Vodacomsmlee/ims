create
    definer = ims@`%` procedure USP_Cmm_Code_U(IN v_Cmm_Code int, IN v_Cmm_Code_Nm varchar(50))
BEGIN
	UPDATE Code_Cmm
	SET Cmm_Code_Nm = v_Cmm_Code_Nm
	WHERE Cmm_Code = v_Cmm_Code;
END;

