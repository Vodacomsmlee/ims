create
    definer = ims@`%` procedure USP_Mntng_Contact_Realtime_U(IN v_uniqueCallId varchar(30),
                                                             IN v_destination varchar(50), IN v_source varchar(50),
                                                             IN v_contactState varchar(20), IN v_timeInState int(10),
                                                             IN v_totalWaitTime int(10), IN v_mediaType varchar(50),
                                                             IN v_currentPriority smallint(50),
                                                             IN v_description varchar(50), IN v_queueKey int(10),
                                                             IN v_qualifyingAgentsCount int(10))
BEGIN
UPDATE `mntng_contactrealtime` SET
`date`=CURRENT_TIMESTAMP(6)
,`Destination`=v_destination
,`Source`=v_source
,`CurrentState`=v_contactState
,`TImeInState`=v_timeInState
,`TotalWaitTime`=v_totalWaitTime
,`MediaType`=v_mediaType
,`CurrentPriority`=v_currentPriority
,`Description`=v_description
,`QueueKey`=v_queueKey
,`QualifyingAgentsCount`=v_qualifyingAgentsCount
WHERE
`CallID`=v_uniqueCallId;
END;

