create
    definer = ims@`%` procedure USP_Cmm_Menu_S_New(IN v_Emp_No varchar(10), IN v_CURRENT_URL_ varchar(200))
BEGIN
	DECLARE v_CurrURL_PathCode VARCHAR(1000);
	-- 임시테이블에 넣고 해당URL의 PATH_CODE를 가져와서 그PATH_CODE에 있는 MenuID는 모두 class="open" 시켜야한다!!!
	DROP TEMPORARY TABLE IF EXISTS MENU;
	CREATE TEMPORARY TABLE MENU (
		SEQ INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
		MenuId INT,
		MenuNm VARCHAR(100),
		HighMenuId INT,
		MenuHref VARCHAR(50),
		Icon VARCHAR(30),
		Lvl INT,
		Path_Code VARCHAR(1000)
	);
	INSERT INTO MENU(MenuId, MenuNm, HighMenuId, MenuHref, Icon, Lvl, Path_Code)
	WITH RECURSIVE CTE(MenuId, MenuNm, HighMenuId, MenuHref, Icon, Lvl, Path_Code)
	AS(
		SELECT MenuId, MenuNm, HighMenuId, MenuHref, Icon, 1 AS Lvl
		, CAST(MenuId AS VARCHAR(100)) AS Path_Code
		FROM Menu_Info
		WHERE HighMenuId = '0'
		AND Del_Stat = 0
		UNION ALL
		SELECT C.MenuId, C.MenuNm, C.HighMenuId, C.MenuHref, C.Icon, Lvl+1
		, CONCAT(Path_Code,'/',CAST(C.MenuId AS VARCHAR(10))) AS Path_Code
		FROM Menu_Info C
		INNER JOIN CTE CCte ON C.HighMenuId = CCte.MenuId
		WHERE Del_Stat = 0
	)
	SELECT D.MenuId, D.MenuNm, D.HighMenuId, D.MenuHref, D.Icon, D.Lvl, D.Path_Code
	FROM Emp A
	JOIN Role_Dtl B ON A.Role_No = B.Role_No
	JOIN Role_Service C ON B.Svc_No = C.Svc_No
	JOIN CTE D  ON C.MenuId = D.MenuId
	WHERE A.Emp_No = v_Emp_No
	AND C.Use_Stat = 0
	AND A.Del_Stat = 0;
	IF IFNULL(v_CURRENT_URL_,'') <> '' THEN
		SELECT Path_Code INTO v_CurrURL_PathCode
		FROM MENU
		WHERE MenuHref = v_CURRENT_URL_;
	END IF;
SELECT MenuId, MenuNm, HighMenuId, MenuHref, Icon, Lvl, Path_Code, LvlOrder, LvlCnt
	, CONCAT_WS(''
	, (CASE
			WHEN Lvl = 1 AND LvlOrder > 1
			THEN (CASE WHEN LAG(Lvl,1) OVER(PARTITION BY Col ORDER BY Path_Code ASC) = 2 THEN '</ul></li>' ELSE '</ul></li></ul></li>' END)
			ELSE ''
		END)
	, (CASE
			WHEN LvlCnt > 0
			THEN (CASE
						WHEN Lvl = 1 
						THEN (CASE WHEN INSTR(v_CurrURL_PathCode, MenuId) > 0  THEN '<li class="open">' ELSE '<li>' END)
						ELSE (CASE
									WHEN Lvl = 2 AND LvlCnt > 0 AND LvlOrder > 1
									THEN (CASE WHEN INSTR(v_CurrURL_PathCode, MenuId) > 0 THEN '</ul></li><li class="open">' ELSE '</ul></li><li>' END)
									ELSE (CASE 
												WHEN INSTR(v_CurrURL_PathCode, MenuId) > 0 
												THEN '<ul style="display:block"><li class="open">'
												ELSE (CASE 
															WHEN Lvl = 2 AND LvlOrder = 1 AND INSTR(v_CurrURL_PathCode, HighMenuId) > 0
															THEN '<ul style="display:block"><li>'
															ELSE '<ul><li>'
														END)
											END)
								END)
					END)
			ELSE (CASE
						WHEN LvlCnt = 0 AND LvlOrder = 1
						THEN (CASE 
									WHEN INSTR(v_CurrURL_PathCode, MenuId) > 0 OR INSTR(v_CurrURL_PathCode, HighMenuId) > 0
									THEN (CASE 
												WHEN Lvl = 2 AND LvlCnt > 0
												THEN '<ul style="display:block"><li class="open">'
												ELSE (CASE WHEN INSTR(v_CurrURL_PathCode, MenuId) > 0 THEN '<ul style="display:block"><li class="open">' ELSE '<ul style="display:block"><li>' END)
											END)
									ELSE '<ul><li>'
								END)
			ELSE (CASE WHEN INSTR(v_CurrURL_PathCode, MenuId) > 0  THEN  '<li class="open">'  ELSE  '<li>' END)
			END)
		END)
	,'<a href="', (CASE WHEN MenuHref = '' THEN '#' ELSE MenuHref END) ,'" title="',MenuNm,'" ', CASE WHEN INSTR(MenuHref, 'http://') > 0 THEN 'target="_blank"' ELSE '' END ,' data-filter-tags="',MenuNm,'">'
	, (CASE WHEN Lvl = 1 THEN '<i class="fal fa-plus-circle"></i>' ELSE '' END)
	,'<span class="nav-link-text">',MenuNm,'</span></a>'
	, (CASE WHEN LvlCnt = 0 THEN '</li>' ELSE '' END)
	, (CASE WHEN (LEAD(Lvl,1) OVER(PARTITION BY Col ORDER BY Path_Code ASC)) IS NULL THEN (CASE WHEN Lvl = 3 THEN '</ul></li></ul></li>' ELSE '</ul></li>' END ) ELSE '' END)
	) AS Tree
	FROM
	(
		SELECT A.MenuId, MenuNm, HighMenuId, MenuHref, Icon, Lvl, Path_Code
		, ROW_NUMBER() OVER(PARTITION BY HighMenuId, Lvl ORDER BY Path_Code ASC) AS LvlOrder
		, (SELECT COUNT(1) AS CNT FROM Menu_Info WHERE HighMenuId = A.MenuId and Del_Stat = 0) AS LvlCnt
		, 1 AS Col
		FROM MENU A
	) X
	ORDER BY Path_Code ASC;
END;

