create
    definer = ims@`%` procedure USP_Mnt_Mntng_Network_I(IN v_Rx int, IN v_Tx int, IN v_Band bigint, IN v_SvrIp varchar(15))
BEGIN
	SELECT v_SvrIp, v_Rx, v_Tx, v_Band;
	IF v_Rx IS NULL THEN
		SET v_Rx = 0;
	END IF;
	IF v_Tx IS NULL THEN
		SET v_Tx = 0;
	END IF;
	IF v_Rx < 0 THEN
		SET v_Rx = 0;
	END IF;
	IF v_Tx < 0 THEN
		SET v_Tx = 0;
	END IF;
	
	IF (v_Rx IS NOT NULL AND v_Tx IS NOT NULL) THEN
	
		SET v_SvrIp = REPLACE(v_SvrIp, '192.168.122.1','172.20.1.207'); -- fax
		SET v_SvrIp = REPLACE(v_SvrIp, '169.254.251.197','172.20.1.201'); -- rec
		
		INSERT INTO Mntng_Network_Hist(Svr_Ip, Rx, Tx, Band)
		VALUES(v_SvrIp, v_Rx, v_Tx, v_Band);
	END IF;
END;

