create
    definer = ims@`%` procedure USP_Mntng_Group_Cumulative_I(IN v_date datetime, IN v_groupKey int(10),
                                                             IN v_callsReceived int(10), IN v_callsOffered int(10),
                                                             IN v_consultOut int(10), IN v_transferOut int(10),
                                                             IN v_receivedHereOfferedElsewhere int(10))
BEGIN
INSERT INTO `mntng_groupcumulative`(
`date`
,`GroupKey`
,`Received`
,`Offered`
,`ConsultOut`
,`TransferOut`
,`ReceivedHereOfferedElsewhere`)
VALUES(v_date
,v_groupKey
,v_callsReceived
,v_callsOffered
,v_consultOut
,v_transferOut
,v_receivedHereOfferedElsewhere);
END;

