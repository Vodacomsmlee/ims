create
    definer = ims@`%` procedure USP_Mntng_Queue_Realtime_I(IN v_queueKey int, IN v_queuedContacts int(5),
                                                           IN v_overflowedContacts int(5), IN v_serviceLevel float,
                                                           IN v_estimatedServiceLevel float, IN v_abandonedRate float,
                                                           IN v_oldestContactWaitTime int(10),
                                                           IN v_avgAnsweredWaitTime float,
                                                           IN v_estimatedAnsweredWaitTime int(10),
                                                           IN v_avgAbandonedWaitTime float)
BEGIN
INSERT INTO `mntng_queuerealtime`(
`date`
,`QueueKey`
,`Contacts`
,`OverflowedContacts`
,`ServiceLevel`
,`EstimatedServiceLevel`
,`AbandonedRate`
,`OldestContactWaitTime`
,`AverageAnsweredWaitTime`
,`EstimatedAnsweredWaitTime`
,`AverageAbandonedWaitTime`)
VALUES(CURRENT_TIMESTAMP(6)
,v_queueKey
,v_queuedContacts
,v_overflowedContacts
,v_serviceLevel
,v_estimatedServiceLevel
,v_abandonedRate
,v_oldestContactWaitTime
,v_avgAnsweredWaitTime
,v_estimatedAnsweredWaitTime
,v_avgAbandonedWaitTime);
END;

