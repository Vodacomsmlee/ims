create
    definer = ims@`%` procedure USP_Mnt_Mntng_TrunkStatus_S()
BEGIN
	with CTE AS
	(
		SELECT
		`DATE`, code, name, ip, idle, busy, total
		, ROW_NUMBER() OVER(PARTITION BY code ORDER BY `DATE` DESC) AS RN
		FROM Mntng_TrunkStatus
	)
	SELECT `date`, code, name, ip, idle, busy, total FROM CTE WHERE RN = 1;
END;

