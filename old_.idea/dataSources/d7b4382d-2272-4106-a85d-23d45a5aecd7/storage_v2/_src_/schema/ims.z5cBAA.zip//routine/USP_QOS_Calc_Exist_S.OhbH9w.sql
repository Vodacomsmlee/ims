create
    definer = ims@`%` procedure USP_QOS_Calc_Exist_S(IN v_MacAddr varchar(12), IN v_Callid varchar(40))
begin
	SELECT COUNT(1) FROM QOS_Calc_Data WHERE MacAddr=v_MacAddr and Callid=v_Callid;
end;

