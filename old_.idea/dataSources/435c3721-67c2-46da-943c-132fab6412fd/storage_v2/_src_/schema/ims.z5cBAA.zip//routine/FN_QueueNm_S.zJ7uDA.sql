create
    definer = ims@`%` function FN_QueueNm_S(v_Que_Code int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   select   Que_Nm INTO v_RETURN FROM Code_Queue  WHERE Que_Code = v_Que_Code
   AND Del_Stat = 0;
   SET v_RETURN = IFNULL(v_RETURN,'');
   RETURN v_RETURN;
END;

