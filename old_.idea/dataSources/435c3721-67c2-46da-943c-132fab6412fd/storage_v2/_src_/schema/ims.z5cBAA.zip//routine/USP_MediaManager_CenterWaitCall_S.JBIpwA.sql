create
    definer = ims@`%` procedure USP_MediaManager_CenterWaitCall_S(IN v_DEPT_NO int)
BEGIN
	SELECT B.Dept_No, D.High_Dept_No AS CENTER_CODE, SUM(CONTACTS) AS WAITCALL FROM `mntng_queuerealtime` AS QRT
		LEFT JOIN code_dept_que AS B ON QRT.QUEUEKEY=B.QUE_CODE
		LEFT JOIN DEPT AS D ON B.DEPT_NO=D.DEPT_NO
	WHERE IFNULL(B.DEPT_NO,0) != 0
		AND D.High_Dept_No=(SELECT High_Dept_No FROM DEPT WHERE DEPT_NO=v_DEPT_NO)
	GROUP BY B.Dept_No;
END;

