create
    definer = ims@`%` function FN_Get_High_Dept_Nm_S(v_Dept_No int) returns varchar(100)
BEGIN 
	DECLARE v_RETURN VARCHAR(100);
	   
	DROP TEMPORARY TABLE IF EXISTS tt_High_DeptNm;
	CREATE TEMPORARY TABLE tt_High_DeptNm			
	(			
	   Path_Dept_Nm varchar(100)	
	); 		
	
	insert into tt_High_DeptNm(Path_Dept_Nm)
	WITH RECURSIVE CTE(DEPT_NO, Path_Dept_Nm)
	AS(
		
		SELECT DEPT_NO, CAST(DEPT_NM AS varCHAR(100)) AS Path_Dept_Nm
		FROM ims.dept A
		WHERE NOT EXISTS (SELECT DEPT_NO FROM ims.dept WHERE DEPT_NO = A.High_Dept_No LIMIT 1)
		
		UNION ALL
		
		SELECT c.DEPT_NO, CONCAT(Path_Dept_Nm,' > ',CAST(C.DEPT_NM AS VARCHAR(100))) AS Path_Dept_Nm
		FROM ims.dept C 
		INNER JOIN CTE CCte ON C.High_Dept_No = CCte.DEPT_NO
	)
	SELECT Path_Dept_Nm
	FROM CTE
	WHERE Dept_No = v_Dept_No;
	select Path_Dept_Nm INTO v_RETURN from tt_High_DeptNm;
	DROP TEMPORARY TABLE IF EXISTS tt_High_DeptNm;
	RETURN v_RETURN;
END;

