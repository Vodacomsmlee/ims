create
    definer = ims@`%` procedure USP_Mng_Ivr_WorkhourSet_D(IN v_WH_Code int)
BEGIN
UPDATE Mng_Ivr_WorkhourSet 
SET Del_Stat = 1
WHERE WH_Code = v_WH_Code;
END;

