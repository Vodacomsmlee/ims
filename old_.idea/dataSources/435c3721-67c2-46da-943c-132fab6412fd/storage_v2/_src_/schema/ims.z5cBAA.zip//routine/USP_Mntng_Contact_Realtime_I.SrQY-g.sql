create
    definer = ims@`%` procedure USP_Mntng_Contact_Realtime_I(IN v_uniqueCallId varchar(30),
                                                             IN v_destination varchar(50), IN v_source varchar(50),
                                                             IN v_contactState varchar(20), IN v_timeInState int(10),
                                                             IN v_totalWaitTime int(10), IN v_mediaType varchar(50),
                                                             IN v_currentPriority smallint(50),
                                                             IN v_description varchar(50), IN v_queueKey int(10),
                                                             IN v_qualifyingAgentsCount int(10))
BEGIN
INSERT INTO `mntng_contactrealtime`(
`date`
,`CallID`
,`Destination`
,`Source`
,`CurrentState`
,`TImeInState`
,`TotalWaitTime`
,`MediaType`
,`CurrentPriority`
,`Description`
,`QueueKey`
,`QualifyingAgentsCount`)
VALUES(CURRENT_TIMESTAMP(6)
,v_uniqueCallId
,v_destination
,v_source
,v_contactState
,v_timeInState
,v_totalWaitTime
,v_mediaType
,v_currentPriority
,v_description
,v_queueKey
,v_qualifyingAgentsCount);
END;

