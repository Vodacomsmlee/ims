create
    definer = ims@`%` procedure USP_Stt_IVR_ServiceStat_S(IN v_destinations varchar(4000),
                                                          IN v_Srch_Type tinyint unsigned, IN v_Start_Dt datetime,
                                                          IN v_End_Dt datetime)
BEGIN
	IF v_Srch_Type is null then
		set v_Srch_Type = 0;
	END IF;
	
	
	call FN_CMM_Split_S(v_destinations, '|');
	
	IF v_Srch_Type = 0 then -- 월별
		SELECT 
		(CASE WHEN DT IS NULL THEN 'Total' ELSE DT END) as DT
		, DNIS, DNIS_NAME, SERVICE_NAME, Group_Seq, TOTAL_TRANS, TOTAL_AGENT, TOTAL_RECEIVE, TOTAL_ABANDONE, TOTAL_CALLBACK
		FROM
			(
				SELECT 
					DATE_FORMAT(startdate, '%Y-%m') as DT
					, DNIS
					, IfNULL(FN_CalledNumberToDesc_S(DNIS), '') as DNIS_NAME
					, IFNULL(FN_CtiGroup_Nm_S(nullif(Group_Seq,'')), '') as SERVICE_NAME
					, Group_Seq
					, SUM(CASE WHEN ROUTENUM = '' THEN 1 ELSE 0 END) as TOTAL_TRANS
					, SUM(CASE WHEN ROUTENUM <> '' THEN 1 ELSE 0 END) as TOTAL_AGENT
					, COUNT(1) as TOTAL_RECEIVE
					, SUM(CASE WHEN ifnull(FAILYN, '') = 'Y' THEN 1 ELSE 0 END) as TOTAL_ABANDONE
					, SUM(CASE WHEN CALLBACK = 1 THEN 1 ELSE 0 END) as TOTAL_CALLBACK
				FROM tb_ivrstatistics
				WHERE DNIS IN( SELECT `VALUE` FROM FN_CMM_Split_S)
				AND startdate >= CONCAT(DATE_FORMAT(v_Start_Dt, '%Y-%m') ,'-01') -- Index 태우기 위해 날짜를 만들어준다.
				AND DATE_FORMAT(startdate, '%Y-%m') <= DATE_FORMAT(v_End_Dt, '%Y-%m')
				GROUP BY DNIS, DATE_FORMAT(startdate, '%Y-%m') with rollup
				-- GROUP BY DNIS, Group_Seq, DATE_FORMAT(startdate, '%Y-%m') WITH ROLLUP
			) X;
	
	end if;
	
	IF v_Srch_Type = 1 then -- 일별
	
						
		SELECT 
		(CASE WHEN DT IS NULL THEN 'Total' ELSE DT END) as DT
		, DNIS, DNIS_NAME, SERVICE_NAME, Group_Seq, TOTAL_TRANS, TOTAL_AGENT, TOTAL_RECEIVE, TOTAL_ABANDONE, TOTAL_CALLBACK
		FROM
			(
			SELECT DATE_FORMAT(startdate, '%Y-%m-%d') AS DT
				, DNIS
				, IFNULL(FN_CalledNumberToDesc_S(DNIS), '') AS DNIS_NAME
				, IFNULL(FN_CtiGroup_Nm_S(NULLIF(Group_Seq,'')), '') AS SERVICE_NAME
				, Group_Seq
				, SUM(CASE WHEN ROUTENUM = '' THEN 1 ELSE 0 END) AS TOTAL_TRANS
				, SUM(CASE WHEN ROUTENUM <> '' THEN 1 ELSE 0 END) AS TOTAL_AGENT
				, COUNT(1) AS TOTAL_RECEIVE
				, SUM(CASE WHEN IFNULL(FAILYN, '') = 'Y' THEN 1 ELSE 0 END) AS TOTAL_ABANDONE
				, SUM(CASE WHEN CALLBACK = 1 THEN 1 ELSE 0 END) AS TOTAL_CALLBACK
			FROM tb_ivrstatistics
			WHERE  DNIS IN( SELECT `VALUE` FROM FN_CMM_Split_S)
			AND startdate >= DATE_FORMAT(v_Start_Dt, '%Y-%m-%d')
			AND DATE_FORMAT(startdate, '%Y-%m-%d') <= DATE_FORMAT(v_End_Dt, '%Y-%m-%d')
			-- GROUP BY DNIS, Group_Seq, DATE_FORMAT(startdate, '%Y-%m-%d') WITH ROLLUP 
			GROUP BY DNIS, DATE_FORMAT(startdate, '%Y-%m-%d') WITH ROLLUP 
			) X;
	
	/*
		SELECT 
			(CASE WHEN GROUPING(DATE_FORMAT(startdate, '%Y-%m-%d')) = 1 THEN 'Total' ELSE DATE_FORMAT(startdate, '%Y-%m-%d') END) as DT
			, DNIS
			, IfNULL(FN_CalledNumberToDesc_S(DNIS), '') as DNIS_NAME
			, IfNULL(FN_CtiGroup_Nm_S(Group_Seq), '') as SERVICE_NAME
			, Group_Seq
			, SUM(CASE WHEN ROUTENUM = '' THEN 1 ELSE 0 END) as TOTAL_TRANS
			, SUM(CASE WHEN ROUTENUM <> '' THEN 1 ELSE 0 END) as TOTAL_AGENT
			, COUNT(1) as TOTAL_RECEIVE
			, SUM(CASE WHEN IfNULL(FAILYN, '') = 'Y' THEN 1 ELSE 0 END) as TOTAL_ABANDONE
			, SUM(CASE WHEN CALLBACK = 1 THEN 1 ELSE 0 END) as TOTAL_CALLBACK
		FROM tb_ivrstatistics
		WHERE DNIS IN( SELECT `VALUE` FROM FN_CMM_Split_S)
		AND startdate >= DATE_FORMAT(v_Start_Dt, '%Y-%m-%d')
		AND DATE_FORMAT(startdate, '%Y-%m-%d') <= DATE_FORMAT(v_End_Dt, '%Y-%m-%d')
		GROUP BY DNIS, Group_Seq, DATE_FORMAT(startdate, '%Y-%m-%d') with ROLLUP ;
	*/	
		
		
	end if;
END;

