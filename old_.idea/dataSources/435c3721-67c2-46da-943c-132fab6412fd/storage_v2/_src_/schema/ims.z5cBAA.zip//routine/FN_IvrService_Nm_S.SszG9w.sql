create
    definer = ims@`%` function FN_IvrService_Nm_S(v_SV_Code int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   select   concat_ws(' ',SV_name, sv_name2) INTO v_RETURN FROM mng_ivr_service  WHERE SV_Code = v_SV_Code;
   RETURN v_RETURN;
end;

