create
    definer = ims@`%` procedure USP_Cmm_Code_I(IN v_Cmm_Code_Nm varchar(50))
BEGIN
	INSERT INTO Code_Cmm(Cmm_Code_Nm)VALUES(v_Cmm_Code_Nm);
END;

