create
    definer = ims@`%` function FN_Get_UserIdToUserNm(v_UserID varchar(8)) returns varchar(50)
BEGIN 
   DECLARE v_RETURN VARCHAR(50);
   DECLARE v_Agent_Key INT;
   SET v_RETURN = '';
	select Emp_Nm into v_RETURN FROM ims.Emp WHERE Emp_No = v_UserID;
/*
   SELECT   userkey INTO v_Agent_Key FROM ims_ifx.users  WHERE userid = v_UserID;
   IF v_Apply_Dt IS NULL THEN
	
      SET v_Apply_Dt = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
   END IF;
   IF v_Agent_Key IS NOT NULL THEN
	
      IF v_Apply_Dt < CONVERT(CURRENT_TIMESTAMP,CHAR(10)) THEN
			
         SELECT   Emp_Nm INTO v_RETURN FROM ims.Emp_Hist  WHERE Agent_Key = v_Agent_Key
         AND (Apply_Start_Dt >= DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d')
         OR IFNULL(Apply_End_Dt,CURRENT_TIMESTAMP) > DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d'))   ORDER BY Reg_Dt ASC LIMIT 1;
      ELSE
         SELECT   Emp_Nm INTO v_RETURN FROM ims.Emp_Hist  WHERE Agent_Key = v_Agent_Key
         AND (Apply_Start_Dt >= DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d')
         OR IFNULL(Apply_End_Dt,CURRENT_TIMESTAMP) > DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d'))   ORDER BY Reg_Dt DESC LIMIT 1;
      END IF;
   END IF;
 */
   RETURN v_RETURN;
END;

