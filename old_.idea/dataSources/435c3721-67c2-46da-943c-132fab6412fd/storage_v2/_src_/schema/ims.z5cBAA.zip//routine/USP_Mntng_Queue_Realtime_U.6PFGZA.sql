create
    definer = ims@`%` procedure USP_Mntng_Queue_Realtime_U(IN v_queueKey int, IN v_queuedContacts int(5),
                                                           IN v_overflowedContacts int(5), IN v_serviceLevel float,
                                                           IN v_estimatedServiceLevel float, IN v_abandonedRate float,
                                                           IN v_oldestContactWaitTime int(10),
                                                           IN v_avgAnsweredWaitTime float,
                                                           IN v_estimatedAnsweredWaitTime int(10),
                                                           IN v_avgAbandonedWaitTime float)
BEGIN
UPDATE `mntng_queuerealtime` SET
`date`=CURRENT_TIMESTAMP(6)
,`Contacts`=v_queuedContacts
,`OverflowedContacts`=v_overflowedContacts
,`ServiceLevel`=v_serviceLevel
,`EstimatedServiceLevel`=v_estimatedServiceLevel
,`AbandonedRate`=v_abandonedRate
,`OldestContactWaitTime`=v_oldestContactWaitTime
,`AverageAnsweredWaitTime`=v_avgAnsweredWaitTime
,`EstimatedAnsweredWaitTime`=v_estimatedAnsweredWaitTime
,`AverageAbandonedWaitTime`=v_avgAbandonedWaitTime
WHERE
`QueueKey`=v_queueKey;
END;

