create
    definer = ims@`%` procedure USP_Mng_Ivr_Scenario_D(IN v_SC_CODE int)
BEGIN
	UPDATE Mng_Ivr_Scenario
	SET Del_Stat = 1
	WHERE SC_CODE = v_SC_CODE;
	
END;

