create definer = ims@`%` event EVT_Mntng_System_Maintenance_D on schedule
    every '1' DAY
        starts '2020-07-17 07:00:00'
    disable on slave
    do
    CALL USP_Mnt_Mntng_System_Maintenance_D();

