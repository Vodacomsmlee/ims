create
    definer = ims@`%` procedure USP_Cmm_Code_D(IN v_Cmm_Code int)
BEGIN
	UPDATE Code_Cmm
	SET Del_Stat = 1
	WHERE Cmm_Code = v_Cmm_Code;
END;

