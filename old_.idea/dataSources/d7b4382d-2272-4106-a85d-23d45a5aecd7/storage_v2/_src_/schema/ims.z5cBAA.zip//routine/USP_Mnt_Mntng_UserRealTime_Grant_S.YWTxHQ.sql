create
    definer = ims@`%` procedure USP_Mnt_Mntng_UserRealTime_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	
	call FN_CMM_Grant_S(v__Emp_No, 2);
	
	SELECT
		A_ROWS.`date`
		, A_ROWS.UserKey
		, A_ROWS.UserID
		, ims.FN_Get_Emp_Nm(A_ROWS.UserKey,CURRENT_TIMESTAMP) AS UserName
		, A_ROWS.Department
		, ims.FN_Get_Emp_Dept_Nm(A_ROWS.UserKey,CURRENT_TIMESTAMP) AS DepartmentName
		, Extension
		, PresenceState
		, (CASE PresenceState
				WHEN 4 THEN HandlingState
				WHEN 3 THEN RoutingStateReasonKey
				ELSE 0
			END
		) AS ReasonKey
		, (CASE PresenceState
				WHEN 4 THEN -- 공통코드 : 4
					CASE WHEN HandlingState IS NOT NULL THEN FN_CMM_CmmDtlName_S(4,HandlingState) ELSE 'unknown' END
				WHEN 3 THEN -- 공통코드 : 1
					CASE WHEN RoutingStateReasonKey IS NOT NULL THEN  FN_CMM_CmmDtlName_S(1,RoutingStateReasonKey) ELSE 'unknown' END
				ELSE -- 공통코드 : 5
					CASE WHEN PresenceState IS NOT NULL THEN  FN_CMM_CmmDtlName_S(5,PresenceState) ELSE 'unknown' END
			END
		) as State
		, SEC_TO_TIME(CASE PresenceState
							WHEN 4 THEN TimeInHandlingState
							WHEN 3 THEN TimeInRoutingState
							ELSE TimeInPresenceState
						END
		) as TimeInState
		, (CASE WHEN AssociatedQueueKey IS NOT NULL THEN FN_QueueNm_S(AssociatedQueueKey) ELSE '' END) as QueueName
		, Handled
		, SEC_TO_TIME(TotalLoggedOnTime) as TotalLoggedOnTime
		, SEC_TO_TIME(TotalIdleTime) as TotalIdleTime
		, SEC_TO_TIME(TotalAwayTime) as TotalAwayTime
		, SEC_TO_TIME(TotalHandledTime -TotalPostProcessingTime) as TotalWorkOnTime
		, SEC_TO_TIME(TotalBusyTime) as TotalBusyTime
		, SEC_TO_TIME(TotalPostProcessingTime) as TotalPostProcessingTime
		, (CASE WHEN ContactType IN(1,2) THEN 'IN'
				WHEN ContactType IN(3) THEN 'OUT'
				WHEN ContactType IN(4) THEN '내선'
				ELSE '' 
			END
		) as ContactType
		
	FROM(
		SELECT
			`date`, UserKey, UserID, Department, Extension,
			RoutingState, RoutingStateReasonKey, TimeInRoutingState,
			PresenceState, TimeInPresenceState, HandlingState, HandlingStateReasonKey,
			TimeInHandlingState, CallID, ContactType, ContactDescription, AssociatedQueueKey,
			TotalContactHandlingTime
			,ROW_NUMBER() OVER(PARTITION BY UserKey ORDER BY `date` DESC) AS RNS
		FROM Mntng_UserRealTime
		) AS A_ROWS,
		(
		SELECT
			`date`, UserKey,Handled
			,TotalLoggedOnTime,TotalIdleTime,TotalAwayTime
			,TotalPostProcessingTime,TotalBusyTime,TotalHandledTime
			,ROW_NUMBER() OVER(PARTITION BY UserKey ORDER BY `date` DESC) AS RNT
		FROM Mntng_UserCumulative
		) AS TOTALS
	WHERE A_ROWS.Department in(SELECT * FROM FN_CMM_Grant_S)
	AND A_ROWS.RNS = 1 
	AND A_ROWS.USERKEY = TOTALS.USERKEY 
	AND TOTALS.RNT = 1;
END;

