create
    definer = ims@`%` procedure USP_Cmm_SendSMS_S(IN v_sms_code int)
BEGIN
	SELECT sms_text, sms_code ,sms_nm ,sms_type
	FROM Mng_Ivr_SMS
	WHERE SMS_CODE = v_sms_code;
END;

