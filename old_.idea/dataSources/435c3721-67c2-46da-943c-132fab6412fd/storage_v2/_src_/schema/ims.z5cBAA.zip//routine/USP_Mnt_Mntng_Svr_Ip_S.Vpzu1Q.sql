create
    definer = ims@`%` procedure USP_Mnt_Mntng_Svr_Ip_S()
BEGIN
	SELECT Svr_Ip, Svr_Desc FROM ims.mntng_svr WHERE Del_Stat = 0;
	
END;

