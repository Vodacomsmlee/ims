create
    definer = ims@`%` procedure USP_Hist_History_Data_S(IN v_start int, IN v_length int, IN v_SearchText varchar(100))
BEGIN
	-- 전체 Row Count
	IF v_start IS NULL THEN
		SET v_start = 0;
	END IF;
	IF v_length IS NULL THEN
		SET v_length = 15;
	END IF;
	IF v_SearchText IS NULL THEN
		SET v_SearchText = '';
	END IF;
	-- Data Row
	SELECT  Seq
	, Procedure_Nm
	, B.Emp_Nm
	, DATE_FORMAT(Reg_Dt,'%Y-%m-%d %T:%f') Reg_Dt
	, Parameter
	FROM HISTORY A 
	LEFT OUTER JOIN Emp B ON A.Emp_No = B.Emp_No
	ORDER BY Reg_Dt DESC
	LIMIT v_length OFFSET v_start;
	
END;

