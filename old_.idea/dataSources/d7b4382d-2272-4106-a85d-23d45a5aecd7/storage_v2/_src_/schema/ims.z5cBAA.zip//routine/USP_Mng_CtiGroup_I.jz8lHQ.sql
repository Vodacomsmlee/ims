create
    definer = ims@`%` procedure USP_Mng_CtiGroup_I(IN v_Dept_No int, IN v_Group_Nm varchar(100),
                                                   IN v_Group_Desc varchar(200), IN v_Group_Key int,
                                                   IN v_Emp_No varchar(4000))
BEGIN
	-- DECLARE @Group_Desc VARCHAR(200)
	IF v_Group_Desc is null then
		set v_Group_Desc = '';
	END IF;
	
	SET v_Group_Desc = '';
	INSERT INTO Mng_Cti_Group(Dept_No, Group_Nm, Group_Desc, Group_Key)
	VALUES(v_Dept_No, v_Group_Nm, v_Group_Desc, v_Group_Key);
END;

