create
    definer = ims@`%` procedure USP_Cmm_History_I(IN v_Proc_Nm varchar(4000), IN v_Emp_No varchar(10))
BEGIN
	INSERT INTO History(Procedure_Nm, Emp_No)
	SELECT v_Proc_Nm, v_Emp_No;
END;

