create
    definer = ims@`%` procedure USP_Cmm_Code_Dtl_D(IN v_Cmm_Dtl_Code_Idx int, IN v_Edit_Emp_Code varchar(10))
BEGIN
	IF v_Edit_Emp_Code is null then
		set v_Edit_Emp_Code = '';
	END IF;
	
	UPDATE Code_Cmm_Dtl
	SET Del_Stat = 1
	,Edit_Emp_Code = v_Edit_Emp_Code
	,Last_Edit_Dt = SYSDATE(3)
	WHERE Cmm_Dtl_Code_Idx = v_Cmm_Dtl_Code_Idx;
   
END;

