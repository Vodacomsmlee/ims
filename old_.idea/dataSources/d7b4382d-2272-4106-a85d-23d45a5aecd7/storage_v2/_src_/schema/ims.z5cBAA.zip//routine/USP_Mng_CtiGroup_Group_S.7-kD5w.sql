create
    definer = ims@`%` procedure USP_Mng_CtiGroup_Group_S(IN v_Emp_No varchar(10))
BEGIN
	SELECT Group_Seq
	FROM Mng_Cti_Group_Emp 
	WHERE Emp_No = v_Emp_No;
END;

