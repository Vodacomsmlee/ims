create
    definer = ims@`%` procedure USP_Cmm_Menu_S(IN v_Emp_No varchar(10))
BEGIN
	WITH RECURSIVE CTE(MenuId,MenuNm,HighMenuId,MenuHref,Icon,Lvl,Path_Code)
	AS(
		SELECT MenuId, MenuNm, HighMenuId, MenuHref, Icon, 1 AS Lvl, CAST(MenuId AS CHAR(10)) AS Path_Code
		FROM Menu_Info 
		WHERE HighMenuId = '0'
		AND Del_Stat = 0
		
		UNION ALL
		
		SELECT C.MenuId, C.MenuNm, C.HighMenuId, C.MenuHref, C.Icon, Lvl+1, CONCAT(Path_Code,'/',CAST(C.MenuId AS CHAR(10))) AS Path_Code
		FROM Menu_Info C 
		INNER JOIN CTE CCte ON C.HighMenuId = CCte.MenuId
		WHERE Del_Stat = 0
	)
	SELECT
		MenuId, MenuNm, HighMenuId, MenuHref, Icon, Lvl, Path_Code,  -- , LvlCnt, LvlOrder
		-- , LAG(Lvl,1) OVER(PARTITION BY Col ORDER BY Path_Code ASC) as pre
		-- , LEAD(Lvl,1) OVER(PARTITION BY Col ORDER BY Path_Code ASC) as nex
		 CONCAT_WS(''
					, (CASE 
							WHEN Lvl = 1 AND LvlOrder > 1 
							THEN (CASE WHEN LAG(Lvl,1) OVER(PARTITION BY Col ORDER BY Path_Code ASC) = 2 THEN '</ul></li>'  ELSE '</ul></li></ul></li>'  END)
							ELSE '' 
						END)
					, (CASE 
							WHEN LvlCnt > 0 
							THEN (CASE 
									WHEN Lvl = 1 THEN '<li class="open">' 
									ELSE 
										(CASE 
											WHEN Lvl = 2 AND LvlCnt > 0 AND LvlOrder > 1
											THEN '</ul></li><li class="open">'
											ELSE '<ul style="display: block;"><li class="open">' 
										END)  
									END) 
							ELSE (CASE WHEN LvlCnt = 0 AND LvlOrder = 1 THEN '<ul style="display: block;"><li>' ELSE '<li>' END)
						END)
					,'<a href="',MenuHref,'" title="',MenuNm,'" ', case when INSTR(MenuHref, 'http://') > 0 then 'target="_blank"' else '' end ,' data-filter-tags="',MenuNm,'">'
					, (CASE WHEN Lvl = 1 THEN '<i class="fal fa-plus-circle"></i>' ELSE '' END) 
					,'<span class="nav-link-text">',MenuNm,'</span></a>'
					, (CASE WHEN LvlCnt = 0 THEN '</li>' ELSE '' END)
					, (CASE WHEN (LEAD(Lvl,1) OVER(PARTITION BY Col ORDER BY Path_Code ASC)) IS NULL THEN (CASE WHEN Lvl = 3 THEN '</ul></li></ul></li>' ELSE '</ul></li>' END ) ELSE '' END)
					) AS Tree
	FROM
	(
		SELECT D.MenuId, MenuNm, HighMenuId, MenuHref, Icon, Lvl, Path_Code
		, ROW_NUMBER() OVER(PARTITION BY HighMenuId, Lvl ORDER BY HighMenuId, Lvl ASC) AS LvlOrder
		, (SELECT COUNT(1) AS CNT FROM Menu_Info WHERE HighMenuId = D.MenuId) AS LvlCnt
		, 1 AS Col
		FROM Emp A 
		JOIN Role_Dtl B ON A.Role_No = B.Role_No
		JOIN Role_Service C ON B.Svc_No = C.Svc_No
		JOIN CTE D  ON C.MenuId = D.MenuId
		WHERE A.Emp_No = v_Emp_No -- '1000' -- '1234567'
		AND C.Use_Stat = 0
		AND A.Del_Stat = 0
	) AS X
	ORDER BY Path_Code, MenuId ASC;
END;

