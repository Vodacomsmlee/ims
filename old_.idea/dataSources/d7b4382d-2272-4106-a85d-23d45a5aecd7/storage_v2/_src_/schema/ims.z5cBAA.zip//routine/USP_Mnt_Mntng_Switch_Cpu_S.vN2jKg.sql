create
    definer = ims@`%` procedure USP_Mnt_Mntng_Switch_Cpu_S(IN v_Svr_Seq int)
BEGIN
	SELECT B.Reg_Dt
	, UNIX_TIMESTAMP(TIMESTAMPADD(HOUR,9, B.Reg_Dt)) AS Tstamp
	, CAST(B.Cpu_UsgRate AS FLOAT) AS Cpu_UsgRate
	, Mem_Total
	, Mem_Usg
	, round((ifnull(Mem_Usg,0) / nullif(ifnull(Mem_Total,0),0)),2) * 100 as Mem_Rate
	FROM mntng_svr A
	JOIN mntng_switch_hist B ON A.Svr_Seq = B.Svr_Seq
	WHERE B.Svr_Seq = v_Svr_Seq
	AND A.Del_Stat = 0
	ORDER BY b.Seq DESC
	LIMIT 100;
END;

