create
    definer = ims@`%` procedure USP_Ifx_Monitoredresources_S()
BEGIN
	SELECT resourcekey, resourcenum
	FROM ims_ifx.monitoredresources
	WHERE resourcetype = 18
	ORDER BY resourcekey;
END;

