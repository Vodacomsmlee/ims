create
    definer = ims@`%` procedure USP_Mntng_Wallbarod_Notice_I(IN v_Notice varchar(4000))
BEGIN INSERT INTO Mntng_Wallboard_Notice(Notice)     VALUES(v_Notice);END;

