create
    definer = ims@`%` procedure USP_Mntng_User_Cumulative_MAX_S()
BEGIN
SELECT * FROM (
SELECT ROW_NUMBER() OVER(PARTITION BY USERKEY ORDER BY `date` DESC) AS
RN, DATE, USERKEY,`Utilization`,`Offered`
,`Handled`,`AbandonedWhileRinging`,`Unhandled`,`RoutedHeld`,`ConsultedOut`,`
TransferredOut`,`TotalLoggedOnTime`,`TotalRingTime`
,`TotalPendingTime`,`TotalHandledTime`,`TotalTimeOther`,`MaximumRoutedHandli
ngTime`,`TotalTalkTime`,`TotalHoldTime`,`Disconnected`
,`Requeued`,`TotalPostProcessingTime`,`TotalIdleTime`,`TotalAwayTime`,
`TotalBusyTime`
FROM `mntng_usercumulative`
) AS A_ROWS
WHERE RN=1;
END;

