create
    definer = ims@`%` procedure USP_AUTH_Service_S()
BEGIN
	SELECT Svc_No
	, Svc_Nm
	, CONCAT((CASE 
			-- WHEN depth = 1 THEN '⊙' 
			WHEN depth = 2 THEN '└─' 
			WHEN depth = 3 THEN '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└──' 
			ELSE ''
		END),' ',Svc_Nm) AS Svc_Nm_Depth
	, Svc_Url, Use_Stat, Use_Stat_Nm, Del_Stat, Reg_Dt, MenuID
	FROM
		(
		SELECT Svc_No
		, Svc_Nm
		, IFNULL(Svc_Url,'') Svc_Url
		, Use_Stat
		, '사용' AS Use_Stat_Nm-- dbo.FN_CMM_CmmDtlName_S(3, Use_Stat)
		, Del_Stat
		, Reg_Dt
		, MenuID
		, (CASE 
				WHEN MenuID LIKE '_000' THEN '1' 
				WHEN MenuID LIKE '__00' THEN '2' 
				WHEN MenuID IS NULL THEN '' 			
				ELSE '3' END) AS depth
		FROM Role_Service 
		WHERE Del_Stat = 0
		-- ORDER BY MenuID
		) X
	ORDER BY MenuID;
	/*
	SELECT Svc_No
	, Svc_Nm
	, IFNULL(Svc_Url,'') Svc_Url
	, Use_Stat
	, '사용' AS Use_Stat_Nm-- dbo.FN_CMM_CmmDtlName_S(3, Use_Stat)
	, Del_Stat
	, Reg_Dt
	FROM Role_Service 
	WHERE Del_Stat = 0
	ORDER BY MenuID; -- Svc_No;
	*/
END;

