create
    definer = ims@`%` procedure USP_QOS_Calc_D(IN v_LocalSubscriberNo varchar(15), IN v_MacAddr varchar(12),
                                               IN v_Callid varchar(40), IN v_protocolVersion int, IN v_Reason smallint,
                                               IN v_StartTime datetime, IN v_EndTime datetime,
                                               IN v_LocalIpAddr varchar(35), IN v_LocalRtpPort int,
                                               IN v_RemoteIpAddr varchar(35), IN v_RemoteRtpPort int,
                                               IN v_SsrcReceiving decimal(22), IN v_SsrcSending decimal(22),
                                               IN v_Codec int, IN v_MediaType int, IN v_PayloadType int,
                                               IN v_MaxPacketSize int, IN v_SilenceSuppression int,
                                               IN v_GoodPackets decimal(22), IN v_MaxJitter int,
                                               IN v_MaxInterJitter int, IN v_MaxJitterExceedPeriods int,
                                               IN v_AvgRoundTripDelay int, IN v_AvgRoundTripDelayExceeded bit,
                                               IN v_LostPackets int, IN v_DiscardedPackets int,
                                               IN v_LostPacketsExceededPeriods int,
                                               IN v_BA11consecutiveLostPackets varchar(25),
                                               IN v_ConsecutivePacketLossExceedPeriods int,
                                               IN v_BA11consecutiveGoodPackets varchar(25),
                                               IN v_ConsecutiveGoodPacketsExceedPeriods int,
                                               IN v_CntJitterBufferOverrun int, IN v_CntJitterBufferUnderrun int,
                                               IN v_CodecChangedOnTheFly bit, IN v_TresholdExceededPeriods int,
                                               IN v_rvalue float)
BEGIN
		DELETE FROM QOS_Calc_Data
		WHERE  LocalSubscriberNo = v_LocalSubscriberNo AND MacAddr = v_MacAddr AND Callid = v_Callid;
END;

