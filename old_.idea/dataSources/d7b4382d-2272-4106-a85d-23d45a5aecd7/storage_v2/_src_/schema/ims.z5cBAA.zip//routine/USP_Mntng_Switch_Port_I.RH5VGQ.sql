create
    definer = ims@`%` procedure USP_Mntng_Switch_Port_I(IN v_Svr_Seq int, IN v_Port_No int, IN v_Port_Link varchar(30),
                                                        IN v_Port_State varchar(45), IN v_Tx_Sec varchar(30),
                                                        IN v_Rx_Sec varchar(30), IN v_Uptime varchar(90))
BEGIN
   IF NOT EXISTS(SELECT  Svr_Seq FROM Mntng_Switch_Port WHERE Svr_Seq = v_Svr_Seq AND Port_No = v_Port_No LIMIT 1) then
      INSERT INTO Mntng_Switch_Port(
         Svr_Seq
         ,Port_No
         ,Port_Link
         ,Port_State
         ,Tx_Sec
         ,Rx_Sec
         ,Uptime
         ,Reg_Dt)
      VALUES(
         v_Svr_Seq
         ,v_Port_No
         ,v_Port_Link
         ,v_Port_State
         ,v_Tx_Sec
         ,v_Rx_Sec
         ,v_Uptime
         ,NOW(3)
      );
   ELSE
      UPDATE Mntng_Switch_Port
      SET Port_Link = v_Port_Link
      ,Port_State = v_Port_State
      ,Tx_Sec = v_Tx_Sec
      ,Rx_Sec = v_Rx_Sec
      ,Uptime = v_Uptime
      ,Reg_Dt = NOW(3)
      WHERE Svr_Seq = v_Svr_Seq
      AND Port_No = v_Port_No;
   end if;
END;

