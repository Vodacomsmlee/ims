create
    definer = ims@`%` procedure USP_Mntng_Wallboard_QueueRealTime_S()
BEGIN
	SELECT
	`date`
	, QueueKey
	, FN_QueueNm_S(QueueKey) AS QueueName
	, Contacts
	, OverflowedContacts
	, ServiceLevel
	, EstimatedServiceLevel
	, CONCAT(FORMAT(ROUND(AbandonedRate,2),2),'%') AS AbandonedRate
	, SEC_TO_TIME(OldestContactWaitTime) AS OldestContactWaitTime
	, SEC_TO_TIME(AverageAnsweredWaitTime) AS AverageAnsweredWaitTime
	, SEC_TO_TIME(EstimatedAnsweredWaitTime) AS EstimatedAnsweredWaitTime
	, SEC_TO_TIME(AverageAbandonedWaitTime) AS AverageAbandonedWaitTime
	FROM(
		SELECT
		`date`, QueueKey, Contacts, OverflowedContacts, ServiceLevel,
		EstimatedServiceLevel, AbandonedRate, OldestContactWaitTime,
		AverageAnsweredWaitTime, EstimatedAnsweredWaitTime, AverageAbandonedWaitTime
		,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueRealTime
	) AS A_ROWS
	WHERE
	RN = 1;
END;

