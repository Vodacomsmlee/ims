create
    definer = ims@`%` procedure USP_Code_Que_I(IN v_Que_Code int, IN v_Que_Nm varchar(100),
                                               IN v_Trans_Group_No varchar(10), IN v_Use_Stat tinyint unsigned)
BEGIN
  INSERT INTO Code_Queue(Que_Code, Que_Nm, Trans_Group_No, Use_Stat)VALUES(v_Que_Code, v_Que_Nm, v_Trans_Group_No, v_Use_Stat);
END;

