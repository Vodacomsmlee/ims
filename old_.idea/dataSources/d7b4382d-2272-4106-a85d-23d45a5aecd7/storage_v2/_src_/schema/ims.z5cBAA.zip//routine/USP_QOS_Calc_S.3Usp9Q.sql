create
    definer = ims@`%` procedure USP_QOS_Calc_S(IN v_nType int, IN v_Start datetime, IN v_End datetime, IN v_minr int,
                                               IN v_maxr int, IN v_subscribers varchar(4000))
BEGIN
	call FN_CMM_Split_S(v_subscribers, '|') ;
	
	SELECT 	LocalSubscriberNo
	, MacAddr
	, Callid
	, DATE_FORMAT(StartTime,'%Y-%m-%d %T') as StartTime
	, DATE_FORMAT(StartTime,'%Y-%m-%d %T') as EndTime
	, LocalIpAddr
	, LocalRtpPort
	, RemoteIpAddr
	, RemoteRtpPort
	, rvalue
	, MaxPacketSize
	, GoodPackets
	, LostPackets
	, DiscardedPackets
	, MaxJitter
	, MaxInterJitter
	, AvgRoundTripDelay 
	FROM QOS_Calc_Data
	WHERE LocalSubscriberNo IN (SELECT `VALUE` FROM FN_CMM_Split_S) 
	AND StartTime >= v_Start 
	AND StartTime <= v_End
	ORDER BY StartTime desc;
/*
	IF v_nType=1
		BEGIN
			SELECT *
			FROM dbo.QOS_Calc_Data WITH(READUNCOMMITTED)
			WHERE StartTime between v_start and v_end 
			ORDER BY StartTime
		END
	ELSE IF v_nType=2
		BEGIN
			SELECT * 
			FROM dbo.QOS_Calc_Data WITH(READUNCOMMITTED)
			WHERE LocalSubscriberNo IN (select * from FN_CMM_Split_S(v_subscribers,'|')) 
			AND StartTime between v_start and v_end 
			ORDER BY StartTime
		END
	ELSE IF v_nType=3
		BEGIN
			SELECT * 
			FROM dbo.QOS_Calc_Data WITH(READUNCOMMITTED)
			WHERE StartTime between v_start and v_end 
			AND rvalue between v_minr and v_maxr 
			ORDER BY StartTime
		END
	ELSE IF v_nType=4
		BEGIN
			SELECT * 
			FROM dbo.QOS_Calc_Data WITH(READUNCOMMITTED)
			WHERE LocalSubscriberNo IN (select * from FN_CMM_Split_S(v_subscribers,'|')) 
			AND StartTime between v_start and v_end 
			AND rvalue between v_minr and v_maxr 
			ORDER BY StartTime
		END
	END
*/
END;

