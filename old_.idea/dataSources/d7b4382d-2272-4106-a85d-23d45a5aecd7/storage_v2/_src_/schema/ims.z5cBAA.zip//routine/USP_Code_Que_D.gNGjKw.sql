create
    definer = ims@`%` procedure USP_Code_Que_D(IN v_Seq int)
BEGIN
   UPDATE Code_Queue
   SET Del_Stat = 1
   WHERE SEQ = v_Seq;
END;

