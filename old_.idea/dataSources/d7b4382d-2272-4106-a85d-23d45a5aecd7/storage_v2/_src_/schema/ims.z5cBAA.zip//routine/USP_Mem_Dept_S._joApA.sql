create
    definer = ims@`%` procedure USP_Mem_Dept_S(IN v__Emp_No varchar(10))
BEGIN 
	IF v__Emp_No is null then
		set v__Emp_No = '';
	END IF;
   
	call FN_CMM_Grant_S(v__Emp_No,1);
	
	/*
	select Dept_No, Dept_Nm
	from ims.dept
	where Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S);
	*/
	
WITH RECURSIVE CTE(DEPT_NO, DEPT_NM, High_Dept_No, SYS_CODE, Lvl, Path_Code, Path_Dept_Nm)
AS(
	
	SELECT DEPT_NO, DEPT_NM, High_Dept_No, DEPT_DESC AS SYS_CODE, 1 AS Lvl
	, CAST(DEPT_NO AS varCHAR(100)) AS Path_Code
	, CAST(DEPT_NM AS VARCHAR(100)) AS Path_Dept_Nm
	FROM ims.dept A
	WHERE NOT EXISTS (SELECT DEPT_NO FROM ims.dept WHERE DEPT_NO = A.High_Dept_No LIMIT 1)
	
	UNION ALL
	
	SELECT C.DEPT_NO, C.DEPT_NM, C.High_Dept_No, C.DEPT_DESC, Lvl + 1 AS Lvl
	, CONCAT(Path_Code,'/',CAST(C.DEPT_NO AS VARCHAR(100))) AS Path_Code
	, CONCAT(Path_Dept_Nm,' > ',CAST(C.DEPT_NM AS VARCHAR(100))) AS Path_Dept_Nm
	FROM ims.dept C 
	INNER JOIN CTE CCte ON C.High_Dept_No = CCte.DEPT_NO
)
SELECT Dept_No, Path_Dept_Nm as Dept_Nm, High_Dept_No, SYS_CODE, Lvl, Path_Code, Path_Dept_Nm
FROM CTE
WHERE Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
ORDER BY Path_Code ASC ;
	/*
	
	WITH RECURSIVE CTE(Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm)
	AS(
		SELECT Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, 1 AS Lvl
		
		, CAST(Dept_No AS CHAR(10)) AS Path_Code
		, CAST(Dept_Nm AS CHAR(50)) AS Path_Dept_Nm
		FROM Dept 
		WHERE High_Dept_No IS NULL
		AND Del_Stat = 0
		
		UNION ALL
		
		SELECT C.Dept_No, C.Dept_Nm, C.High_Dept_No, C.Team_Key, C.Dept_Desc, Lvl + 1 AS Lvl
		, CONCAT(Path_Code,'/',CAST(C.Dept_No AS CHAR(10))) AS Path_Code
		, CONCAT(Path_Dept_Nm,' > ',CAST(C.Dept_Nm AS CHAR(50))) AS Path_Dept_Nm
		FROM Dept C 
		INNER JOIN CTE CCte ON C.High_Dept_No = CCte.Dept_No
		WHERE Del_Stat = 0
	)
	SELECT Dept_No, Path_Dept_Nm as Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm
	FROM CTE
	where Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
	ORDER BY Path_Code ASC ;
	*/
END;

