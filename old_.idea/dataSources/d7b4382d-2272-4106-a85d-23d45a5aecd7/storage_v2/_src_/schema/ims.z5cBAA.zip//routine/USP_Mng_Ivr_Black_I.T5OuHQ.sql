create
    definer = ims@`%` procedure USP_Mng_Ivr_Black_I(IN v_BL_TELNO varchar(20), IN v_BL_DESC varchar(50))
BEGIN
	if not exists(select BL_SEQUENCE from ims.mng_ivr_blacklist where BL_TELNO = REPLACE(v_BL_TELNO, '-','') limit 1) then
		insert into ims.mng_ivr_blacklist(BL_TELNO, BL_DESC)
		values (replace(v_BL_TELNO, '-',''), v_BL_DESC);
	end if;
END;

