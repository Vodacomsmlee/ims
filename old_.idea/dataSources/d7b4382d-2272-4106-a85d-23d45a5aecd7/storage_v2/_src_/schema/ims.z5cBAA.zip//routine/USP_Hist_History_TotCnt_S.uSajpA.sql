create
    definer = ims@`%` procedure USP_Hist_History_TotCnt_S(IN v_start int, IN v_length int, IN v_SearchText varchar(100))
BEGIN
	-- 전체 Row Count
	IF v_start IS NULL THEN
		SET v_start = 0;
	END IF;
	IF v_length IS NULL THEN
		SET v_length = 15;
	END IF;
	IF v_SearchText IS NULL THEN
		SET v_SearchText = '';
	END IF;
	SELECT COUNT(1) TotRowCnt FROM HISTORY;
	
END;

