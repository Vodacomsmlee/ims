create
    definer = ims@`%` procedure USP_Mntng_Group_Realtime_All_S()
BEGIN
SELECT `date`,`GroupKey`
FROM `mntng_grouprealtime`;
END;

