create
    definer = ims@`%` procedure USP_Code_Que_U(IN v_Seq int, IN v_Que_Code int, IN v_Que_Nm varchar(100),
                                               IN v_Trans_Group_No varchar(10), IN v_Use_Stat tinyint unsigned)
BEGIN
	UPDATE Code_Queue
	SET Que_Code = v_Que_Code,Que_Nm = v_Que_Nm,Trans_Group_No = v_Trans_Group_No, 
	Use_Stat = v_Use_Stat
	WHERE SEQ = v_Seq;
END;

