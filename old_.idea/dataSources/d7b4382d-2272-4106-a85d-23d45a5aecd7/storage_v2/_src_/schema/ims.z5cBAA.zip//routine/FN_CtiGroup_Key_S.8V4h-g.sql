create
    definer = ims@`%` function FN_CtiGroup_Key_S(v_Group_Seq int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN INT;
   select   Group_Key INTO v_RETURN FROM Mng_Cti_Group  WHERE Group_Seq = v_Group_Seq
   AND Del_Stat = 0;
   RETURN v_RETURN;
END;

