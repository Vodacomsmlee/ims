create
    definer = ims@`%` procedure USP_Mntng_Queue_Cumulative_MAX2_S()
BEGIN
SELECT * FROM (
SELECT ROW_NUMBER() OVER(PARTITION BY `QueueKey` ORDER BY `date` DESC)
AS RN, `date`, `QueueKey`
FROM `mntng_queuecumulative`
) AS A_ROWS
WHERE RN=1;
END;

