create
    definer = ims@`%` procedure USP_Cmm_SSO_U(IN v_Emp_No varchar(10), IN v_Auth_Key varchar(100))
BEGIN
   UPDATE Emp
   SET Auth_Key = v_Auth_Key
   WHERE Emp_No = v_Emp_No;
END;

