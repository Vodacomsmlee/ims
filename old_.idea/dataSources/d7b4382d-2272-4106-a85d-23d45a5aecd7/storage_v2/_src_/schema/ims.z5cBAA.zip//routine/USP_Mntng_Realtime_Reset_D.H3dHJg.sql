create
    definer = ims@`%` procedure USP_Mntng_Realtime_Reset_D()
BEGIN
TRUNCATE TABLE `mntng_aggredaterealtime`;
TRUNCATE TABLE `mntng_contactrealtime`;
TRUNCATE TABLE `mntng_grouprealtime`;
TRUNCATE TABLE `mntng_queuerealtime`;
TRUNCATE TABLE `mntng_userrealtime`;
END;

