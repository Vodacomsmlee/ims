create
    definer = ims@`%` procedure USP_Mng_Ivr_Voice_ServiceID_S(IN v_serviceID varchar(20))
BEGIN
   SELECT COUNT(1) AS CNT FROM Mng_Ivr_Prompt WHERE SC_PROMPT = v_serviceID;
END;

