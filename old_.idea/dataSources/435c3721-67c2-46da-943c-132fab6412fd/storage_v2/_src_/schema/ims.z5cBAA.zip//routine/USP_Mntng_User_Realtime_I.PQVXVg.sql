create
    definer = ims@`%` procedure USP_Mntng_User_Realtime_I(IN v_userKey int, IN v_extension varchar(20),
                                                          IN v_routingState varchar(20),
                                                          IN v_routingStateReasonKey int(10),
                                                          IN v_timeInRoutingState int(10),
                                                          IN v_presenceState varchar(20),
                                                          IN v_timeInPresenceState int(10),
                                                          IN v_handlingState varchar(20),
                                                          IN v_handlingStateReason int(10),
                                                          IN v_timeInHandlingState int(10),
                                                          IN v_uniqueCallId varchar(30), IN v_contactType varchar(40),
                                                          IN v_description varchar(50), IN v_associatedQueueKey int(10),
                                                          IN v_userHandlingTime int(10))
BEGIN
INSERT INTO `mntng_userrealtime`(
`date`
,`UserKey`
,`Department`
,`Extension`
,`RoutingState`
,`RoutingStateReasonKey`
,`TimeInRoutingState`
,`PresenceState`
,`TimeInPresenceState`
,`HandlingState`
,`HandlingStateReasonKey`
,`TimeInHandlingState`
,`CallID`
,`ContactType`
,`ContactDescription`
,`AssociatedQueueKey`
,`TotalContactHandlingTime`)
VALUES(CURRENT_TIMESTAMP(6)
,v_userKey
,FN_Get_UserKeyToDeptNo(v_userKey)
,v_extension
,v_routingState
,v_routingStateReasonKey
,v_timeInRoutingState
,v_presenceState
,v_timeInPresenceState
,v_handlingState
,v_handlingStateReason
,v_timeInHandlingState
,v_uniqueCallId
,v_contactType
,v_description
,v_associatedQueueKey
,v_userHandlingTime);
END;

