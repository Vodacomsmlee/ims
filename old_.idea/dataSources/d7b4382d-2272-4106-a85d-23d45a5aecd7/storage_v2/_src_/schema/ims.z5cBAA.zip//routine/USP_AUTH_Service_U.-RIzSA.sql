create
    definer = ims@`%` procedure USP_AUTH_Service_U(IN v_Svc_No int, IN v_Svc_Nm varchar(100), IN v_Svc_Url varchar(200),
                                                   IN v_Use_Stat tinyint unsigned)
BEGIN
	IF v_Use_Stat is null then
		set v_Use_Stat = 0;
	END IF;
	
	IF v_Svc_No IS NOT NULL then
		UPDATE Role_Service
		SET Svc_Nm = v_Svc_Nm,Svc_Url = v_Svc_Url,Use_Stat = v_Use_Stat
		WHERE Svc_No = v_Svc_No;
	end if;
END;

