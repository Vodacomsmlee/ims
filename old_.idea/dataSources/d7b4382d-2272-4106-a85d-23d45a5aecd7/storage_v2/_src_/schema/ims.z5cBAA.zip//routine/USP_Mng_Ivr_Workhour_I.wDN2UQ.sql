create
    definer = ims@`%` procedure USP_Mng_Ivr_Workhour_I(IN v_WH_Code int, IN v_WH_Type tinyint unsigned,
                                                       IN v_WH_START varchar(10), IN v_WH_END varchar(10),
                                                       IN v_WH_LUNCH_YN tinyint unsigned,
                                                       IN v_WH_LUNCH_START varchar(10), IN v_WH_LUNCH_END varchar(10),
                                                       IN v_WH_BEFORE_PROMPT varchar(10),
                                                       IN v_WH_AFTER_PROMPT varchar(10),
                                                       IN v_WH_LUNCH_PROMPT varchar(10), IN v_WH_OUTSERVICE int,
                                                       IN v_WH_OUTSERVICE_TARGET varchar(15), IN v_WH_IN_LUNCH int,
                                                       IN v_WH_IN_LUNCH_TARGET varchar(10))
BEGIN
	INSERT INTO Mng_Ivr_Workhour(
		WH_Code
		,WH_Type
		,WH_START
		,WH_END
		,WH_LUNCH_YN
		,WH_LUNCH_START
		,WH_LUNCH_END
		,WH_BEFORE_PROMPT
		,WH_AFTER_PROMPT
		,WH_LUNCH_PROMPT
		,WH_OUTSERVICE
		,WH_OUTSERVICE_TARGET
		,WH_IN_LUNCH
		,WH_IN_LUNCH_TARGET
	) VALUES (
		v_WH_Code
		,v_WH_Type
		,RIGHT(CONCAT_WS('','0',v_WH_START),4)
		,RIGHT(CONCAT_WS('','0',v_WH_END),4)
		,v_WH_LUNCH_YN
		,RIGHT(CONCAT_WS('','0',v_WH_LUNCH_START),4)
		,RIGHT(CONCAT_WS('','0',v_WH_LUNCH_END),4)
		,v_WH_BEFORE_PROMPT
		,v_WH_AFTER_PROMPT
		,v_WH_LUNCH_PROMPT
		,v_WH_OUTSERVICE
		,v_WH_OUTSERVICE_TARGET
		,v_WH_IN_LUNCH
		,v_WH_IN_LUNCH_TARGET
	);
END;

