create
    definer = ims@`%` procedure USP_Mng_CtiHuntGroup_S()
BEGIN
	-- MOH 헌트그룹
	select resourcename, resourcenum from ims_ifx.Resources where resourcetype = 3 and subtype = 3 order by resourcenum;
	-- Initial 헌트 그룹
	select resourcename, resourcenum, resourceproperty from ims_ifx.Resources where resourcetype = 5 and resourceproperty <> '' order by resourcenum;
END;

