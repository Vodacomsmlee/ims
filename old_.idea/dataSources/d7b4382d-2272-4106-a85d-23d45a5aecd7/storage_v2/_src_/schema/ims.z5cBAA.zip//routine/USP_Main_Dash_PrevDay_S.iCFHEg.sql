create
    definer = ims@`%` procedure USP_Main_Dash_PrevDay_S()
BEGIN
	DECLARE v_IP_PBX_PREV_IN INT;
	DECLARE v_IP_PBX_PREV_OUT INT;
	DECLARE v_IVR_PREV_IN INT;
	DECLARE v_IVR_PREV_AGENT_REQ INT;
	DECLARE v_IVR_PREV_SERVICE_TRANS INT;
	DECLARE v_IVR_PREV_ABANDON INT;
	DECLARE v_IVR_PREV_CALLBACK INT;
	DECLARE v_CTI_PREV_Answered INT;
	DECLARE v_CTI_PREV_Abandoned INT;
	DECLARE v_CTI_PREV_Received INT;
	DECLARE v_CTI_PREV_CallBack INT;
	DECLARE v_CTI_PREV_Received_Rate FLOAT;
   
	-- IP-교환기 대표번호 수신 전일 누적
	select SUM(CNT) INTO v_IP_PBX_PREV_IN 
	FROM(
		SELECT COUNT(DISTINCT(callid)) CNT
		FROM ims_ifx.callrecord A 
		JOIN Code_CalledNumber B  ON A.origdestination = B.CalledNumber
		WHERE contacttype IN(1,2)
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
		AND waitresolution IN(1,2,3)
		UNION ALL
		SELECT COUNT(DISTINCT(callid)) CNT
		FROM ims_ifx.callrecord1 A 
		JOIN Code_CalledNumber B  ON A.origdestination = B.CalledNumber
		WHERE contacttype IN(1,2)
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
		AND waitresolution IN(1,2,3)
		UNION ALL
		SELECT COUNT(DISTINCT(callid)) CNT
		FROM ims_ifx.callrecord2 A 
		JOIN Code_CalledNumber B  ON A.origdestination = B.CalledNumber
		WHERE contacttype IN(1,2)
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
		AND waitresolution IN(1,2,3)
	) X;
	
	-- IP-교환기	발신 전일 누적
	select SUM(CNT) INTO v_IP_PBX_PREV_OUT 
	FROM(
		SELECT COUNT(1) CNT
		FROM ims_ifx.callRecord A 
		JOIN ims_ifx.agentRecord B ON A.callid = B.callid
			AND A.arrivalsite = B.agentsite
			AND A.requeuecount = B.requeuecount
			AND B.jointype = 1
			AND B.termtype <> 48
		WHERE  A.contacttype = 3
		AND tothandlingtime > 0
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
		UNION ALL
		SELECT COUNT(1) CNT
		FROM ims_ifx.callRecord1 A 
		JOIN ims_ifx.agentRecord B ON A.callid = B.callid
			AND A.arrivalsite = B.agentsite
			AND A.requeuecount = B.requeuecount
			AND B.jointype = 1
			AND B.termtype <> 48
		WHERE  A.contacttype = 3
		AND tothandlingtime > 0
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
		UNION ALL
		SELECT COUNT(1) CNT
		FROM ims_ifx.callRecord2 A 
		JOIN ims_ifx.agentRecord B ON A.callid = B.callid
			AND A.arrivalsite = B.agentsite
			AND A.requeuecount = B.requeuecount
			AND B.jointype = 1
			AND B.termtype <> 48
		WHERE  A.contacttype = 3
		AND tothandlingtime > 0
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
	) X; 
	  
	  
	select COUNT(1)
	, SUM(CASE WHEN FAILYN = 'N' THEN 1 ELSE  0 END)
	, SUM(CASE WHEN ROUTENUM = '' THEN 1 ELSE  0 END)
	, SUM(CASE WHEN FAILYN = 'Y' THEN 1 ELSE  0 END)
	, SUM(CASE WHEN CALLBACK = 1 THEN 1 ELSE  0 END) 
	INTO v_IVR_PREV_IN
	,v_IVR_PREV_AGENT_REQ
	,v_IVR_PREV_SERVICE_TRANS
	,v_IVR_PREV_ABANDON
	,v_IVR_PREV_CALLBACK FROM TB_IVRSTATISTICS  A 
	JOIN Code_CalledNumber B ON A.DNIS = B.CalledNumber 
	WHERE DATE_FORMAT(startdate,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d');
	select
	SUM(Answered)
	, SUM(Abandoned)
	, SUM(Received)
	, ROUND((cast(SUM(Answered) as DECIMAL(15,15))/cast(SUM(Received) as DECIMAL(15,15)))*100,2) rate
	INTO v_CTI_PREV_Answered
	,v_CTI_PREV_Abandoned
	,v_CTI_PREV_Received
	,v_CTI_PREV_Received_Rate 
	FROM (
		SELECT
		Answered
		, Abandoned
		, Received
		, ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) RowNum
		  FROM Mntng_QueueCumulative 
		  WHERE DATE_FORMAT(`date`,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(DAY,-1,CURRENT_TIMESTAMP),'%Y-%m-%d')
	)X 
	WHERE RowNum = 1;
	select COUNT(1) INTO v_CTI_PREV_CallBack 
	FROM Mng_Ivr_Callback  
	WHERE CB_RESULT = 1
	AND DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d') = DATE_FORMAT(TIMESTAMPADD(day,-1,CURRENT_TIMESTAMP),'%Y-%m-%d');
	SELECT IFNULL(v_IP_PBX_PREV_IN,0) IP_PBX_PREV_IN
	, IFNULL(v_IP_PBX_PREV_OUT,0) IP_PBX_PREV_OUT
	, IFNULL(v_IVR_PREV_IN,0) IVR_PREV_IN
	, IFNULL(v_IVR_PREV_AGENT_REQ,0) IVR_PREV_AGENT_REQ
	, IFNULL(v_IVR_PREV_SERVICE_TRANS,0) IVR_PREV_SERVICE_TRANS
	, IFNULL(v_IVR_PREV_ABANDON,0) IVR_PREV_ABANDON
	, IFNULL(v_IVR_PREV_CALLBACK,0) IVR_PREV_CALLBACK
	, IFNULL(v_CTI_PREV_Answered,0) CTI_PREV_Answered
	, IFNULL(v_CTI_PREV_Abandoned,0) CTI_PREV_Abandoned
	, IFNULL(v_CTI_PREV_Received,0) CTI_PREV_Received
	, IFNULL(v_CTI_PREV_Received_Rate,0) CTI_PREV_Received_Rate
	, IFNULL(v_CTI_PREV_CallBack,0) CTI_PREV_CallBack
	, IFNULL(ROUND((cast((v_CTI_PREV_Answered+v_CTI_PREV_CallBack) as DECIMAL(15,15))/cast(v_CTI_PREV_Received as DECIMAL(15,15)))*100,2), 0) CTI_PREV_CallBack_Rate;
	-- , CTI_PREV_Abandoned_Rate = ROUND(( CAST((@CTI_PREV_Abandoned) AS FLOAT) / CAST(@CTI_PREV_Received AS FLOAT) ) * 100,2)
END;

