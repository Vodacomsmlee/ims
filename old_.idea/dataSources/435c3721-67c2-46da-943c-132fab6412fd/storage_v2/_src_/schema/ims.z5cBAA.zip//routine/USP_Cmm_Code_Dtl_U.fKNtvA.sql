create
    definer = ims@`%` procedure USP_Cmm_Code_Dtl_U(IN v_Cmm_Dtl_Code_Idx int, IN v_Cmm_Dtl_Code varchar(200),
                                                   IN v_Cmm_Dtl_Code_Nm varchar(100), IN v_Edit_Emp_Code varchar(10))
BEGIN
	IF v_Edit_Emp_Code is null then
		set v_Edit_Emp_Code = '';
	END IF;
	
	UPDATE Code_Cmm_Dtl
	SET Cmm_Dtl_Code = v_Cmm_Dtl_Code
	, Cmm_Dtl_Code_Nm = v_Cmm_Dtl_Code_Nm
	, Edit_Emp_Code = v_Edit_Emp_Code
	, Last_Edit_Dt = SYSDATE(3)
	WHERE Cmm_Dtl_Code_Idx = v_Cmm_Dtl_Code_Idx;
	
END;

