create
    definer = ims@`%` procedure USP_Mem_Total_Dept_S()
BEGIN
	
WITH RECURSIVE CTE(Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm)
AS(
	
	SELECT Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, 1 AS Lvl
	, CAST(Dept_No AS CHAR(10)) AS Path_Code
	, CAST(Dept_Nm AS CHAR(50)) AS Path_Dept_Nm
	FROM ims.dept A
	WHERE NOT EXISTS (SELECT DEPT_NO FROM ims.dept WHERE DEPT_NO = A.High_Dept_No LIMIT 1)
	
	UNION ALL
	
	SELECT C.Dept_No, C.Dept_Nm, C.High_Dept_No, C.Team_Key, C.Dept_Desc, Lvl + 1 AS Lvl
	, CONCAT(Path_Code,'/',CAST(C.DEPT_NO AS CHAR(10))) AS Path_Code
	, CONCAT(Path_Dept_Nm,' > ',CAST(C.DEPT_NM AS CHAR(50))) AS Path_Dept_Nm
	FROM ims.dept C 
	INNER JOIN CTE CCte ON C.High_Dept_No = CCte.DEPT_NO
)
SELECT Dept_No, Dept_Nm, High_Dept_No, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm, X.Team_Key, Y.teamname
FROM CTE X
LEFT OUTER JOIN ims_ifx.teams Y ON X.Team_Key = Y.teamkey
ORDER BY Path_Code ASC ;



	/*
	SELECT Dept_No, Dept_Nm, Dept_Type, High_Dept_No, Team_Key, Dept_Desc
	FROM Dept 
	WHERE Del_Stat = 0
	ORDER BY Dept_Nm;

	WITH RECURSIVE CTE(Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm)
	AS(
		SELECT Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, 1 AS Lvl
		
		, CAST(Dept_No AS CHAR(10)) AS Path_Code
		, CAST(Dept_Nm AS CHAR(50)) AS Path_Dept_Nm
		FROM Dept 
		WHERE High_Dept_No IS NULL
		AND Del_Stat = 0
		
		UNION ALL
		
		SELECT C.Dept_No, C.Dept_Nm, C.High_Dept_No, C.Team_Key, C.Dept_Desc, Lvl + 1 AS Lvl
		, CONCAT(Path_Code,'/',CAST(C.Dept_No AS CHAR(10))) AS Path_Code
		, CONCAT(Path_Dept_Nm,' > ',CAST(C.Dept_Nm AS CHAR(50))) AS Path_Dept_Nm
		FROM Dept C 
		INNER JOIN CTE CCte ON C.High_Dept_No = CCte.Dept_No
		WHERE Del_Stat = 0
	)
	SELECT Dept_No, Dept_Nm, High_Dept_No, Team_Key, Dept_Desc, Lvl, Path_Code, Path_Dept_Nm
	FROM CTE
	ORDER BY Path_Code asc ;
	*/
	
	
END;

