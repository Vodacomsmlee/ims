create
    definer = ims@`%` procedure USP_AUTH_Role_I(IN v_Role_Nm varchar(30), IN v_CCAPP_Admin_Stat tinyint unsigned)
BEGIN
	IF v_CCAPP_Admin_Stat is null then
		set v_CCAPP_Admin_Stat = 0;
	END IF;
	IF IFNULL(v_Role_Nm,'') <> '' then
		INSERT INTO Role(Role_Nm, CCAPP_Admin_Stat) VALUES(v_Role_Nm, v_CCAPP_Admin_Stat);
	end if;
END;

