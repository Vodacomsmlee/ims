create
    definer = ims@`%` procedure USP_Mem_Emp_Pwd_U(IN v_Emp_No varchar(10), IN v_Pwd varchar(50),
                                                  IN v_newPwd varchar(50))
BEGIN
	/*
	비밀번호 변경
	*/
	DECLARE v_RST INT;
	SET v_RST = 0;
	IF NOT EXISTS(SELECT Emp_No FROM Emp WHERE Emp_No = v_Emp_No AND Emp_Passwd = SHA2(v_Pwd, 256) AND Del_Stat = 0 LIMIT 1) then		
		SET v_RST = -1;
	ELSE
		IF v_Pwd = v_newPwd then		
			SET v_RST = -2;
		ELSE
			UPDATE Emp
			SET Emp_Passwd = SHA2(v_newPwd,256),Last_PassWd_Edit_Dt = CURRENT_TIMESTAMP
			WHERE Emp_No = v_Emp_No;
		end if;
	end if;
	SELECT v_RST Result, DATE_FORMAT(Last_PassWd_Edit_Dt,'%Y-%m-%d %T:%f') as Last_PassWd_Edit_Dt
	FROM Emp  WHERE Emp_No = v_Emp_No; 
END;

