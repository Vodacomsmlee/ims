create
    definer = ims@`%` procedure USP_Mntng_User_Cumulative_U(IN v_date datetime, IN v_userKey int,
                                                            IN v_utilization float, IN v_offered int(10),
                                                            IN v_handled int(10), IN v_abandonedWhileRinging int(10),
                                                            IN v_unhandledRouted int(10),
                                                            IN v_undeliveredRouted int(10), IN v_routedHeld int(10),
                                                            IN v_routedConsulted int(10),
                                                            IN v_routedTransferred int(10), IN v_totalLogonTime int(10),
                                                            IN v_ringingTime int(10), IN v_totalPendingTime int(10),
                                                            IN v_handlingTime int(10), IN v_totalOtherTime int(10),
                                                            IN v_maximumRoutedHandlingTime int(10),
                                                            IN v_totalRoutedTalkTime int(10),
                                                            IN v_totalRoutedHoldTime int(10),
                                                            IN v_disconnectedRoutedCalls int(10), IN v_requeue int(10),
                                                            IN v_totalPostProcessingTime int(10),
                                                            IN v_totalIdleTime int(10), IN v_totalAwayTime int(10),
                                                            IN v_totalBusyTime int(10))
BEGIN
UPDATE mntng_usercumulative SET
`Utilization`=v_utilization
,`Offered`=v_offered
,`Handled`=v_handled
,`AbandonedWhileRinging`=v_abandonedWhileRinging
,`Unhandled`=(v_unhandledRouted+v_undeliveredRouted)
,`RoutedHeld`=v_routedHeld
,`ConsultedOut`=v_routedConsulted
,`TransferredOut`=v_routedTransferred
,`TotalLoggedOnTime`=v_totalLogonTime
,`TotalRingTime`=v_ringingTime
,`TotalPendingTime`=v_totalPendingTime
,`TotalHandledTime`=v_handlingTime
,`TotalTimeOther`=v_totalOtherTime
,`MaximumRoutedHandlingTime`=v_maximumRoutedHandlingTime
,`TotalTalkTime`=v_totalRoutedTalkTime
,`TotalHoldTime`=v_totalRoutedHoldTime
,`Disconnected`=v_disconnectedRoutedCalls
,`Requeued`=v_requeue
,`TotalPostProcessingTime`=v_totalPostProcessingTime
,`TotalIdleTime`=v_totalIdleTime
,`TotalAwayTime`=v_totalAwayTime
,`TotalBusyTime`=v_totalBusyTime
WHERE
`date`=v_date AND `UserKey`=v_userKey;
END;

