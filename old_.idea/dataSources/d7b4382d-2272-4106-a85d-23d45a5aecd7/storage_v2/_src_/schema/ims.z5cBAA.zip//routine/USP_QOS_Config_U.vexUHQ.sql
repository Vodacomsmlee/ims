create
    definer = ims@`%` procedure USP_QOS_Config_U(IN v_nType int, IN v_value varchar(25))
begin
	IF v_nType=1 THEN-- path
		UPDATE QOS_CONFIG set value=v_value WHERE name='report_path';
	ELSEIF v_nType=2 THEN-- packet
		UPDATE QOS_CONFIG set value=v_value WHERE name='packet';
	ELSEIF v_nType=3 THEN-- cursor
		UPDATE QOS_CONFIG set value=v_value WHERE name='cursor';
	end if;
end;

