create
    definer = ims@`%` procedure USP_Mnt_Mntng_Proc_I(IN v_Svr_Ip varchar(15), IN v_Process_Nm varchar(100),
                                                     IN v_Process_Cnt int)
BEGIN
	IF v_Process_Nm is null then
		set v_Process_Nm = '';
	END IF;
	IF v_Process_Cnt is null then
		set v_Process_Cnt = 0;
	END IF;
	
	INSERT INTO Mntng_Process(Svr_Ip, Process_Nm, Process_Cnt) VALUES(v_Svr_Ip, v_Process_Nm, v_Process_Cnt);
END;

