create
    definer = ims@`%` procedure USP_Mng_Ivr_Menu_U(IN v_SC_MENU int, IN v_SC_DIGIT varchar(10), IN v_SC_NEXT int,
                                                   IN v_SC_NEXTNAME int, IN v_SC_NOTI_YN int, IN v_SC_NOTI int)
BEGIN
	UPDATE Mng_Ivr_ScenarioMenuSub
	SET SC_NEXT = v_SC_NEXT
	,SC_NEXTNAME = v_SC_NEXTNAME
	,SC_NOTI_YN = v_SC_NOTI_YN
	,SC_NOTI = v_SC_NOTI
	WHERE SC_MENU = v_SC_MENU 
	AND SC_DIGIT = v_SC_DIGIT;
END;

