create
    definer = ims@`%` procedure USP_Mntng_Cumulative_from_MAX_before_15m_D(IN v_date datetime)
BEGIN
DELETE FROM `mntng_usercumulative` WHERE `date`>=v_date;
DELETE FROM `mntng_queuecumulative` WHERE `date`>=v_date;
DELETE FROM `mntng_groupcumulative` WHERE `date`>=v_date;
DELETE FROM `mntng_aggregatecumulative` WHERE `date`>=v_date;
END;

