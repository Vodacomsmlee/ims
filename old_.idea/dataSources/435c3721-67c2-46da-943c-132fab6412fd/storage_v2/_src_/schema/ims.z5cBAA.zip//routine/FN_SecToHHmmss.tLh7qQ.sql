create
    definer = ims@`%` function FN_SecToHHmmss(v_SEC int) returns varchar(50)
BEGIN 
   DECLARE v_RETURN VARCHAR(50);
   SET v_SEC = IFNULL(v_SEC,0);
   
   SET v_RETURN = CONCAT( CAST(TRUNCATE(v_SEC/(60*60),0) AS INT) , ':', RIGHT(CONCAT('0',CAST(TRUNCATE((v_SEC / 60) % 60 ,0) AS INT)),2) , ':', RIGHT(CONCAT('0',CAST(TRUNCATE(v_SEC%60,0) AS INT)),2) );
   RETURN v_RETURN;
END;

