create
    definer = ims@`%` procedure USP_Mntng_User_Realtime_D(IN v_userKey int(10))
BEGIN
DELETE FROM `mntng_userrealtime` WHERE `UserKey`=v_userKey;
END;

