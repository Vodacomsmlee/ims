create
    definer = ims@`%` procedure FN_CMM_Split_S(IN sStringIn longtext, IN splitChar varchar(64)) comment '문자열 분리'
BEGIN
	DECLARE mText LONGTEXT;
	DECLARE mValue LONGTEXT;
	SET max_heap_table_size = 1024 * 1024 * 256;
	DROP TEMPORARY TABLE IF EXISTS FN_CMM_Split_S;
	CREATE TEMPORARY TABLE FN_CMM_Split_S
	(
		seq INT NOT NULL AUTO_INCREMENT
		, `value` VARCHAR(100) NOT NULL DEFAULT ''
		, PRIMARY KEY (`seq`)
	) ENGINE = MEMORY;
	SET mText = sStringIn;
	WHILE IFNULL(mText, '') != '' DO
		SET mValue = SUBSTRING_INDEX(mText, splitChar, 1);
		SET mText = SUBSTRING(mText, CHAR_LENGTH(mValue) + CHAR_LENGTH(splitChar) + 1);
		INSERT INTO FN_CMM_Split_S (`value`) VALUES (mValue);
	END WHILE;
END;

