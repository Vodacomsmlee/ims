create
    definer = ims@`%` procedure USP_Mng_Ivr_MenuSet_U(IN v_SC_MENU int, IN v_SC_MENUNAME varchar(50),
                                                      IN v_SC_PROMPT varchar(50), IN v_SC_DIGIT varchar(50))
BEGIN
	UPDATE Mng_Ivr_ScenarioMenu
	SET SC_MENUNAME = v_SC_MENUNAME
	,SC_PROMPT = v_SC_PROMPT
	,SC_DIGIT = v_SC_DIGIT
	WHERE SC_MENU = v_SC_MENU;
END;

