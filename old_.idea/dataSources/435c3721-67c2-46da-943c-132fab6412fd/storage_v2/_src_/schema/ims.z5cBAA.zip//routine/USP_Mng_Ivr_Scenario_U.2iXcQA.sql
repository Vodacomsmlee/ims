create
    definer = ims@`%` procedure USP_Mng_Ivr_Scenario_U(IN v_SC_CODE int, IN v_Dept_No int, IN v_SC_NAME varchar(20),
                                                       IN v_SC_NOTI_YN tinyint unsigned, IN v_SC_NOTI int,
                                                       IN v_SC_NEXT int, IN v_SC_NEXT_TARGET varchar(15),
                                                       IN v_SC_PROMPT_YN tinyint unsigned, IN v_SC_PROMPT varchar(10))
BEGIN
	UPDATE Mng_Ivr_Scenario
	SET Dept_No = v_Dept_No
	,SC_NAME = v_SC_NAME
	,SC_NOTI_YN = v_SC_NOTI_YN
	,SC_NOTI = v_SC_NOTI
	,SC_NEXT = v_SC_NEXT
	,SC_NEXT_TARGET = v_SC_NEXT_TARGET
	,SC_PROMPT_YN = v_SC_PROMPT_YN
	,SC_PROMPT = v_SC_PROMPT
	WHERE SC_CODE = v_SC_CODE;
END;

