create
    definer = ims@`%` procedure USP_Stt_IVR_Statistics_S(IN v_servicelist varchar(4000),
                                                         IN v_Srch_Type tinyint unsigned, IN v_Start_Dt datetime,
                                                         IN v_End_Dt datetime)
BEGIN
	IF v_Srch_Type is null then
		set v_Srch_Type = 0;
	END IF;
	
	IF v_Srch_Type = 0 then -- 월별
		call FN_CMM_Split_S(v_servicelist,'|');
		
		SELECT
			DT, Group_Seq,
			ims.FN_CtiGroup_Nm_S(Group_Seq) SERVICE_NAME,
			SUM(CASE WHEN ROUTENUM = '' THEN CNT ELSE 0 END) TRANS_CNT,
			SUM(CASE WHEN ROUTENUM != '' THEN CNT ELSE 0 END) AGENT_CNT,
			SUM(CNT) RECEIVE_CNT
		FROM
			(
			SELECT DATE_FORMAT(startdate,'%Y-%m') as DT, Group_Seq, ROUTENUM,  COUNT(1) CNT
			FROM TB_IVRSTATISTICS 
			WHERE Group_Seq IN(SELECT `VALUE` FROM FN_CMM_Split_S)
			AND startdate >= CONCAT(DATE_FORMAT(v_Start_Dt,'%Y-%m'),'-01') -- Index 태우기 위해 날짜를 만들어준다.
			AND CONCAT(DATE_FORMAT(v_Start_Dt,'%Y-%m'),'-01') <= LAST_DAY(v_End_Dt)
			and ifnull(Group_Seq,'') <> ''
			GROUP BY DATE_FORMAT(startdate,'%Y-%m'),Group_Seq,ROUTENUM) AS AGG
		GROUP BY DT, Group_Seq;
	end if;
	
	
	IF v_Srch_Type = 1 then -- 일별
		call FN_CMM_Split_S(v_servicelist,'|');
	
		SELECT
			DT, Group_Seq,
			ims.FN_CtiGroup_Nm_S(Group_Seq) SERVICE_NAME,
			SUM(CASE WHEN ROUTENUM = '' THEN CNT ELSE 0 END) TRANS_CNT,
			SUM(CASE WHEN ROUTENUM != '' THEN CNT ELSE 0 END) AGENT_CNT,
			SUM(CNT) RECEIVE_CNT
		FROM
			(
			SELECT DATE_FORMAT(startdate,'%Y-%m-%d') as DT, Group_Seq, ROUTENUM, COUNT(1) CNT
			FROM TB_IVRSTATISTICS 
			WHERE Group_Seq IN(SELECT `VALUE` FROM FN_CMM_Split_S)
			AND startdate >= DATE_FORMAT(v_Start_Dt,'%Y-%m-%d') -- Index 태우기 위해 날짜를 CONVERT 해준다.
			AND DATE_FORMAT(startdate,'%Y-%m-%d') <= DATE_FORMAT(v_End_Dt,'%Y-%m-%d')
			GROUP BY DATE_FORMAT(startdate,'%Y-%m-%d'),Group_Seq,ROUTENUM
			) AS AGG
		GROUP BY DT,Group_Seq;
	end if;
	
END;

