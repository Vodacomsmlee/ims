create
    definer = ims@`%` procedure USP_Mnt_Mntng_Proc_U(IN v_Proc_Seq int, IN v_Svr_Ip varchar(15),
                                                     IN v_Process_Nm varchar(100), IN v_Process_Cnt int)
BEGIN
	UPDATE Mntng_Process
	SET Process_Nm = v_Process_Nm,Process_Cnt = v_Process_Cnt
	WHERE Seq = v_Proc_Seq AND Svr_Ip = v_Svr_Ip;
END;

