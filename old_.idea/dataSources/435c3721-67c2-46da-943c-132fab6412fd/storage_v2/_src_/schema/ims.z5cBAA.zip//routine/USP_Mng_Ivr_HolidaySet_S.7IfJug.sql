create
    definer = ims@`%` procedure USP_Mng_Ivr_HolidaySet_S(IN v__Emp_No varchar(10))
BEGIN
	IF v__Emp_No is null then
	  set v__Emp_No = '';
	END IF;
	
	-- call FN_CMM_Grant_S(v__Emp_No,6);
	
	SELECT HD_Code, HD_Code_Nm, A.Dept_No
	,'' as Dept_Nm -- (select dept_nm from Dept where dept_no = A.dept_no) as Dept_Nm
	FROM Mng_Ivr_HolidaySet A 
	WHERE 1=1 -- Dept_No IN(SELECT `VALUE` FROM FN_CMM_Grant_S)
	AND Del_Stat = 0
	ORDER BY HD_Code_Nm;
END;

