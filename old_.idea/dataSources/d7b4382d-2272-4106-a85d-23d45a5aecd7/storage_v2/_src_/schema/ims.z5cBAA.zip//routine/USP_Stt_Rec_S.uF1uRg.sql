create
    definer = ims@`%` procedure USP_Stt_Rec_S(IN v_Dept_No varchar(4000), IN v_Agent_Key varchar(4000),
                                              IN v_sDate datetime, IN v_eDate datetime, IN v_sTime varchar(10),
                                              IN v_eTime varchar(10))
BEGIN
	DECLARE v_SQL VARCHAR(4000);
	IF v_Dept_No IS NULL THEN
		SET v_Dept_No = '';
	END IF;
	IF v_Agent_Key IS NULL THEN
		SET v_Agent_Key = '';
	END IF;
	
	SET v_sTime = CONCAT('0',REPLACE(v_sTime,':',''));
	SET v_sTime = CONCAT_WS('',v_sTime,'00');
	SET v_sTime = RIGHT(v_sTime, 6);
	SET v_eTime = CONCAT('0',REPLACE(v_eTime,':',''));
	SET v_eTime = CONCAT_WS('',v_eTime,'59');
	SET v_eTime = RIGHT(v_eTime, 6);
	
	SET v_SQL = '';
	SET v_SQL = CONCAT_WS('', v_SQL, ' SELECT ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' DATE_FORMAT(A.REC_DATE, ''%Y-%m-%d'') AS rec_date ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , ims_ifx.FN_Get_UserID(B.Agent_key) AS user_id ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' , ims_ifx.FN_Get_Emp_Nm(B.Agent_key, DATE_FORMAT(A.REC_DATE, ''%Y-%m-%d'')) AS Emp_Nm ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , ims_ifx.FN_Get_Emp_Nm(B.Agent_key) AS Emp_Nm ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' , ims_ifx.FN_Get_Emp_Dept_Nm(B.Agent_key, DATE_FORMAT(A.REC_DATE, ''%Y-%m-%d'')) AS Dept_Nm ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , ims_ifx.FN_Get_Emp_Dept_Nm(B.Agent_key) AS Dept_Nm ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , COUNT(1) AS tot_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(REC_ENDTIME) AS tot_call_time ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , AVG(REC_ENDTIME) as avg_call_time ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_inout = ''I'' THEN 1 ELSE 0 END) AS in_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_inout = ''O'' THEN 1 ELSE 0 END) AS out_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_inout = ''L'' THEN 1 ELSE 0 END) AS local_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_endtime >= 0 AND rec_endtime < 60 THEN 1 ELSE 0 END) AS one_under_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_endtime >= 60 AND rec_endtime < 300 THEN 1 ELSE 0 END) AS one_five_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_endtime >= 300 AND rec_endtime < 600 THEN 1 ELSE 0 END) AS five_ten_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , SUM(CASE WHEN rec_endtime >= 600 THEN 1 ELSE 0 END) AS ten_over_cnt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' FROM record.crec_recfile A ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' LEFT OUTER JOIN ims.emp B ON A.REC_USER_ID = RTRIM(LTRIM(ims_ifx.FN_Get_AgentKeyToEmpNo(B.Agent_key))) ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' WHERE A.REC_DATE >= ''',DATE_FORMAT(v_sDate, '%Y%m%d'),''' ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' AND A.REC_DATE <= ''',DATE_FORMAT(v_eDate, '%Y%m%d'),''' ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' AND A.REC_STIME >= ''',v_sTime,''' ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' AND A.REC_ETIME <= ''',v_eTime,''' ');
	IF IFNULL(v_Agent_Key,'') <> '' OR  IFNULL(v_Dept_No,'') <> '' THEN
		SET v_SQL = CONCAT_WS('', v_SQL, ' AND (B.Agent_Key IN(', (CASE WHEN v_Agent_Key = '' THEN '''''' ELSE REPLACE(v_Agent_Key,'|',',') END) ,')');
		SET v_SQL = CONCAT_WS('', v_SQL, '  	OR B.Dept_No IN(', CASE WHEN v_Dept_No = '' THEN '''''' ELSE REPLACE(v_Dept_No,'|',',') END ,') )');
	END IF;
	SET v_SQL = CONCAT_WS('', v_SQL, ' GROUP BY A.REC_DATE, B.Agent_key ');
	SET @SWV_Stmt = v_SQL;
	PREPARE SWT_Stmt FROM @SWV_Stmt;
	EXECUTE SWT_Stmt;
	DEALLOCATE PREPARE SWT_Stmt;
	
END;

