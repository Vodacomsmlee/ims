create
    definer = ims@`%` procedure USP_Hist_Rec_Down_S(IN v_start int, IN v_length int, IN v_down_sdate varchar(10),
                                                    IN v_down_edate varchar(10), IN v_loginid varchar(20),
                                                    IN v_loginnm varchar(40), IN v_rec_sdate varchar(10),
                                                    IN v_rec_edate varchar(10), IN v_userid varchar(20),
                                                    IN v_usernm varchar(40))
BEGIN
	DECLARE v_SQL NATIONAL VARCHAR(4000);
	DECLARE v_WHERE NATIONAL VARCHAR(4000);
	IF v_start IS NULL THEN
		SET v_start = 0;
	END IF;
	
	IF v_length IS NULL THEN
		SET v_length = 15;
	END IF;
	
	IF v_loginid IS NULL THEN
		SET v_loginid = '';
	END IF;
	IF v_loginnm IS NULL THEN
		SET v_loginnm = '';
	END IF;
	
	IF v_userid IS NULL THEN
	  SET v_userid = '';
	END IF;
	
	IF v_usernm IS NULL THEN
		SET v_usernm = '';
	END IF;
	
	IF IFNULL(v_down_sdate,'') = '' THEN
		SET v_down_sdate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	END IF;
	
	IF IFNULL(v_down_edate,'') = '' THEN
		SET v_down_edate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	END IF;
	
	SET v_WHERE = '';
	
	IF IFNULL(v_down_sdate,'') <> '' AND IFNULL(v_down_edate,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(crymd, ''%Y-%m-%d'') >= ''',DATE_FORMAT(v_down_sdate, '%Y-%m-%d'),''' ');
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(crymd, ''%Y-%m-%d'') <= ''',DATE_FORMAT(v_down_edate, '%Y-%m-%d'),''' ');
	END IF;
	
	IF IFNULL(v_loginid,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND crsabun =''',v_loginid,''' ');
	END IF;
	
	IF IFNULL(v_loginnm,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND create_by =''',v_loginnm,''' ');
	END IF;
	
	/*
	IF IFNULL(v_rec_sdate,'') <> '' AND IFNULL(v_rec_edate,'') <> '' then
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(rec_datm, ''%Y-%m-%d'') >= ''',DATE_FORMAT(v_rec_sdate, '%Y-%m-%d'),''' ');
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(rec_datm, ''%Y-%m-%d'') <= ''',DATE_FORMAT(v_rec_edate, '%Y-%m-%d'),''' ');
	end if;
	
	IF IFNULL(v_userid,'') <> '' then
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND user_id =''',v_userid,''' ');
	end if;
	
	IF IFNULL(v_usernm,'') <> '' then
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND user_name =''',v_usernm,''' ');
	end if;
	*/
	
	-- DATA
	SET v_SQL = CONCAT_WS('', ' SELECT ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' DATE_FORMAT(CONCAT(crymd,crtime),''%Y-%m-%d %T'') as down_datm ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , crsabun as down_id');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , create_by as down_name');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , ipaddress as down_ip');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , '''' as rec_datm ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' , DATE_FORMAT(rec_datm,''%Y-%m-%d %T:%f'') rec_datm ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' , user_id ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' , user_name ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , filename as rec_filename ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' FROM record.down_his ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' LEFT OUTER JOIN record.tbl_user B  ON down_id = b.user_id ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' WHERE 1 = 1 ');
	SET v_SQL = CONCAT_WS('', v_SQL, v_WHERE);
	SET v_SQL = CONCAT_WS('', v_SQL,' ORDER BY create_date DESC ');
	SET v_SQL = CONCAT_WS('', v_SQL,' LIMIT ', v_length , ' OFFSET ' , v_start);
	
	
	SET @SWV_Stmt = v_SQL;
	PREPARE SWT_Stmt FROM @SWV_Stmt;
	EXECUTE SWT_Stmt;
	DEALLOCATE PREPARE SWT_Stmt;
END;

