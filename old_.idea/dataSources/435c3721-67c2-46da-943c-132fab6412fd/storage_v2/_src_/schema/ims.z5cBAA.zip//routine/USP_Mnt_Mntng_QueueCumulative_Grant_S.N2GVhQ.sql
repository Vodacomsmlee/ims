create
    definer = ims@`%` procedure USP_Mnt_Mntng_QueueCumulative_Grant_S(IN v__Emp_No varchar(10))
BEGIN
	CALL FN_CMM_Grant_S(v__Emp_No,2);
	
	SELECT
	`date`
	, QueueKey
	, FN_QueueNm_S(QueueKey) AS QueueName
	, SEC_TO_TIME(MaximumWaitTime) AS MaximumWaitTime
	, ServiceLevel
	, SEC_TO_TIME(AverageWaitTime) AS AverageWaitTime
	, CONCAT(FORMAT(ROUND(AbandonedRate*100,2),2),'%') AS AbandonedRate
	, Redirected,Answered,Abandoned,Received
	, CONCAT(FORMAT(ROUND(Answered*100.0/Received,2),2),'%') AS AnswerRate
	FROM(
		SELECT
			`date`, QueueKey, MaximumWaitTime,ServiceLevel,AverageWaitTime,AbandonedRate
			,Redirected,Answered,Abandoned,Received
			,ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueCumulative
		WHERE QueueKey in(SELECT * FROM FN_CMM_Grant_S)
		-- AND date > DATEADD(DD, DATEDIFF(DD,0,GETDATE()), 0)
		AND DATE_FORMAT(`date`,'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
	) AS A_ROWS
	WHERE RN = 1;
END;

