create
    definer = ims@`%` procedure USP_Mntng_Switch_Hist_I(IN v_Svr_Seq int, IN v_Svr_Uptime varchar(30),
                                                        IN v_Cpu_UsgRate varchar(6), IN v_Pwr_Total varchar(5),
                                                        IN v_Pwr_Cnsum varchar(5), IN v_Pwr_Remain varchar(5),
                                                        IN v_Mem_Nm varchar(15), IN v_Mem_Total varchar(15),
                                                        IN v_Mem_Usg varchar(15), IN v_FW_Ver varchar(30))
BEGIN
 INSERT INTO Mntng_Switch_Hist(Svr_Seq
           ,Svr_Uptime
           ,Cpu_UsgRate
           ,Pwr_Total
           ,Pwr_Cnsum
           ,Pwr_Remain
           ,Mem_Nm
           ,Mem_Total
           ,Mem_Usg
           ,FW_Ver
		   ,Reg_Dt)
     VALUES(v_Svr_Seq
           ,v_Svr_Uptime
           ,v_Cpu_UsgRate
           ,v_Pwr_Total
           ,v_Pwr_Cnsum
           ,v_Pwr_Remain
           ,v_Mem_Nm
           ,v_Mem_Total
           ,v_Mem_Usg
           ,v_FW_Ver
		   ,NOW(3));
END;

