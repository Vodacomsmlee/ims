create
    definer = ims@`%` procedure USP_Hist_Rec_Listen_Data_S(IN v_start int, IN v_length int,
                                                           IN v_listen_sdate varchar(10), IN v_listen_edate varchar(10),
                                                           IN v_listen_userid varchar(20),
                                                           IN v_listen_usernm varchar(40), IN v_rec_sdate varchar(10),
                                                           IN v_rec_edate varchar(10), IN v_rec_userid varchar(20),
                                                           IN v_rec_usernm varchar(40))
BEGIN
	DECLARE v_SQL NATIONAL VARCHAR(4000);
	DECLARE v_WHERE NATIONAL VARCHAR(4000);
	IF v_start IS NULL THEN
		SET v_start = 0;
	END IF;
	IF v_length IS NULL THEN
		SET v_length = 15;
	END IF;
	IF v_listen_userid IS NULL THEN
		SET v_listen_userid = '';
	END IF;
	IF v_listen_usernm IS NULL THEN
		SET v_listen_usernm = '';
	END IF;
	IF v_rec_userid IS NULL THEN
		SET v_rec_userid = '';
	END IF;
	IF v_rec_usernm IS NULL THEN
		SET v_rec_usernm = '';
	END IF;
	IF IFNULL(v_listen_sdate,'') = '' THEN
		SET v_listen_sdate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	END IF;
	IF IFNULL(v_listen_edate,'') = '' THEN
		SET v_listen_edate = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	END IF;
	SET v_WHERE = '';
	IF IFNULL(v_listen_sdate,'') <> '' AND IFNULL(v_listen_sdate,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(crymd, ''%Y-%m-%d'') >= ''',DATE_FORMAT(v_listen_sdate, '%Y-%m-%d'), ''' ');
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND DATE_FORMAT(crymd, ''%Y-%m-%d'') <= ''',DATE_FORMAT(v_listen_edate, '%Y-%m-%d'), ''' ');
	END IF;
	IF IFNULL(v_listen_userid,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND crsabun =''',v_listen_userid,''' ');
	END IF;
	IF IFNULL(v_listen_usernm,'') <> '' THEN
		SET v_WHERE = CONCAT_WS('',v_WHERE,' AND create_by =''',v_listen_usernm,''' ');
	END IF;
	-- DATA
	SET v_SQL = '';
	SET v_SQL = CONCAT_WS('', ' SELECT ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' DATE_FORMAT(CONCAT(crymd,crtime),''%Y-%m-%d %T'') listen_datm  ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , crsabun as listen_id ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , create_by as listen_name ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , ipaddress as listen_ip ');
	/*
	SET v_SQL = CONCAT_WS('', v_SQL, ' , DATE_FORMAT(rec_datm,''%Y-%m-%d %T:%f'') rec_datm ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , user_id ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , user_name ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , rec_filename  ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , DATE_FORMAT(rec_datm,''%Y%m%d'') rec_dt ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , rec_keycode ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' , local_no ');
	*/	
	SET v_SQL = CONCAT_WS('', v_SQL, ' FROM record.record_his ');
	-- SET v_SQL = CONCAT_WS('', v_SQL, ' LEFT OUTER JOIN record.tbl_user B  ON listen_id = B.user_id  ');
	SET v_SQL = CONCAT_WS('', v_SQL, ' WHERE 1 = 1 ');
	SET v_SQL = CONCAT_WS('', v_SQL, v_WHERE);
	SET v_SQL = CONCAT_WS('', v_SQL, ' ORDER BY crymd DESC, crtime DESC');
	SET v_SQL = CONCAT_WS('', v_SQL,' LIMIT ', v_length , ' OFFSET ' , v_start);
	
	
	SET @SWV_Stmt = v_SQL;
	PREPARE SWT_Stmt FROM @SWV_Stmt;
	EXECUTE SWT_Stmt;
	DEALLOCATE PREPARE SWT_Stmt;
END;

