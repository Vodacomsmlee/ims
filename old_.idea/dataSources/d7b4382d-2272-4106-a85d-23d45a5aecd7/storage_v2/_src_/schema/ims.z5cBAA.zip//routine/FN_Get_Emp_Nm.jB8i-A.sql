create
    definer = ims@`%` function FN_Get_Emp_Nm(v_Agent_Key int, v_Apply_Dt datetime) returns varchar(50)
BEGIN 
   DECLARE v_RETURN VARCHAR(50);
   IF v_Apply_Dt IS NULL THEN
	
      SET v_Apply_Dt = STR_TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d'),'%Y-%m-%d');
   END IF;
   IF v_Apply_Dt < CONVERT(CURRENT_TIMESTAMP,CHAR(10)) THEN
		
      SELECT   Emp_Nm INTO v_RETURN FROM ims.Emp_Hist  WHERE Agent_Key = v_Agent_Key
      AND (Apply_Start_Dt >= DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d')
      OR IFNULL(Apply_End_Dt,CURRENT_TIMESTAMP) > DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d')) ORDER BY Reg_Dt ASC LIMIT 1;
   ELSE
      SELECT   Emp_Nm INTO v_RETURN FROM ims.Emp_Hist  WHERE Agent_Key = v_Agent_Key
      AND (Apply_Start_Dt >= DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d')
      OR IFNULL(Apply_End_Dt,CURRENT_TIMESTAMP) > DATE_FORMAT(v_Apply_Dt,'%Y-%m-%d')) ORDER BY Reg_Dt DESC LIMIT 1;
   END IF;
   RETURN v_RETURN;
END;

