create
    definer = ims@`%` procedure USP_Main_Dash_S()
BEGIN
	DECLARE v_IP_PBX_IN INT;
	DECLARE v_IVR_ANSWER INT;
	DECLARE v_AGENT_ANSWER INT;
	DECLARE v_AGENT_CONN INT;
	DECLARE v_AGENT_STANDBY INT;
	DECLARE v_IVR_CUR_IN INT;
	DECLARE v_IVR_CUR_AGENT_REQ INT;
	DECLARE v_IVR_CUR_SERVICE_TRANS INT;
	DECLARE v_IVR_CUR_ABANDON INT;
	DECLARE v_IVR_CUR_CALLBACK INT;
	DECLARE v_CTI_Answered INT;
	DECLARE v_CTI_Abandoned INT;
	DECLARE v_CTI_Received INT;
	DECLARE v_CTI_CallBack INT;
	DECLARE v_CTI_Received_Rate FLOAT;
	DECLARE v_IVR_TOT_CHANNEL INT;
	DECLARE v_IVR_USE_CHANNEL INT;
	DECLARE v_IVR_STANDBY_CHANNEL INT;
	-- IP-교환기	발신 전일 누적
	DECLARE v_IP_PBX_OUT INT;
	
   select   SUM(CNT) INTO v_IP_PBX_OUT 
   FROM(
		SELECT COUNT(1) CNT
		FROM ims_ifx.callRecord A 
		JOIN ims_ifx.agentRecord B ON A.callid = B.callid
		AND A.arrivalsite = B.agentsite AND A.requeuecount = B.requeuecount
		AND B.jointype = 1
		AND B.termtype <> 48
		WHERE  A.contacttype = 3
		AND tothandlingtime > 0
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
		UNION ALL
		SELECT COUNT(1) CNT
		FROM ims_ifx.callRecord1 A 
		JOIN ims_ifx.agentRecord B ON A.callid = B.callid
		AND A.arrivalsite = B.agentsite
		AND A.requeuecount = B.requeuecount
		AND B.jointype = 1
		AND B.termtype <> 48
		WHERE  A.contacttype = 3
		AND tothandlingtime > 0
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
		UNION ALL
		SELECT COUNT(1) CNT
		FROM ims_ifx.callRecord2 A 
		JOIN ims_ifx.agentRecord B ON A.callid = B.callid
		AND A.arrivalsite = B.agentsite
		AND A.requeuecount = B.requeuecount
		AND B.jointype = 1
		AND B.termtype <> 48
		WHERE A.contacttype = 3
		AND tothandlingtime > 0
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,9,callstart),'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
	) X; 
      
	select COUNT(DISTINCT(callid)), SUM(CASE WHEN ROUTENUM <> '' THEN 1 ELSE 0 END) INTO v_IVR_ANSWER,v_AGENT_CONN 
	FROM TB_IVRSTATISTICS A JOIN Code_CalledNumber B ON A.DNIS = B.CalledNumber 
	WHERE DATE_FORMAT(startdate,'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	select SUM(Numansweredprim)+SUM(Numansweredover) INTO v_AGENT_ANSWER 
	FROM ims_ifx.calltypefifteenmin A JOIN Code_Queue B ON A.calltypekey = B.Que_Code 
	WHERE DATE_FORMAT(TIMESTAMPADD(HOUR,9,recordtimestamp),'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	-- 고객대기콜
	select SUM(Contacts) INTO v_AGENT_STANDBY 
	FROM Mntng_QueueRealTime A JOIN Code_Queue B ON A.QueueKey = B.Que_Code;
	SET v_IP_PBX_IN = v_IVR_ANSWER;
	select   COUNT(1), SUM(CASE WHEN FAILYN = 'N' THEN 1 ELSE  0 END)
	, SUM(CASE WHEN ROUTENUM = '' THEN 1 ELSE  0 END)
	, SUM(CASE WHEN FAILYN = 'Y' THEN 1 ELSE  0 END)
	, SUM(CASE WHEN CALLBACK = 1 THEN 1 ELSE  0 END) 
	INTO v_IVR_CUR_IN
	,v_IVR_CUR_AGENT_REQ
	,v_IVR_CUR_SERVICE_TRANS
	,v_IVR_CUR_ABANDON,
	v_IVR_CUR_CALLBACK 
	FROM TB_IVRSTATISTICS A 
	JOIN Code_CalledNumber B  ON A.DNIS = B.CalledNumber 
	WHERE DATE_FORMAT(startdate,'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	select   
	SUM(Answered)
	, SUM(Abandoned)
	, SUM(Received)
	, ROUND((cast(SUM(Answered) as DECIMAL(15,15))/cast(SUM(Received) as DECIMAL(15,15)))*100,2) rate
	INTO v_CTI_Answered
	,v_CTI_Abandoned
	,v_CTI_Received
	,v_CTI_Received_Rate 
	FROM (
		SELECT
		Answered
		, Abandoned
		, Received
		, ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) RowNum
		FROM Mntng_QueueCumulative 
		WHERE DATE_FORMAT(`date`,'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d')
   )x 
   WHERE RowNum = 1;
	-- 콜백 처리된것중 당일 접수된
	select COUNT(1) INTO v_CTI_CallBack 
	FROM Mng_Ivr_Callback  
	WHERE CB_RESULT = 1
	AND DATE_FORMAT(CB_CALLBACKDATETIME,'%Y-%m-%d') = DATE_FORMAT(CURRENT_TIMESTAMP,'%Y-%m-%d');
	-- IVR 실시간 현황
	select   COUNT(1)
	, IFNULL(SUM(CASE WHEN IFNULL(DNIS,'') <> '' THEN 1 ELSE 0 END),0)
	, IFNULL(SUM(CASE WHEN IFNULL(DNIS,'') = '' THEN 1 ELSE 0 END),0) 
	INTO v_IVR_TOT_CHANNEL
	,v_IVR_USE_CHANNEL
	,v_IVR_STANDBY_CHANNEL 
	FROM TB_IVRMONITOR;
	-- IP-교환기(국선) 실시간 현황
	SELECT
	IFNULL(v_IP_PBX_IN,0) IP_PBX_IN
	, IFNULL(v_IP_PBX_OUT,0) IP_PBX_OUT
	, IFNULL(v_IVR_ANSWER,0) IVR_ANSWER
	, IFNULL(v_AGENT_ANSWER,0) AGENT_ANSWER
	, IFNULL(v_AGENT_CONN,0) AGENT_CONN
	, IFNULL(v_AGENT_STANDBY,0) AGENT_STANDBY
	, IFNULL(v_IVR_CUR_IN,0) IVR_CUR_IN
	, IFNULL(v_IVR_CUR_AGENT_REQ,0) IVR_CUR_AGENT_REQ
	, IFNULL(v_IVR_CUR_SERVICE_TRANS,0) IVR_CUR_SERVICE_TRANS
	, IFNULL(v_IVR_CUR_ABANDON,0) IVR_CUR_ABANDON
	, IFNULL(v_IVR_CUR_CALLBACK,0) IVR_CUR_CALLBACK
	, IFNULL(v_CTI_Answered,0) CTI_Answered
	, IFNULL(v_CTI_Abandoned,0) CTI_Abandoned
	, IFNULL(v_CTI_Received,0) CTI_Received
	, IFNULL(v_CTI_Received_Rate,0) CTI_Received_Rate
	, IFNULL(v_CTI_CallBack,0) CTI_CallBack
	, IFNULL(ROUND((cast((v_CTI_Answered+v_CTI_CallBack) as DECIMAL(15,15))/cast(v_CTI_Received as DECIMAL(15,15)))*100,2),0) CTI_CallBack_Rate
	-- , CTI_Abandoned_Rate = ROUND(( CAST((@CTI_Abandoned) AS FLOAT) / CAST(CTI_@Received AS FLOAT) ) * 100,2)
	, v_IVR_TOT_CHANNEL IVR_TOT_CHANNEL
	, v_IVR_USE_CHANNEL IVR_USE_CHANNEL
	, v_IVR_STANDBY_CHANNEL IVR_STANDBY_CHANNEL;
END;

