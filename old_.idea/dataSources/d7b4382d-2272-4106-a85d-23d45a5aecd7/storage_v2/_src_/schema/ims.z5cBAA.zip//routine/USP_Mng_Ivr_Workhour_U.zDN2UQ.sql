create
    definer = ims@`%` procedure USP_Mng_Ivr_Workhour_U(IN v_WH_Seq int, IN v_WH_Type tinyint unsigned,
                                                       IN v_WH_START varchar(10), IN v_WH_END varchar(10),
                                                       IN v_WH_LUNCH_YN tinyint unsigned,
                                                       IN v_WH_LUNCH_START varchar(10), IN v_WH_LUNCH_END varchar(10),
                                                       IN v_WH_BEFORE_PROMPT varchar(10),
                                                       IN v_WH_AFTER_PROMPT varchar(10),
                                                       IN v_WH_LUNCH_PROMPT varchar(10), IN v_WH_OUTSERVICE int,
                                                       IN v_WH_OUTSERVICE_TARGET varchar(15), IN v_WH_IN_LUNCH int,
                                                       IN v_WH_IN_LUNCH_TARGET varchar(10))
BEGIN
	IF v_WH_IN_LUNCH_TARGET = '' THEN
		SET v_WH_IN_LUNCH_TARGET = '0';
	END IF;
	
	IF v_WH_OUTSERVICE_TARGET = '' THEN
		SET v_WH_OUTSERVICE_TARGET = '0';
	END IF;
	
	
	IF v_WH_LUNCH_YN = 0 THEN
		UPDATE Mng_Ivr_Workhour
		SET WH_Type = v_WH_Type
		,WH_START = RIGHT(CONCAT_WS('','0',v_WH_START),4)
		,WH_END = RIGHT(CONCAT_WS('','0',v_WH_END),4)
		,WH_LUNCH_YN = v_WH_LUNCH_YN
		,WH_LUNCH_START = RIGHT(CONCAT_WS('','0',v_WH_LUNCH_START),4)
		,WH_LUNCH_END = RIGHT(CONCAT_WS('','0',v_WH_LUNCH_END),4)
		,WH_BEFORE_PROMPT = v_WH_BEFORE_PROMPT
		,WH_AFTER_PROMPT = v_WH_AFTER_PROMPT
		,WH_LUNCH_PROMPT = v_WH_LUNCH_PROMPT
		,WH_OUTSERVICE = v_WH_OUTSERVICE
		,WH_OUTSERVICE_TARGET = v_WH_OUTSERVICE_TARGET
		,WH_IN_LUNCH = v_WH_IN_LUNCH
		,WH_IN_LUNCH_TARGET = v_WH_IN_LUNCH_TARGET
		WHERE WH_Seq = v_WH_Seq;
	ELSE
		UPDATE Mng_Ivr_Workhour
		SET WH_Type = v_WH_Type
		,WH_START = RIGHT(CONCAT_WS('','0',v_WH_START),4)
		,WH_END = RIGHT(CONCAT_WS('','0',v_WH_END),4)
		,WH_LUNCH_YN = v_WH_LUNCH_YN
		,WH_LUNCH_START = RIGHT(CONCAT_WS('','0',v_WH_LUNCH_START),4)
		,WH_LUNCH_END = RIGHT(CONCAT_WS('','0',v_WH_LUNCH_END),4)
		,WH_BEFORE_PROMPT = v_WH_BEFORE_PROMPT
		,WH_AFTER_PROMPT = v_WH_AFTER_PROMPT
		-- ,WH_LUNCH_PROMPT = v_WH_LUNCH_PROMPT
		,WH_OUTSERVICE = v_WH_OUTSERVICE
		,WH_OUTSERVICE_TARGET = v_WH_OUTSERVICE_TARGET
		-- ,WH_IN_LUNCH = v_WH_IN_LUNCH
		,WH_IN_LUNCH_TARGET = v_WH_IN_LUNCH_TARGET
		WHERE WH_Seq = v_WH_Seq;
	END IF;
END;

