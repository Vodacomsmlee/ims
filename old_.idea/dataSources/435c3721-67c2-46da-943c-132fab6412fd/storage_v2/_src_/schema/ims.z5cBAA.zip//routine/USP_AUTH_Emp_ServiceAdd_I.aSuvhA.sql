create
    definer = ims@`%` procedure USP_AUTH_Emp_ServiceAdd_I(IN v_Svc_No int, IN v_Emp_No varchar(10))
BEGIN
	DECLARE v_RTN_VALUE INT;
	DECLARE v_REG_DT DATETIME;
	SET v_RTN_VALUE = -1;
	SET v_REG_DT = SYSDATE(3);
	IF v_Svc_No IS NULL OR IFNULL(v_Emp_No,'') = '' then
		SET v_RTN_VALUE = -2;
	ELSE
		IF EXISTS(SELECT  Svc_No FROM Role_Emp_Service  WHERE Emp_No = v_Emp_No AND Svc_No = v_Svc_No AND Del_Stat = 0 LIMIT 1) then
				
			UPDATE Role_Emp_Service
			SET Del_Stat = 1
			WHERE Emp_No = v_Emp_No AND Svc_No = v_Svc_No;
			SET v_REG_DT = NULL;
		ELSE
			INSERT INTO Role_Emp_Service(Emp_No, Svc_No, Reg_Dt)
			VALUES(v_Emp_No, v_Svc_No, v_REG_DT);
		end if;
		
		SET v_RTN_VALUE = 1;
	end if;
	SELECT v_RTN_VALUE Result, DATE_FORMAT(v_REG_DT,'%Y-%m-%d %T:%f') AS Reg_Dt;
END;

