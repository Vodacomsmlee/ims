create
    definer = ims@`%` procedure USP_Mem_Emp_D(IN v_Emp_No varchar(10), IN v_Proc_Emp_NO varchar(10),
                                              IN v_Apply_End_Dt datetime)
BEGIN
	DECLARE v_RTN_VAL TINYINT UNSIGNED;
	DECLARE v_RoleChk INT;
	DECLARE v_Dept_Nm VARCHAR(50);
	DECLARE v_AgentKey INT; 
	DECLARE v_Emp_Nm VARCHAR(20);
	DECLARE v_UserID VARCHAR(20);
	DECLARE v_Organ_No VARCHAR(20);
	
	SET v_RTN_VAL = 0; -- 삭제실패
	
	-- 현재 로그인 사용자가 삭제할 권한이 있는지 확인
	-- Role이 관리자인 경우만 삭제처리
	SELECT IFNULL(Role_No,-1) INTO v_RoleChk FROM EMP  WHERE Emp_No = v_Proc_Emp_NO AND Del_Stat = 0;
	IF v_RoleChk = 3 THEN
		
		IF v_Apply_End_Dt IS NULL THEN	
			SET v_Apply_End_Dt = DATE_FORMAT(NOW(),'%Y-%m-%d');
		END IF;
		
		SELECT B.Dept_Nm, Agent_Key, Emp_Nm, A.Organ_No INTO v_Dept_Nm, v_AgentKey, v_Emp_Nm, v_Organ_No
		FROM EMP A 
		JOIN Dept B ON A.Dept_No = B.Dept_No 
		WHERE Emp_No = v_Emp_No;
		
		-- Emp_Hist 저장
		INSERT INTO Emp_Hist(Agent_Key, Emp_No, Organ_No, Emp_Nm, Dept_No, Dept_Nm, Apply_End_Dt, Reg_Dt)
		SELECT Agent_Key, Emp_No, v_Organ_No, Emp_Nm, Dept_No, v_Dept_Nm, v_Apply_End_Dt, CURRENT_TIMESTAMP
		FROM EMP 
		WHERE Emp_No = v_Emp_No;
		
		-- 삭제
		UPDATE EMP
		SET Del_Stat = 1
		WHERE Emp_No = v_Emp_No;
		
		
		-- 녹취 계정 삭제
		SET v_UserID = ims_ifx.FN_Get_UserID(v_AgentKey);
		CALL record.sp_User_insert_app(v_UserID,v_Emp_Nm,'9999','D');
		
		SET v_RTN_VAL = 1;
	END IF;
	-- SELECT CAST(v_RTN_VAL AS SIGNED INTEGER) Rst;
	select IF(v_RTN_VAL = TRUE, 'true', 'false') as Rst;
END;

