create
    definer = ims@`%` procedure USP_Mnt_Mntng_Dash_QueueRealTime_S()
BEGIN
	SELECT
	SUM(Contacts) as WaitCalls
	, ROUND(AVG(AbandonedRate),2) as AbandonedRate
	, DATE_FORMAT(TIMESTAMPADD(SECOND,MAX(OldestContactWaitTime),''),'%h:%i:%s') as OldestContactWaitTime
	, DATE_FORMAT(TIMESTAMPADD(SECOND,AVG(AverageAnsweredWaitTime),''),'%h:%i:%s') as AverageAnsweredWaitTime
	, ROUND(AVG(ServiceLevel),2) ServiceLevel,DATE_FORMAT(TIMESTAMPADD(SECOND,AVG(EstimatedAnsweredWaitTime),''),'%h:%i:%s') as EstimatedAnsweredWaitTime
	, ROUND(AVG(EstimatedServiceLevel),2) as EstimatedServiceLevel
	FROM(
		SELECT
		`date`, QueueKey, Contacts, OverflowedContacts, ServiceLevel,
		EstimatedServiceLevel, AbandonedRate, OldestContactWaitTime,
		AverageAnsweredWaitTime, EstimatedAnsweredWaitTime, AverageAbandonedWaitTime,
		ROW_NUMBER() OVER(PARTITION BY QueueKey ORDER BY `date` DESC) AS RN
		FROM Mntng_QueueRealTime
	) AS A_ROWS
	WHERE RN = 1;
END;

