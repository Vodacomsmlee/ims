create
    definer = ims@`%` procedure USP_Mng_Ivr_DNIS_D(IN v_DNIS_CODE int)
BEGIN
	UPDATE Mng_Ivr_DNIS
	SET Del_Stat = 1
	WHERE DNIS_CODE = v_DNIS_CODE;
END;

