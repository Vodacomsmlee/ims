create
    definer = ims@`%` procedure USP_Mng_Ivr_HolidaySet_D(IN v_HD_Code int)
BEGIN
	UPDATE Mng_Ivr_HolidaySet SET Del_Stat = 1
	WHERE HD_Code = v_HD_Code;
END;

