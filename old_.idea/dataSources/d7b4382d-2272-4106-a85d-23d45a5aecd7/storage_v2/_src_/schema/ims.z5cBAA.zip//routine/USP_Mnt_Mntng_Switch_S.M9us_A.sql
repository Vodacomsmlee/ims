create
    definer = ims@`%` procedure USP_Mnt_Mntng_Switch_S()
BEGIN
	SELECT A.Svr_Ip, A.Svr_Seq, A.Svr_Desc
	, (SELECT Seq FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1) AS Seq
	, IFNULL((SELECT Svr_Uptime FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Svr_Uptime
	, IFNULL((SELECT Cpu_UsgRate FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Cpu_UsgRate
	, IFNULL((SELECT Pwr_Total FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Pwr_Total
	, IFNULL((SELECT Pwr_Cnsum FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Pwr_Cnsum
	, IFNULL((SELECT Pwr_Remain FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Pwr_Remain
	, IFNULL((SELECT Mem_Nm FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Mem_Nm
	, IFNULL((SELECT Mem_Total FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Mem_Total
	, IFNULL((SELECT Mem_Usg FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS Mem_Usg
	, IFNULL((SELECT FW_Ver FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT 1),'') AS FW_Ver
	-- , (SELECT Reg_Dt FROM mntng_switch_hist WHERE Svr_Seq = A.Svr_Seq ORDER BY Seq DESC LIMIT) AS Reg_Dt
	FROM mntng_svr A
	WHERE Svr_Type = 1 -- 0:서버, 1:네트워크 스위치
	AND Del_Stat = 0;
END;

