create
    definer = ims@`%` procedure USP_Mng_Ivr_Notice_U(IN v_NT_CODE int, IN v_Dept_No int, IN v_NT_NAME varchar(20),
                                                     IN v_NT_SERVICE_SDATE varchar(8), IN v_NT_SERVICE_EDATE varchar(8),
                                                     IN v_NT_USE_YN int, IN v_NT_tts_TIMEREAD_YN int,
                                                     IN v_NT_tts_SDate varchar(8), IN v_NT_tts_STime varchar(4),
                                                     IN v_NT_tts_EDate varchar(8), IN v_NT_tts_ETime varchar(4),
                                                     IN v_NT_PROMPT varchar(10), IN v_NT_PROMPT_END varchar(10),
                                                     IN v_NT_PROMPT_END2 varchar(10))
BEGIN
   UPDATE Mng_Ivr_Notice
   SET Dept_No = v_Dept_No
   ,NT_NAME = v_NT_NAME
   ,NT_SERVICE_SDATE = v_NT_SERVICE_SDATE
   ,NT_SERVICE_EDATE = v_NT_SERVICE_EDATE
   ,NT_USE_YN = v_NT_USE_YN
   ,NT_tts_TIMEREAD_YN = v_NT_tts_TIMEREAD_YN
   ,NT_tts_SDate = v_NT_tts_SDate
   ,NT_tts_STime = RIGHT(CONCAT_WS('','0',v_NT_tts_STime),4)
   ,NT_tts_EDate = v_NT_tts_EDate
   ,NT_tts_ETime = RIGHT(CONCAT_WS('','0',v_NT_tts_ETime),4)
   ,NT_PROMPT = v_NT_PROMPT
   ,NT_PROMPT_END = v_NT_PROMPT_END
   ,NT_PROMPT_END2 = v_NT_PROMPT_END2
   WHERE NT_CODE = v_NT_CODE;
   
END;

