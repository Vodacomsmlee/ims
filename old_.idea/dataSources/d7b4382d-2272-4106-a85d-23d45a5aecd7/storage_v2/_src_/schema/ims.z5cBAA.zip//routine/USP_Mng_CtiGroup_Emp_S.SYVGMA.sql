create
    definer = ims@`%` procedure USP_Mng_CtiGroup_Emp_S(IN v_Group_Seq int)
BEGIN
	SELECT Emp_No
	FROM Mng_Cti_Group_Emp 
	WHERE Group_Seq = v_Group_Seq;
END;

