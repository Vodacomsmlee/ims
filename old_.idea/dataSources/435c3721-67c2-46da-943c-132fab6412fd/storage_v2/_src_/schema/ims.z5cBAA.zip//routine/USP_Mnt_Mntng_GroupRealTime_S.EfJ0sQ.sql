create
    definer = ims@`%` procedure USP_Mnt_Mntng_GroupRealTime_S()
BEGIN
	SELECT
	`date`
	, groupkey
	, CallsWaiting
	,LoggedOnUsers
	,IdleUsers
	,BusyUsers
	,AwayUsers
	FROM(
		SELECT
		`date`
		, groupkey
		, CallsWaiting
		,LoggedOnUsers
		,IdleUsers
		,BusyUsers
		,AwayUsers
		,ROW_NUMBER() OVER(PARTITION BY groupkey ORDER BY `date` DESC) AS RN
		FROM Mntng_GroupRealTime
	) AS A_ROWS
	WHERE RN = 1;
END;

