create
    definer = ims@`%` procedure USP_Cmm_SsoKey_U(IN v_empno varchar(10), IN v_key varchar(100), OUT v_resultcode int)
BEGIN
	SET v_resultcode = 0;
	IF NOT EXISTS(SELECT Emp_No FROM Emp  WHERE Emp_No = v_empno LIMIT 1) then
		SET v_resultcode = -1;
	ELSE
		IF IFNULL(v_key,'') = '' then
			SET v_resultcode = -2;
		ELSE
			UPDATE Emp
			SET Auth_Key = v_key
			WHERE Emp_No = v_empno;
			
			SET v_resultcode = 1;
		end if;
	end if;
END;

