create
    definer = ims@`%` procedure USP_Mntng_Queue_Realtime_All_D()
BEGIN
TRUNCATE TABLE `mntng_queuerealtime`;
END;

