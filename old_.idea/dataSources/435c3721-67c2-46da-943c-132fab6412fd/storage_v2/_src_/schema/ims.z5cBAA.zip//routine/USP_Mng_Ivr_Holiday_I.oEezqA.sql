create
    definer = ims@`%` procedure USP_Mng_Ivr_Holiday_I(IN v_HD_Code int, IN v_HD_Nm varchar(50), IN v_HD_Date varchar(8),
                                                      IN v_HD_TimeStart varchar(6), IN v_HD_TimeEnd varchar(6),
                                                      IN v_HD_AnuallyYN tinyint unsigned,
                                                      IN v_HD_PromptYN tinyint unsigned, IN v_HD_Prompt char(10))
BEGIN
	INSERT INTO Mng_Ivr_Holiday(HD_Code, HD_Nm, HD_Date, HD_TimeStart, HD_TimeEnd, HD_AnuallyYN, HD_PromptYN, HD_Prompt)
	VALUES(v_HD_Code
	, v_HD_Nm,v_HD_Date
	, RIGHT(CONCAT_WS('','0',v_HD_TimeStart),4)
	, RIGHT(CONCAT_WS('','0',v_HD_TimeEnd),4)
	, v_HD_AnuallyYN
	, v_HD_PromptYN
	, v_HD_Prompt);
END;

