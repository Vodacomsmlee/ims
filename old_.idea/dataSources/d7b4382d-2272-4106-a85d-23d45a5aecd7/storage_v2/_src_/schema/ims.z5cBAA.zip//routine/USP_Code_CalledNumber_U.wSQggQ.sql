create
    definer = ims@`%` procedure USP_Code_CalledNumber_U(IN v_Seq int, IN v_Called_Key int,
                                                        IN v_CalledNumber varchar(20), IN v_Desc varchar(100),
                                                        IN v_Use_Stat tinyint unsigned)
BEGIN
	UPDATE Code_CalledNumber
	SET Called_Key = v_Called_Key 
	, CalledNumber = v_CalledNumber
	,`Desc` = v_Desc
	, Use_Stat = v_Use_Stat
	WHERE SEQ = v_Seq;
END;

