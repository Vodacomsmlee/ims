create
    definer = ims@`%` function FN_QueueDiv_S(v_Dept_No int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   
   SELECT B.Que_Div into v_RETURN 
   FROM ims.code_dept_que A
   join ims.code_queue B On A.Que_Code = B.Que_Code
   WHERE A.Dept_No = v_Dept_No
   group by B.Que_Div;
   
   SET v_RETURN = IFNULL(v_RETURN,'');
   RETURN v_RETURN;
END;

