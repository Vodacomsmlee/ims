create
    definer = ims@`%` procedure USP_Mng_Ivr_Scenario_I(IN v_Dept_No int, IN v_SC_NAME varchar(20),
                                                       IN v_SC_NOTI_YN tinyint unsigned, IN v_SC_NOTI varchar(10),
                                                       IN v_SC_NEXT varchar(10), IN v_SC_NEXT_TARGET varchar(15),
                                                       IN v_SC_PROMPT_YN tinyint unsigned, IN v_SC_PROMPT varchar(10))
BEGIN
	IF(v_SC_NOTI = '') THEN
		SET v_SC_NOTI = NULL;
	ELSE
		SET v_SC_NOTI = CAST(v_SC_NOTI AS INT);
	END IF;
	IF(v_SC_NEXT = '') THEN
		SET v_SC_NEXT = NULL;
	ELSE
		SET v_SC_NEXT = CAST(v_SC_NEXT AS INT);
	END IF;
	
	IF(v_SC_PROMPT_YN = '') THEN
		SET v_SC_PROMPT_YN = NULL;
	ELSE
		SET v_SC_PROMPT_YN = CAST(v_SC_PROMPT_YN AS int);
	END IF;
	INSERT INTO Mng_Ivr_Scenario(
		Dept_No
		,SC_NAME
		,SC_NOTI_YN
		,SC_NOTI
		,SC_NEXT
		,SC_NEXT_TARGET
		,SC_PROMPT_YN
		,SC_PROMPT
	) VALUES (
		v_Dept_No,
		v_SC_NAME,
		v_SC_NOTI_YN,
		v_SC_NOTI,
		v_SC_NEXT,
		v_SC_NEXT_TARGET,
		v_SC_PROMPT_YN,
		v_SC_PROMPT
	);
			
END;

