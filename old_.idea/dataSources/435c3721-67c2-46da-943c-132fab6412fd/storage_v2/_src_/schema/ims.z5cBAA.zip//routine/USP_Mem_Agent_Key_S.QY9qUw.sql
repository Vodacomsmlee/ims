create
    definer = ims@`%` procedure USP_Mem_Agent_Key_S()
BEGIN
   SELECT B.userkey
	, ims_ifx.FN_Get_UserID(B.userkey) userid
	, (CASE WHEN A.Emp_No IS NULL THEN 1 ELSE 0 END) Use_Stat
   FROM(SELECT Emp_No, Agent_Key
		  FROM Emp
		  WHERE Del_Stat = 0) A
   RIGHT OUTER JOIN ims_ifx.users B  ON A.Agent_Key = B.userkey AND B.usertype = 0
   WHERE B.userkey NOT IN(1,2);
END;

