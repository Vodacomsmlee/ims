create
    definer = ims@`%` procedure USP_Mnt_Mntng_ProcessHist_I(IN v_Seq int, IN v_ProcNm varchar(100), IN v_RunProcessCnt int)
BEGIN
	DECLARE v_Cmm_Process_Cnt INT;
	IF EXISTS(SELECT  Process_Seq FROM Mntng_Process_Hist  WHERE Process_Seq = v_Seq LIMIT 1) then
	
		select Process_Cnt INTO v_Cmm_Process_Cnt FROM Mntng_Process  WHERE Seq = v_Seq;
		UPDATE Mntng_Process_Hist
		SET Run_Process_Cnt = v_RunProcessCnt
		,Reg_Dt = SYSDATE(3)
		WHERE Process_Seq = v_Seq;
		-- 실행중인 프로세스 Cnt가 기본 프로세스 Cnt보다 작을경우 업데이트
		IF v_Cmm_Process_Cnt > v_RunProcessCnt then
			UPDATE Mntng_Process_Hist
			SET Risk_Dt = SYSDATE(3)
			WHERE Process_Seq = v_Seq;
		end if;
	ELSE
		INSERT INTO Mntng_Process_Hist(Process_Seq, Process_Nm, Run_Process_Cnt)
		VALUES(v_Seq, v_ProcNm, v_RunProcessCnt);
	end if;
END;

