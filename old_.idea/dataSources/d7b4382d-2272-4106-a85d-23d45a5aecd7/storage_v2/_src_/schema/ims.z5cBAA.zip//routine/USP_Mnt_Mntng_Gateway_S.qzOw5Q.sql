create
    definer = ims@`%` procedure USP_Mnt_Mntng_Gateway_S()
BEGIN
	SELECT Svr_Ip, Svr_Seq, Svr_Desc
	FROM mntng_svr A
	WHERE Svr_Type = 1 -- 0:서버, 1:네트워크 스위치, 2:Gateway
	AND Del_Stat = 0;
END;

