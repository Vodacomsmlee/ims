create
    definer = ims@`%` procedure USP_Code_CalledNumber_S()
BEGIN
	SELECT Seq, Called_Key, CalledNumber, `Desc`, Use_Stat
	, (CASE WHEN Use_Stat = 1 THEN '사용' ELSE '사용 안함' END) AS Use_Stat_Nm
	FROM Code_CalledNumber 
	WHERE Del_Stat = 0;
END;

