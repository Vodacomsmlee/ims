create
    definer = ims@`%` function FN_Get_Dept_Nm_S(v_Dept_No int) returns varchar(100)
BEGIN 
   DECLARE v_RETURN VARCHAR(100);
   select Dept_Nm INTO v_RETURN FROM ims.Dept WHERE Dept_No = v_Dept_No;
   RETURN v_RETURN;
END;

